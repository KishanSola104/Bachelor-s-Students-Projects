﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="Payment.aspx.cs" Inherits="Payment" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>Payment</title>
    <style>
        .container { width: 50%; margin: auto; padding: 20px; border: 1px solid #ccc; border-radius: 10px; background: #f9f9f9; }
        .form-group { margin-bottom: 15px; }
        .form-label { font-weight: bold; }
        .total-price { font-size: 20px; font-weight: bold; color: red; }
    </style>
</head>
<body>

    <form id="form1" runat="server">

    <div class="container">
        <h2>Payment</h2>
        <p>
            <asp:Label ID="lblMessage" runat="server"></asp:Label>
        </p>
        <asp:Label ID="lblMovieName" runat="server" Font-Bold="true" Font-Size="18px" />
        
        <div class="form-group">
            <label class="form-label">Seat Type:</label>
            <asp:Label ID="lblSeatType" runat="server" />
        </div>

        <div class="form-group">
            <label class="form-label">Number of Seats:</label>
            <asp:Label ID="lblSeatCount" runat="server" />
        </div>

        <div class="form-group">
            <label class="form-label">Total Price:</label>
            <asp:Label ID="lblTotalPrice" runat="server" CssClass="total-price" />
        </div>

        <div class="form-group">
            <label class="form-label">Select Payment Method:</label>
            <asp:DropDownList ID="ddlPaymentMethod" runat="server" CssClass="form-control">
                <asp:ListItem Text="Credit/Debit Card" Value="Card" />
                <asp:ListItem Text="UPI Payment" Value="UPI" />
                <asp:ListItem Text="Net Banking" Value="NetBanking" />
            </asp:DropDownList>
        </div>

        <asp:Button ID="btnPay" runat="server" CssClass="btn btn-success" Text="Confirm Payment" OnClick="btnPay_Click" />
    </div>

    </form>

</body>
</html>