﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="ManageMovies.aspx.cs" Inherits="ManageMovies" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>Manage Movies  - CineStar Theater</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body { font-family: Arial, sans-serif; margin: 0; background-color: #f4f4f4; }
        .container { display: flex; }
        .sidebar { width: 250px; background: #222; color: white; padding: 20px; height: 100vh; }
        .sidebar a { display: block; color: white; padding: 10px; text-decoration: none; }
        .sidebar a:hover { background: red; }
        .main-content { flex: 1; padding: 20px; }
        .header { background: red; padding: 15px; color: white; text-align: right; }
        .dashboard-cards { display: flex; gap: 20px; margin-top: 20px; }
        .card { background: white; padding: 20px; box-shadow: 0 0 10px rgba(0,0,0,0.1); flex: 1; text-align: center; }
        .footer { background: #222; color: white; text-align: center; padding: 10px; position: relative; bottom: 0; width: 100%; }
        
        .form-container { max-width: 600px; margin: auto; padding: 20px; background: white; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        .form-group { margin-bottom: 15px; }
        .form-group label { font-weight: bold; }
        .form-group input, .form-group select, .form-group textarea { width: 100%; padding: 8px; border: 1px solid #ccc; }
        .form-group button { background: red; color: white; padding: 10px; border: none; cursor: pointer; }
        .form-group button:hover { background: darkred; }
    </style>
</head>
<body>
<form id="Form1" runat="server">
    <div class="header">
        Welcome, <asp:Label ID="lblAdminName" runat="server" /> | 
        <asp:Button ID="btnLogout" runat="server" Text="Logout" OnClick="btnLogout_Click" />
    </div>
    <div class="container">
        <div class="sidebar">
            <h2>Admin Panel</h2>
            <a href="ManageMovies.aspx">Manage Movies</a>
            <a href="ManageShows.aspx">Manage Shows</a>
            <a href="ManageBookings.aspx">Manage Bookings</a>
            <a href="ManageUsers.aspx">Manage Users</a>
        
        </div>
       
              <div class="main-content">
            <h2>Manage Movies</h2>
            <div class="form-container">
                <div class="form-group">
                    <label>Select Movie ID:</label>
                    <asp:DropDownList ID="ddlMovieID" runat="server" AutoPostBack="true" OnSelectedIndexChanged="ddlMovieID_SelectedIndexChanged" CssClass="form-control"></asp:DropDownList>
                </div>
                <div class="form-group">
                    <label>Movie ID:</label>
                    <asp:TextBox ID="txtMovieID" runat="server" CssClass="form-control" required></asp:TextBox>
                </div>
                <div class="form-group">
                    <label>Movie Name:</label>
                    <asp:TextBox ID="txtMovieName" runat="server" CssClass="form-control" ></asp:TextBox>
                </div>
                <div class="form-group">
                    <label>Movie Cast:</label>
                    <asp:TextBox ID="txtMovieCast" runat="server" CssClass="form-control" TextMode="MultiLine"></asp:TextBox>
                </div>
                <div class="form-group">
                    <label>Movie Category:</label>
                    <asp:DropDownList ID="ddlCategory" runat="server" CssClass="form-control">
                        <asp:ListItem Value="Hindi">Hindi</asp:ListItem>
                        <asp:ListItem Value="English">English</asp:ListItem>
                        <asp:ListItem Value="South">South</asp:ListItem>
                    </asp:DropDownList>
                </div>
                <div class="form-group">
                    <label>Description:</label>
                    <asp:TextBox ID="txtDescription" runat="server" CssClass="form-control" TextMode="MultiLine" ></asp:TextBox>
                </div>
                <div class="form-group">
                    <label>Movie Poster:</label>
                    <asp:FileUpload ID="filePoster" runat="server" CssClass="form-control"  />
                </div>
                <div class="form-group">
                    <asp:Button ID="btnAddMovie" runat="server" Text="Add Movie" CssClass="btn" OnClick="btnAddMovie_Click" />
                    <asp:Button ID="btnUpdateMovie" runat="server" Text="Update Movie" CssClass="btn" OnClick="btnUpdateMovie_Click" />
                    <asp:Button ID="btnDeleteMovie" runat="server" Text="Delete Movie" CssClass="btn" OnClick="btnDeleteMovie_Click" />
                </div>
                <div class="form-group">
                    <asp:Label ID="lblMessage" runat="server" ForeColor="Red" />
                </div>
            </div>
        </div>
          

    </div>
    <div class="footer">&copy; 2025 CineStar Theater - Admin Panel</div>
    </form>
</body>
</html>
