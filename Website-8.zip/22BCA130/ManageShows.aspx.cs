﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ManageShows : System.Web.UI.Page
{
    string connStr = ConfigurationManager.ConnectionStrings["TheaterBookingDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadMovies();
           // LoadShows();
        }
    }

    private void LoadMovies()
    {
        try
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                SqlDataAdapter da = new SqlDataAdapter("SELECT MovieID, MovieName FROM Movies", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);

                ddlMovieID.DataSource = dt;
                ddlMovieID.DataTextField = "MovieName";
                ddlMovieID.DataValueField = "MovieID";
                ddlMovieID.DataBind();
                ddlMovieID.Items.Insert(0, new ListItem("--Select Movie--", ""));
            }
        }
        catch (Exception ex)
        {
            lblMessage.Text = "Error loading movies: " + ex.Message;
        }
    }

    

    protected void btnAddShow_Click(object sender, EventArgs e)
    {
        try
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO Shows (ShowID, ShowDate, ShowTime, ScreenNo, TicketPrice, MovieID) VALUES (@ShowID, @ShowDate, @ShowTime, @ScreenNo, @TicketPrice, @MovieID)", conn);
                cmd.Parameters.AddWithValue("@ShowID", txtShowID.Text);
                cmd.Parameters.AddWithValue("@ShowDate", txtShowDate.Text);
                cmd.Parameters.AddWithValue("@ShowTime", txtShowTime.Text);
                cmd.Parameters.AddWithValue("@ScreenNo", txtScreenNo.Text);
                cmd.Parameters.AddWithValue("@TicketPrice", txtTicketPrice.Text);
                cmd.Parameters.AddWithValue("@MovieID", ddlMovieID.SelectedValue);

                cmd.ExecuteNonQuery();
                lblMessage.Text = "Show added successfully!";
             //   LoadShows();
            }
        }
        catch (Exception ex)
        {
            lblMessage.Text = "Error adding show: " + ex.Message;
        }
    }

    

  
    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        txtShowDate.Text = Calendar1.SelectedDate.ToString("yyyy-MM-dd");
    }
    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminLogin.aspx");
    }
}
