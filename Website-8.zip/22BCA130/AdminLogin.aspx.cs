﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.UI;


    public partial class AdminLogin : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtEmail == null || txtPassword == null)
            {
                lblError.Text = "Error: Form controls not initialized.";
                lblError.Visible = true;
                return;
            }

            string email = txtEmail.Text.Trim();
            string password = txtPassword.Text.Trim();

            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                lblError.Text = "Please enter both email and password.";
                lblError.Visible = true;
                return;
            }

            // Fix for C# 4.0 - No Null-conditional Operator
            string connString = ConfigurationManager.ConnectionStrings["TheaterBookingDB"] != null
                ? ConfigurationManager.ConnectionStrings["TheaterBookingDB"].ConnectionString
                : string.Empty;

            if (string.IsNullOrEmpty(connString))
            {
                lblError.Text = "Database connection error. Please check web.config.";
                lblError.Visible = true;
                return;
            }

            try
            {
                using (SqlConnection con = new SqlConnection(connString))
                {
                    string query = "SELECT COUNT(1) FROM Admins WHERE Email = @Email AND Password = @Password";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@Email", email);
                        cmd.Parameters.AddWithValue("@Password", password);

                        con.Open();
                        int count = Convert.ToInt32(cmd.ExecuteScalar());
                        con.Close();

                        if (count == 1)
                        {
                            Session["AdminEmail"] = email;
                            Response.Redirect("AdminDashboard.aspx");
                        }
                        else
                        {
                            lblError.Text = "Invalid email or password.";
                            lblError.Visible = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                lblError.Text = "An error occurred: " + ex.Message;
                lblError.Visible = true;
            }
        }
    }
