﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="BookShow.aspx.cs" Inherits="BookShow" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
<style>
       /* Global Styles */
body {
    font-family: 'Poppins', sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f8f8f8;
}

/* Header */
.header {
    height: 80px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 30px;
    background-color: #007bff;
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
}

.logo {
    height: 70px;
    width: 120px;
    border-radius: 10px;
}

/* Navigation Menu */
.menu {
    display: flex;
    list-style: none;
    background: linear-gradient(90deg, #ff7e5f, #feb47b);
    padding: 12px 20px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

.menu a {
    text-decoration: none;
    color: white;
    margin: 0 20px;
    font-size: 18px;
    font-weight: 500;
    transition: 0.3s;
}

.menu a:hover {
    color: #ffdd57;
    text-shadow: 0px 0px 8px rgba(255, 255, 255, 0.6);
}

/* Search & Cart */
.search-cart {
    display: flex;
    align-items: center;
}

.search-box {
    padding: 8px;
    border: none;
    border-radius: 20px;
    outline: none;
}

.search-btn {
    background: #FFD700;
    border: none;
    padding: 8px 12px;
    border-radius: 50%;
    cursor: pointer;
    margin-left: 8px;
    transition: 0.3s;
}

.search-btn:hover {
    background: #fff;
}

.cart-icon {
    font-size: 22px;
    margin-left: 15px;
    cursor: pointer;
    color: #fff;
    transition: 0.3s;
}

.cart-icon:hover {
    color: #FFD700;
}

/* Banner Section */
.banner {
    width: 100%;
    height: 200px;
    display: flex;
    justify-content: center;
    align-items: center;
    overflow: hidden;
    position: relative;
}

.banner-img {
    width: 100%;
    height: 100px;
    object-fit: cover;
}

.banner-text {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: rgba(0, 0, 0, 0.6);
    padding: 20px 40px;
    border-radius: 8px;
    color: #fff;
    font-size: 26px;
    font-weight: bold;
}

/* Product Section */
.product-section {
    text-align: center;
    padding: 50px 0;
    background: #e0e0e0;
    animation: fadeIn 1s ease-in-out;
}

@keyframes fadeIn {
    from {
        opacity: 0;
    }
    to {
        opacity: 1;
    }
}

/* Product List */
.container {
    width: 90%;
    margin: auto;
    text-align: center;
}

.product-list {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 20px;
    margin-top: 20px;
}

.product {
    width: 250px;
    background: #fff;
    border-radius: 10px;
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
    padding: 15px;
    text-align: center;
    transition: transform 0.3s ease-in-out;
}

.product:hover {
    transform: scale(1.05);
}

.product img {
    width: 100%;
    height: 200px;
    object-fit: cover;
    border-radius: 10px;
}

.product-info {
    padding: 10px;
}

h3 {
    font-size: 20px;
    color: #333;
    margin: 10px 0;
}

.description {
    font-size: 14px;
    color: #666;
    height: 60px;
    overflow: hidden;
    text-overflow: ellipsis;
}

.price {
    font-size: 18px;
    color: #d9534f;
    font-weight: bold;
    margin: 10px 0;
}

.add-to-cart {
    background: #28a745;
    color: white;
    padding: 10px 15px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    transition: background 0.3s ease-in-out;
}

.add-to-cart:hover {
    background: #218838;
}

/* Footer */
.footer {
    background-color: #007bff;
    color: white;
    padding: 10px 0;
    text-align: center;
    font-size: 14px;
}

.footer .top-bar {
    display: flex;
    justify-content: space-around;
    padding: 10px 0;
    border-bottom: 1px solid white;
}

.footer .container {
    max-width: 1200px;
    margin: auto;
    padding: 30px 10px;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
}

.footer-column {
    width: 22%;
    min-width: 200px;
    text-align: left;
}

.footer-column h3 {
    font-size: 16px;
    margin-bottom: 10px;
}

.footer-column p {
    font-size: 14px;
    color: white;
}

.footer-column ul {
    list-style: none;
    padding: 0;
}

.footer-column ul li {
    margin: 5px 0;
}

.footer-column ul li a {
    text-decoration: none;
    color: white;
    font-size: 14px;
    transition: 0.3s;
}

.footer-column ul li a:hover {
    color: #ffd700;
}

/* Social Icons */
.social-icons {
    display: flex;
    gap: 10px;
    margin-top: 10px;
}

.social-icons a {
    font-size: 20px;
    text-decoration: none;
    color: red;
    transition: color 0.3s;
}

.social-icons a:hover {
    color: darkred;
}

/* Newsletter */
.newsletter {
    display: flex;
    border: 1px solid #ddd;
    border-radius: 5px;
    overflow: hidden;
}

.newsletter input {
    width: 100%;
    padding: 8px;
    border: none;
    outline: none;
}

.newsletter button {
    background-color: red;
    color: white;
    border: none;
    padding: 8px;
    cursor: pointer;
}



    </style>
</head>
<body>
  <form id="form1" runat="server">
     


  <div class="header">
    <asp:Image ID="imgLogo" runat="server" ImageUrl="logo.webp" CssClass="logo" />
    
    <asp:Menu ID="MainMenu" runat="server" CssClass="menu" Orientation="Horizontal"
        StaticDisplayLevels="1" MaximumDynamicDisplayLevels="1">
        <Items>
            <asp:MenuItem Text="Home" NavigateUrl="UserDashboard.aspx" />
            <asp:MenuItem Text="Movies" NavigateUrl="Movies.aspx" />
            <asp:MenuItem Text="My Bookings" NavigateUrl="MyBookings.aspx" />
            
           <asp:MenuItem Text="Contact US" NavigateUrl="ContactUS.aspx" />
           <asp:MenuItem Text="Logout" NavigateUrl="AdminLogin.aspx" />

            
            
        </Items>
    </asp:Menu>
</div>

          
       
      
    <div class="container">
    <!-- Breadcrumb Navigation -->
    <div class="breadcrumb">
        <asp:Literal ID="lblBreadcrumb" runat="server"></asp:Literal>
    </div>

    <!-- Movie Details -->
    <div class="movie-details">
        <div class="movie-info">
            <h1 class="movie-title">
                <asp:Label ID="lblMovieName" runat="server" CssClass="title-text" />
                <span class="cast">
                    <asp:Label ID="lblCast" runat="server" CssClass="cast-text" />
                </span>
            </h1>
            <p class="category">Category: <asp:Label ID="lblCategory" runat="server" CssClass="category-text" /></p>
        </div>

        <!-- Movie Poster Image -->
        <div class="movie-image">
            <asp:Image ID="imgBanner" runat="server" CssClass="movie-img" />
        </div>

        <!-- Movie Description -->
        <div class="movie-description">
            <h3>Description</h3>
            <p><asp:Label ID="lblDescription" runat="server" CssClass="description-text" /></p>
        </div>

        <!-- Booking Section -->
        <div class="booking-section">
            
            <asp:Button ID="btnBook" runat="server" CssClass="book-btn" Text="Book Ticket" OnClick="btnBook_Click" />
        </div>
    </div>

    <!-- Error Message -->
    <div class="error-message">
        <asp:Label ID="lblError" runat="server" ForeColor="Red" />
    </div>
</div>









     <div class="footer">
    <!-- Top Bar with Movie Highlights -->
    <div class="top-bar">
        <asp:Label ID="Label1" runat="server" Text="🎥 Book Your Favorite Movies Now - Best Seats Available!"></asp:Label>
        <asp:Label ID="Label2" runat="server" Text="🍿 Enjoy Exclusive Combo Offers on Snacks & Drinks"></asp:Label>
        <asp:Label ID="Label3" runat="server" Text="💺 Recliner & VIP Seats Available for Premium Experience"></asp:Label>
        <asp:Label ID="Label4" runat="server" Text="🎬 Watch the Latest Blockbusters in Stunning 4K & IMAX"></asp:Label>
        <asp:Label ID="Label5" runat="server" Text="📱 Book Tickets Anytime, Anywhere with Our Mobile App!"></asp:Label>
    </div>

    <div class="container">
        <!-- Footer Logo & About -->
        <div class="footer-column">
            <asp:Image ID="imgFooterLogo" runat="server" ImageUrl="logo.webp" Width="150px" />
            <p>Welcome to CineStar Theater! Experience movies like never before with the best sound, visuals, and comfort. 🍿🎬</p>
        </div>

        <!-- Quick Links Section -->
        <div class="footer-column">
            <h3>QUICK LINKS</h3>
            <asp:BulletedList ID="blQuickLinks" runat="server">
                <asp:ListItem Text="Now Showing" Value="Movies.aspx" />
                <asp:ListItem Text="Upcoming Movies" Value="Upcoming.aspx" />
                <asp:ListItem Text="Book Tickets" Value="BookNow.aspx" />
                <asp:ListItem Text="Offers & Discounts" Value="Offers.aspx" />
            </asp:BulletedList>
        </div>

        <!-- Policies & Booking Terms -->
        <div class="footer-column">
            <h3>SECURITY & POLICIES</h3>
            <asp:BulletedList ID="blPolicies" runat="server">
                <asp:ListItem Text="Booking Terms & Conditions" Value="Terms.aspx" />
                <asp:ListItem Text="Cancellation Policy" Value="CancelPolicy.aspx" />
                <asp:ListItem Text="Privacy Policy" Value="Privacy.aspx" />
            </asp:BulletedList>
        </div>

        <!-- Contact & Newsletter -->
        <div class="footer-column">
            <h3>CONTACT US</h3>
            <p>📧 <asp:HyperLink ID="HyperLinkEmail" runat="server" style="color:White;" NavigateUrl="mailto:support@cinestartheater.com">support@cinestartheater.com</asp:HyperLink></p>
            <p>📞 <asp:HyperLink ID="HyperLinkPhone" runat="server" style="color:White;" NavigateUrl="tel:+919912345678">+91 99123 45678</asp:HyperLink></p>
            <p>📍 <strong>Address:</strong> CineStar Multiplex, MG Road, Mumbai, India</p>

            <h3>Subscribe for Movie Updates</h3>
            <asp:TextBox ID="txtEmail" runat="server" Placeholder="Enter your email"></asp:TextBox>
            <asp:Button ID="btnSubscribe" runat="server" Text="Subscribe" CssClass="subscribe-btn" />
        </div>
    </div>
</div>


    
     
    </form>
</body>
</html>

