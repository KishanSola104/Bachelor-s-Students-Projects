﻿using System;
using System.Configuration;
using System.Data.SqlClient;

public partial class AdminDashboard : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["AdminEmail"] == null)
        {
            Response.Redirect("AdminLogin.aspx");
        }
        else
        {
            LoadDashboardStats();
        }
    }

    private void LoadDashboardStats()
    {
        /*
        string connString = ConfigurationManager.ConnectionStrings["TheaterDBConnection"].ConnectionString;
        using (SqlConnection con = new SqlConnection(connString))
        {
            con.Open();
            SqlCommand cmdMovies = new SqlCommand("SELECT COUNT(*) FROM Movies", con);
            SqlCommand cmdShows = new SqlCommand("SELECT COUNT(*) FROM Shows", con);
            SqlCommand cmdBookings = new SqlCommand("SELECT COUNT(*) FROM Bookings", con);
            lblMovies.Text = cmdMovies.ExecuteScalar().ToString();
            lblShows.Text = cmdShows.ExecuteScalar().ToString();
            lblBookings.Text = cmdBookings.ExecuteScalar().ToString();
        }*/
    }

    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Redirect("AdminLogin.aspx");
    }
}
