﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="Checkout.aspx.cs" Inherits="Checkout" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Checkout</title>
    <style>
        .container { width: 50%; margin: auto; padding: 20px; border: 1px solid #ccc; border-radius: 10px; background: #f9f9f9; }
        .form-group { margin-bottom: 15px; }
        .form-label { font-weight: bold; }
        .total-price { font-size: 20px; font-weight: bold; color: red; }
    </style>
    <script>
        function updatePrice() {
            var seatType = document.getElementById('<%= ddlSeatType.ClientID %>').value;
            var seatCount = document.getElementById('<%= txtSeatCount.ClientID %>').value;
            var pricePerSeat = 0;

            if (seatType === "Gold") pricePerSeat = 500;
            else if (seatType === "Platinum") pricePerSeat = 700;
            else if (seatType === "Silver") pricePerSeat = 300;

            var totalPrice = pricePerSeat * seatCount;
            document.getElementById('<%= lblTotalPrice.ClientID %>').innerText = "₹ " + totalPrice;
        }
    </script>
</head>
<body>
<form runat="server">
    <div class="container">
        <h2>Movie Checkout</h2>
        <p>
            <asp:Label ID="lblMessage" runat="server"></asp:Label>
        </p>
        <asp:Label ID="lblMovieName" runat="server" Font-Bold="true" Font-Size="18px" />
        
        <div class="form-group">
            <label class="form-label">Select Seat Type:</label>
            <asp:DropDownList ID="ddlSeatType" runat="server" CssClass="form-control" AutoPostBack="true" OnSelectedIndexChanged="ddlSeatType_SelectedIndexChanged">
                <asp:ListItem Text="Gold - ₹500" Value="Gold" />
                <asp:ListItem Text="Platinum - ₹700" Value="Platinum" />
                <asp:ListItem Text="Silver - ₹300" Value="Silver" />
            </asp:DropDownList>
        </div>

        <div class="form-group">
            <label class="form-label">Number of Seats:</label>
            <asp:TextBox ID="txtSeatCount" runat="server" CssClass="form-control" Text="1" AutoPostBack="true" OnTextChanged="txtSeatCount_TextChanged" onkeyup="updatePrice()" />
        </div>

        <div class="form-group">
            <label class="form-label">Total Price:</label>
            <asp:Label ID="lblTotalPrice" runat="server" CssClass="total-price" />
        </div>

        <asp:Button ID="btnProceed" runat="server" CssClass="btn btn-primary" Text="Proceed to Payment" OnClick="btnProceed_Click" />
    </div>
    </form>
</body>
</html>