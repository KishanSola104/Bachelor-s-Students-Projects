﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="OrderConfirmation.aspx.cs" Inherits="OrderConfirmation" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>Order Confirmation</title>
    <style>
        .container { 
            width: 50%; 
            margin: auto; 
            padding: 20px; 
            border: 1px solid #ccc; 
            border-radius: 10px; 
            background: #f9f9f9; 
            text-align: center; 
        }
        .success { 
            color: green; 
            font-size: 22px; 
            font-weight: bold; 
        }
        .total-price { 
            font-size: 20px; 
            font-weight: bold; 
            color: red; 
        }
        .payment-status {
            font-size: 18px;
            font-weight: bold;
            color: blue;
        }
        .btn {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
        }
        .btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <form id="Form1" runat="server">
        <asp:Label ID="lblMessage" runat="server" ForeColor="Red"></asp:Label>
        
        <div class="container">
            <h2>Order Confirmation</h2>
            <p class="success">Your booking has been confirmed!</p>

            <div class="form-group">
                <label class="form-label">Movie:</label>
                <asp:Label ID="lblMovieName" runat="server" />
            </div>

            <div class="form-group">
                <label class="form-label">Seat Type:</label>
                <asp:Label ID="lblSeatType" runat="server" />
            </div>

            <div class="form-group">
                <label class="form-label">Number of Seats:</label>
                <asp:Label ID="lblSeatCount" runat="server" />
            </div>

            <div class="form-group">
                <label class="form-label">Total Price:</label>
                <asp:Label ID="lblTotalPrice" runat="server" CssClass="total-price" />
            </div>

            <div class="form-group">
                <label class="form-label">Payment Status:</label>
                <asp:Label ID="lblPaymentStatus" runat="server" CssClass="payment-status" />
            </div>

            <asp:Button ID="btnHome" runat="server" CssClass="btn" Text="Back to Home" OnClick="btnHome_Click" />
        </div>
    </form>
</body>
</html>