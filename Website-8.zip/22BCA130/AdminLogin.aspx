﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="AdminLogin.aspx.cs" Inherits="AdminLogin" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
<style>
        body { font-family: Arial, sans-serif; margin: 0; background-color: #f4f4f4; }
        .login-container { width: 350px; margin: 100px auto; padding: 20px; background: white; box-shadow: 0 0 10px rgba(0,0,0,0.1); text-align: center; }
        h2 { margin-bottom: 20px; }
        input[type="text"], input[type="password"] { width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ccc; }
        button { width: 100%; padding: 10px; background: red; color: white; border: none; cursor: pointer; }
        button:hover { background: darkred; }
        .error-message { color: red; margin-top: 10px; display: none; }
    </style>
</head>
<body>
<form runat="server">
    <div class="login-container">
        <h2>Admin Login</h2>
        <asp:TextBox ID="txtEmail" runat="server" placeholder="Enter Email"></asp:TextBox>
        <asp:TextBox ID="txtPassword" runat="server" TextMode="Password" placeholder="Enter Password"></asp:TextBox>
        <asp:Button ID="btnLogin" runat="server" Text="Login" OnClick="btnLogin_Click" />
        <asp:Label ID="lblError" runat="server" ForeColor="Red" Visible="False"></asp:Label>
    </div>
    </form>
</body>
</html>