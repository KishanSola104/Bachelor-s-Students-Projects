﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="AdminDashboard.aspx.cs" Inherits="AdminDashboard" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>Admin Dashboard - CineStar Theater</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body { font-family: Arial, sans-serif; margin: 0; background-color: #f4f4f4; }
        .container { display: flex; }
        .sidebar { width: 250px; background: #222; color: white; padding: 20px; height: 100vh; }
        .sidebar a { display: block; color: white; padding: 10px; text-decoration: none; }
        .sidebar a:hover { background: red; }
        .main-content { flex: 1; padding: 20px; }
        .header { background: red; padding: 15px; color: white; text-align: right; }
        .dashboard-cards { display: flex; gap: 20px; margin-top: 20px; }
        .card { background: white; padding: 20px; box-shadow: 0 0 10px rgba(0,0,0,0.1); flex: 1; text-align: center; }
        .footer { background: #222; color: white; text-align: center; padding: 10px; position: absolute; bottom: 0; width: 100%; }
    </style>
</head>
<body>
<form runat="server">
    <div class="header">
        Welcome, <asp:Label ID="lblAdminName" runat="server" /> | 
        <asp:Button ID="btnLogout" runat="server" Text="Logout" OnClick="btnLogout_Click" />
    </div>
    <div class="container">
        <div class="sidebar">
            <h2>Admin Panel</h2>
            <a href="ManageMovies.aspx">Manage Movies</a>
            <a href="ManageShows.aspx">Manage Shows</a>
            <a href="ManageBookings.aspx">Manage Bookings</a>
            <a href="ManageUsers.aspx">Manage Users</a>
        
        </div>
        <div class="main-content">
            <h2>Dashboard Overview</h2>
            <div class="dashboard-cards">
                <div class="card">Total Movies: <asp:Label ID="lblTotalMovies" runat="server" /></div>
                <div class="card">Total Shows: <asp:Label ID="lblTotalShows" runat="server" /></div>
                <div class="card">Total Bookings: <asp:Label ID="lblTotalBookings" runat="server" /></div>
                <div class="card">Total Users: <asp:Label ID="lblTotalUsers" runat="server" /></div>
            </div>
        </div>
    </div>
    <div class="footer">&copy; 2025 CineStar Theater - Admin Panel</div>
    </form>
</body>
</html>
