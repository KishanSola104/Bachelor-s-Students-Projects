﻿using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI;

public partial class OrderConfirmation : System.Web.UI.Page
{
    string connStr = ConfigurationManager.ConnectionStrings["TheaterBookingDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserEmail"] == null)
            {
                Response.Redirect("Login.aspx");
            }

            string userEmail = Session["UserEmail"].ToString();
            LoadOrderDetails(userEmail);
        }
    }

    private void LoadOrderDetails(string userEmail)
    {
        using (SqlConnection con = new SqlConnection(connStr))
        {
            try
            {
                string query = "SELECT TOP 1 o.SeatType, o.NumberOfSeats, o.TotalPrice, m.MovieName, o.PaymentStatus " +
                               "FROM Orders o INNER JOIN Movies m ON o.MovieID = m.MovieID " +
                               "WHERE o.UserEmail = @UserEmail ORDER BY o.OrderDate DESC";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@UserEmail", userEmail);
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        lblMovieName.Text = reader["MovieName"].ToString();
                        lblSeatType.Text = reader["SeatType"].ToString();
                        lblSeatCount.Text = reader["NumberOfSeats"].ToString();
                        lblTotalPrice.Text = "₹ " + reader["TotalPrice"].ToString();
                        lblPaymentStatus.Text = reader["PaymentStatus"].ToString();
                    }
                    else
                    {
                        lblMessage.Text = "No recent orders found.";
                    }
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = "Error loading order details. " + ex.Message;
            }
        }
    }
    protected void btnHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("UserDashboard.aspx");
    }
}
