﻿using System;
using System.Data.SqlClient;
using System.Configuration;


    public partial class ContactUS : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string name = txtName.Text.Trim();
            string email = txtEmail.Text.Trim();
            string subject = txtSubject.Text.Trim();
            string message = txtMessage.Text.Trim();

            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(email) ||
                string.IsNullOrEmpty(subject) || string.IsNullOrEmpty(message))
            {
                Response.Write("<script>alert('All fields are required!');</script>");
                return;
            }

            try
            {
                /*
                string connStr = ConfigurationManager.ConnectionStrings["TheaterBookingDB"].ConnectionString;
                using (SqlConnection conn = new SqlConnection(connStr))
                {
                    string query = "INSERT INTO ContactMessages (Name, Email, Subject, Message) VALUES (@Name, @Email, @Subject, @Message)";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Name", name);
                        cmd.Parameters.AddWithValue("@Email", email);
                        cmd.Parameters.AddWithValue("@Subject", subject);
                        cmd.Parameters.AddWithValue("@Message", message);

                        conn.Open();
                        cmd.ExecuteNonQuery();
                        conn.Close();

                        Response.Write("<script>alert('Your message has been sent successfully!');</script>");
                        txtName.Text = "";
                        txtEmail.Text = "";
                        txtSubject.Text = "";
                        txtMessage.Text = "";
                    }
                }*/
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('An error occurred: " + ex.Message + "');</script>");
            }
            finally
            {
                Response.Write("<script>alert('Your message has been sent successfully!');</script>");
            }
        }
    }

