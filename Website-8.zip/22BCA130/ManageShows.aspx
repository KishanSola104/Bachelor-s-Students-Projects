﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="ManageShows.aspx.cs" Inherits="ManageShows" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
   <title>Manage Shows  - CineStar Theater</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body { font-family: Arial, sans-serif; margin: 0; background-color: #f4f4f4; }
        .container { display: flex; }
        .sidebar { width: 200px; background: #222; color: white; padding: 20px; height: 1200px; }
        .sidebar a { display: block; color: white; padding: 10px; text-decoration: none; }
        .sidebar a:hover { background: red; }
        .main-content { flex: 1; padding: 20px; }
        .header { background: red; padding: 15px; color: white; text-align: right;}
        .dashboard-cards { display: flex; gap: 20px; margin-top: 20px; }
        .card { background: white; padding: 20px; box-shadow: 0 0 10px rgba(0,0,0,0.1); flex: 1; text-align: center; }
        .footer { background: #222; color: white; text-align: center; padding: 10px; position: relative; bottom: 0; width: 100%; }
        
        
        
        .main-content {
    width: 50%;
    margin: 20px;
    padding: 20px;
    border: 1px solid #ddd;
    border-radius: 5px;
    background-color: #f9f9f9;
}
label {
    font-weight: bold;
    display: block;
    margin-top: 10px;
}
input, select {
    width: 100%;
    padding: 8px;
    margin: 5px 0;
    border: 1px solid #ccc;
    border-radius: 4px;
}
button {
    background-color: #28a745;
    color: white;
    padding: 10px;
    border: none;
    cursor: pointer;
    margin-top: 10px;
}
button:hover {
    background-color: #218838;
}

    </style>
</head>
<body>
<form id="Form1" runat="server">
    <div class="header">
        Welcome, <asp:Label ID="lblAdminName" runat="server" /> | 
        <asp:Button ID="btnLogout" style="width:70px;" runat="server" Text="Logout" OnClick="btnLogout_Click" />
    </div>
    <div class="container">
        <div class="sidebar">
            <h2>Admin Panel</h2>
            <a href="ManageMovies.aspx">Manage Movies</a>
            <a href="ManageShows.aspx">Manage Shows</a>
            <a href="ManageBookings.aspx">Manage Bookings</a>
            <a href="ManageUsers.aspx">Manage Users</a>
        
        </div>
             <div class="main-content">
            <h2>Manage Shows</h2>
            <asp:Label ID="lblMessage" runat="server" ForeColor="Red"></asp:Label>
            
            <label>Select Movie ID:</label>
            <asp:DropDownList ID="ddlMovieID" runat="server"></asp:DropDownList>
            <br /><br />

            <label>Show ID:</label>
            <asp:TextBox ID="txtShowID" runat="server"></asp:TextBox>
            <br /><br />

            <label>Show Date:</label>
            <asp:TextBox ID="txtShowDate" runat="server"></asp:TextBox>
            <asp:Calendar ID="Calendar1" runat="server" OnSelectionChanged="Calendar1_SelectionChanged"></asp:Calendar>
            <br /><br />

            <label>Show Time:</label>
            <asp:TextBox ID="txtShowTime" runat="server" TextMode="Time"></asp:TextBox>
            <br /><br />

            <label>Screen No:</label>
            <asp:TextBox ID="txtScreenNo" runat="server"></asp:TextBox>
            <br /><br />

            <label>Ticket Price:</label>
            <asp:TextBox ID="txtTicketPrice" runat="server"></asp:TextBox>
            <br /><br />

            <asp:Button ID="btnAddShow" runat="server" Text="Add Show" OnClick="btnAddShow_Click" />
            
      
       <asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False" 
            CellPadding="4" DataKeyNames="ShowID" DataSourceID="SqlDataSource1" 
            ForeColor="#333333" GridLines="None">
            <AlternatingRowStyle BackColor="White" />
            <Columns>
                <asp:CommandField ShowDeleteButton="True" ShowEditButton="True" />
                <asp:BoundField DataField="ShowID" HeaderText="ShowID" ReadOnly="True" 
                    SortExpression="ShowID" />
                <asp:BoundField DataField="MovieID" HeaderText="MovieID" 
                    SortExpression="MovieID" />
                <asp:BoundField DataField="ShowDate" HeaderText="ShowDate" 
                    SortExpression="ShowDate" />
                <asp:BoundField DataField="ShowTime" HeaderText="ShowTime" 
                    SortExpression="ShowTime" />
                <asp:BoundField DataField="ScreenNo" HeaderText="ScreenNo" 
                    SortExpression="ScreenNo" />
                <asp:BoundField DataField="TicketPrice" HeaderText="TicketPrice" 
                    SortExpression="TicketPrice" />
            </Columns>
            <EditRowStyle BackColor="#2461BF" />
            <FooterStyle BackColor="#507CD1" Font-Bold="True" ForeColor="White" />
            <HeaderStyle BackColor="#507CD1" Font-Bold="True" ForeColor="White" />
            <PagerStyle BackColor="#2461BF" ForeColor="White" HorizontalAlign="Center" />
            <RowStyle BackColor="#EFF3FB" />
            <SelectedRowStyle BackColor="#D1DDF1" Font-Bold="True" ForeColor="#333333" />
            <SortedAscendingCellStyle BackColor="#F5F7FB" />
            <SortedAscendingHeaderStyle BackColor="#6D95E1" />
            <SortedDescendingCellStyle BackColor="#E9EBEF" />
            <SortedDescendingHeaderStyle BackColor="#4870BE" />
        </asp:GridView>

        <asp:SqlDataSource ID="SqlDataSource1" runat="server" 
            ConnectionString="<%$ ConnectionStrings:TheaterBookingDB %>" 
            DeleteCommand="DELETE FROM [Shows] WHERE [ShowID] = @ShowID" 
            InsertCommand="INSERT INTO [Shows] ([ShowID], [MovieID], [ShowDate], [ShowTime], [ScreenNo], [TicketPrice]) VALUES (@ShowID, @MovieID, @ShowDate, @ShowTime, @ScreenNo, @TicketPrice)" 
            SelectCommand="SELECT * FROM [Shows]" 
            UpdateCommand="UPDATE [Shows] SET [MovieID] = @MovieID, [ShowDate] = @ShowDate, [ShowTime] = @ShowTime, [ScreenNo] = @ScreenNo, [TicketPrice] = @TicketPrice WHERE [ShowID] = @ShowID">
            <DeleteParameters>
                <asp:Parameter Name="ShowID" Type="Int32" />
            </DeleteParameters>
            <InsertParameters>
                <asp:Parameter Name="ShowID" Type="Int32" />
                <asp:Parameter Name="MovieID" Type="Int32" />
                <asp:Parameter DbType="Date" Name="ShowDate" />
                <asp:Parameter DbType="Time" Name="ShowTime" />
                <asp:Parameter Name="ScreenNo" Type="Int32" />
                <asp:Parameter Name="TicketPrice" Type="Decimal" />
            </InsertParameters>
            <UpdateParameters>
                <asp:Parameter Name="MovieID" Type="Int32" />
                <asp:Parameter DbType="Date" Name="ShowDate" />
                <asp:Parameter DbType="Time" Name="ShowTime" />
                <asp:Parameter Name="ScreenNo" Type="Int32" />
                <asp:Parameter Name="TicketPrice" Type="Decimal" />
                <asp:Parameter Name="ShowID" Type="Int32" />
            </UpdateParameters>
        </asp:SqlDataSource>
       
        </div>
       
      
    </div>

      

    <div class="footer">&copy; 2025 CineStar Theater - Admin Panel</div>
    </form>
</body>
</html>

