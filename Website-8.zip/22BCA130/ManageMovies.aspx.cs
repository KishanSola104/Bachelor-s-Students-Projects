﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Web.UI.WebControls;


public partial class ManageMovies : System.Web.UI.Page
{
    string connStr = ConfigurationManager.ConnectionStrings["TheaterBookingDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadMovieIDs();
        }
    }

    private void LoadMovieIDs()
    {
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            string query = "SELECT MovieID FROM Movies";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataTable dt = new DataTable();
            da.Fill(dt);

            ddlMovieID.DataSource = dt;
            ddlMovieID.DataTextField = "MovieID";
            ddlMovieID.DataValueField = "MovieID";
            ddlMovieID.DataBind();

            ddlMovieID.Items.Insert(0, new ListItem("--Select Movie ID--", ""));
        }
    }

    protected void ddlMovieID_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlMovieID.SelectedIndex > 0)
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string query = "SELECT * FROM Movies WHERE MovieID = @MovieID";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@MovieID", ddlMovieID.SelectedValue);

                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    txtMovieID.Text = reader["MovieID"].ToString();
                    txtMovieName.Text = reader["MovieName"].ToString();
                    txtMovieCast.Text = reader["MovieCast"].ToString();
                    ddlCategory.SelectedValue = reader["MovieCategory"].ToString();
                    txtDescription.Text = reader["Description"].ToString();
                }
            }
        }
    }

    protected void btnAddMovie_Click(object sender, EventArgs e)
    {
        try
        {
            if (filePoster.HasFile)
            {
                string fileName = Path.GetFileName(filePoster.PostedFile.FileName);
                string filePath = "Images/" + fileName;
                filePoster.SaveAs(Server.MapPath(filePath));

                using (SqlConnection conn = new SqlConnection(connStr))
                {
                    string query = "INSERT INTO Movies (MovieID, MovieName, MovieCast, MovieCategory, Description, MoviePoster) VALUES (@MovieID, @MovieName, @MovieCast, @MovieCategory, @Description, @MoviePoster)";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@MovieID", txtMovieID.Text.Trim());
                    cmd.Parameters.AddWithValue("@MovieName", txtMovieName.Text.Trim());
                    cmd.Parameters.AddWithValue("@MovieCast", txtMovieCast.Text.Trim());
                    cmd.Parameters.AddWithValue("@MovieCategory", ddlCategory.SelectedValue);
                    cmd.Parameters.AddWithValue("@Description", txtDescription.Text.Trim());
                    cmd.Parameters.AddWithValue("@MoviePoster", filePath);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    lblMessage.Text = "Movie added successfully!";
                    lblMessage.ForeColor = System.Drawing.Color.Green;
                }
                LoadMovieIDs();
            }
            else
            {
                lblMessage.Text = "Please select a movie poster.";
            }
        }
        catch (Exception ex)
        {
            lblMessage.Text = "Error: " + ex.Message;
        }
    }

    protected void btnUpdateMovie_Click(object sender, EventArgs e)
    {
        try
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string query = "UPDATE Movies SET MovieName=@MovieName, MovieCast=@MovieCast, MovieCategory=@MovieCategory, Description=@Description WHERE MovieID=@MovieID";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@MovieID", txtMovieID.Text.Trim());
                cmd.Parameters.AddWithValue("@MovieName", txtMovieName.Text.Trim());
                cmd.Parameters.AddWithValue("@MovieCast", txtMovieCast.Text.Trim());
                cmd.Parameters.AddWithValue("@MovieCategory", ddlCategory.SelectedValue);
                cmd.Parameters.AddWithValue("@Description", txtDescription.Text.Trim());

                conn.Open();
                cmd.ExecuteNonQuery();
                lblMessage.Text = "Movie updated successfully!";
                lblMessage.ForeColor = System.Drawing.Color.Blue;
            }
        }
        catch (Exception ex)
        {
            lblMessage.Text = "Error: " + ex.Message;
        }
    }

    protected void btnDeleteMovie_Click(object sender, EventArgs e)
    {
        try
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string query = "DELETE FROM Movies WHERE MovieID=@MovieID";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@MovieID", txtMovieID.Text.Trim());

                conn.Open();
                cmd.ExecuteNonQuery();
                lblMessage.Text = "Movie deleted successfully!";
                lblMessage.ForeColor = System.Drawing.Color.Red;

                LoadMovieIDs();
            }
        }
        catch (Exception ex)
        {
            lblMessage.Text = "Error: " + ex.Message;
        }
    }
    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Response.Redirect("");
    }
}
