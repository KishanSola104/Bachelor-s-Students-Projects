﻿using System;
using System.Web.UI;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using System.Configuration;

public partial class UserDashboard : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            BindProducts();


            if (Session["UserEmail"] == null)
            {
                Response.Redirect("login.aspx");
            }
            else
            {
                // Label1.Text = "Welcome, " + Session["UserEmail"].ToString();
            }
        }
    }


    private void BindProducts()
    {
        string connectionString = ConfigurationManager.ConnectionStrings["TheaterBookingDB"].ConnectionString;

        using (SqlConnection con = new SqlConnection(connectionString))
        {
            try
            {
                con.Open();

                // Fetch 4 Namkeen products
                //string queryNamkeen = "SELECT TOP 4 Product_ID, Product_Name, Price, Image FROM Products WHERE Category = 'Collection' ORDER BY NEWID()";


                string queryAdventure = "SELECT TOP 4 MovieID, MovieName, MovieCast, MovieCategory, MoviePoster FROM Movies WHERE MovieCategory = 'Hindi' ORDER BY NEWID()";
                using (SqlCommand cmd = new SqlCommand(queryAdventure, con))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        DataTable dtAdventure = new DataTable();
                        sda.Fill(dtAdventure);
                        Repeater1.DataSource = dtAdventure;
                        Repeater1.DataBind();
                    }
                }


                // Fetch 4 Sweet products
                string querySweet = "SELECT TOP 4 MovieID, MovieName, MovieCast, MovieCategory, MoviePoster FROM Movies WHERE MovieCategory = 'South' ORDER BY NEWID()";
                using (SqlCommand cmd = new SqlCommand(querySweet, con))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        DataTable dtSweets = new DataTable();
                        sda.Fill(dtSweets);
                        Repeater2.DataSource = dtSweets;
                        Repeater2.DataBind();
                    }
                }

                // Fetch 4 Combo products
                string queryCombos = "SELECT TOP 4 MovieID, MovieName, MovieCast, MovieCategory, MoviePoster FROM Movies WHERE MovieCategory = 'English' ORDER BY NEWID()";
                using (SqlCommand cmd = new SqlCommand(queryCombos, con))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        DataTable dtCombos = new DataTable();
                        sda.Fill(dtCombos);
                        Repeater3.DataSource = dtCombos;
                        Repeater3.DataBind();
                    }
                }

            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('Error: " + ex.Message + "');</script>");
            }
        }
    }

    protected void btnBook_Click(object sender, EventArgs e)
    {
        Button btn = (Button)sender;  // Get the button that triggered the event
        string movieId = btn.CommandArgument; // Get the package ID

        // Redirect to the next page with the package ID in the URL
        Response.Redirect("Checkout.aspx?ID=" + movieId);
    }

   
}
