﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="MyBookings.aspx.cs" Inherits="MyBookings" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>My Bookings</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 80%;
            margin: auto;
            padding: 20px;
            background: white;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        h2 {
            text-align: center;
            color: #333;
        }
        .booking-card {
            display: flex;
            border: 1px solid #ddd;
            padding: 15px;
            margin: 15px 0;
            border-radius: 10px;
            background: #fff;
        }
        .poster img {
            width: 120px;
            height: 160px;
            border-radius: 5px;
        }
        .details {
            margin-left: 20px;
        }
        .details h3 {
            color: #007bff;
            margin: 0;
        }
        .details p {
            margin: 5px 0;
            font-size: 16px;
        }
        .payment-status {
            font-weight: bold;
            color: green;
        }
        .not-paid {
            color: red;
        }
        .cancel-btn {
            margin-top: 10px;
            background-color: red;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 5px;
            cursor: pointer;
        }
        .cancel-btn:hover {
            background-color: darkred;
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="container">
            <h2>My Bookings</h2>
            <asp:Label ID="lblMessage" runat="server" ForeColor="Red"></asp:Label>
            <asp:Repeater ID="rptBookings" runat="server" OnItemCommand="rptBookings_ItemCommand">
                <ItemTemplate>
                    <div class="booking-card">
                        <div class="poster">
                            <img src='<%# Eval("MoviePoster") %>' alt="Movie Poster" />
                        </div>
                        <div class="details">
                            <h3><%# Eval("MovieName") %></h3>
                            <p><strong>Seat Type:</strong> <%# Eval("SeatType") %></p>
                            <p><strong>Number of Seats:</strong> <%# Eval("NumberOfSeats") %></p>
                            <p><strong>Total Price:</strong> ₹ <%# Eval("TotalPrice") %></p>
                            <p><strong>Booking Date:</strong> <%# Eval("OrderDate") %></p>
                            <p><strong>Payment Status:</strong> 
                                <span class='<%# Eval("PaymentStatus").ToString() == "Paid" ? "payment-status" : "not-paid" %>'>
                                    <%# Eval("PaymentStatus") %>
                                </span>
                            </p>
                            <asp:Button ID="btnCancel" runat="server" CssClass="cancel-btn" CommandName="CancelBooking"
                                CommandArgument='<%# Eval("MovieID") %>' Text="Cancel Booking" OnClientClick="return confirm('Are you sure you want to cancel this booking?');" />
                        </div>
                    </div>
                </ItemTemplate>
            </asp:Repeater>
        </div>
    </form>
</body>
</html>