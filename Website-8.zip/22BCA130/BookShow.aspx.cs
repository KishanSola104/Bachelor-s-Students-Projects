﻿using System;
using System.Data.SqlClient;
using System.Configuration;

public partial class BookShow : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // Ensure user is logged in before loading movie details
        if (Session["UserEmail"] == null)
        {
            Response.Redirect("Login.aspx");
            return;
        }

        if (!IsPostBack)
        {
            string MovieID = Request.QueryString["ID"];
            if (!string.IsNullOrEmpty(MovieID))
            {
                LoadMovieDetails(MovieID);
            }
        }
    }

    private void LoadMovieDetails(string MovieID)
    {
        string connStr = ConfigurationManager.ConnectionStrings["TheaterBookingDB"].ConnectionString;
        using (SqlConnection con = new SqlConnection(connStr))
        {
            try
            {
                string query = "SELECT * FROM Movies WHERE MovieID = @MovieID";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@MovieID", MovieID);
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        // Movie Details
                        lblMovieName.Text = reader["MovieName"].ToString();
                        lblCast.Text = reader["MovieCast"].ToString();
                        lblCategory.Text = reader["MovieCategory"].ToString();
                        lblDescription.Text = reader["Description"].ToString();

                        // Movie Poster Image
                        string imagePath = reader["MoviePoster"].ToString();
                        imgBanner.ImageUrl = !string.IsNullOrEmpty(imagePath) ? ResolveUrl("~/" + imagePath) : ResolveUrl("~/Images/default.png");
                    }
                    else
                    {
                        lblMovieName.Text = "Movie Not Found!";
                    }
                }
            }
            catch (Exception ex)
            {
                lblError.Text = "Error loading movie details: " + ex.Message;
            }
        }
    }

    protected void btnBook_Click(object sender, EventArgs e)
    {
        string MovieID = Request.QueryString["ID"];
        if (!string.IsNullOrEmpty(MovieID))
        {
            Response.Redirect("Checkout.aspx?ID=" + MovieID);
        }
        else
        {
            lblError.Text = "Invalid Movie ID.";
        }
    }
}
