﻿using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI;

public partial class Payment : System.Web.UI.Page
{
    string connStr = ConfigurationManager.ConnectionStrings["TheaterBookingDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserEmail"] == null)
            {
                Response.Redirect("Login.aspx");
            }

            string userEmail = Session["UserEmail"].ToString();
            LoadOrderDetails(userEmail);
        }
    }

    private void LoadOrderDetails(string userEmail)
    {
        using (SqlConnection con = new SqlConnection(connStr))
        {
            try
            {
                string query = "SELECT TOP 1 o.SeatType, o.NumberOfSeats, o.TotalPrice, m.MovieName " +
                               "FROM Orders o INNER JOIN Movies m ON o.MovieID = m.MovieID " +
                               "WHERE o.UserEmail = @UserEmail ORDER BY o.OrderDate DESC";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@UserEmail", userEmail);
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        lblMovieName.Text = reader["MovieName"].ToString();
                        lblSeatType.Text = reader["SeatType"].ToString();
                        lblSeatCount.Text = reader["NumberOfSeats"].ToString();
                        lblTotalPrice.Text = "₹ " + reader["TotalPrice"].ToString();
                    }
                    else
                    {
                        lblMessage.Text = "No recent orders found.";
                    }
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = "Error loading order details. " + ex.Message;
            }
        }
    }

    protected void btnPay_Click(object sender, EventArgs e)
    {
        string userEmail = Session["UserEmail"].ToString();

        using (SqlConnection con = new SqlConnection(connStr))
        {
            try
            {
                string query = "UPDATE Orders SET PaymentStatus = 'Paid' WHERE UserEmail = @UserEmail AND PaymentStatus = 'Pending'";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@UserEmail", userEmail);
                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        Response.Redirect("OrderConfirmation.aspx?UserEmail=" + userEmail);
                    }
                    else
                    {
                        lblMessage.Text = "Error processing payment.";
                    }
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = "Payment processing failed. " + ex.Message;
            }
        }
    }
}
