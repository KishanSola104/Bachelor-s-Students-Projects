﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MyBookings : System.Web.UI.Page
{
    string connStr = ConfigurationManager.ConnectionStrings["TheaterBookingDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserEmail"] == null)
            {
                Response.Redirect("Login.aspx");
            }
            else
            {
                LoadUserBookings(Session["UserEmail"].ToString());
            }
        }
    }

    private void LoadUserBookings(string userEmail)
    {
        using (SqlConnection con = new SqlConnection(connStr))
        {
            try
            {
                string query = "SELECT m.MovieID, m.MovieName, m.MoviePoster, o.SeatType, o.NumberOfSeats, " +
                               "o.TotalPrice, o.OrderDate, o.PaymentStatus " +
                               "FROM Orders o " +
                               "INNER JOIN Movies m ON o.MovieID = m.MovieID " +
                               "WHERE o.UserEmail = @UserEmail " +
                               "ORDER BY o.OrderDate DESC";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@UserEmail", userEmail);
                    con.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        rptBookings.DataSource = dt;
                        rptBookings.DataBind();
                    }
                    else
                    {
                        lblMessage.Text = "You have no bookings yet.";
                    }
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = "Error loading bookings.";
            }
        }
    }

    protected void rptBookings_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName == "CancelBooking")
        {
            int movieId = Convert.ToInt32(e.CommandArgument);
            CancelBooking(movieId);
        }
    }

    private void CancelBooking(int movieId)
    {
        using (SqlConnection con = new SqlConnection(connStr))
        {
            try
            {
                string query = "DELETE FROM Orders WHERE MovieID = @MovieID AND UserEmail = @UserEmail";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@MovieID", movieId);
                    cmd.Parameters.AddWithValue("@UserEmail", Session["UserEmail"].ToString());
                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        lblMessage.Text = "Booking canceled successfully!";
                        LoadUserBookings(Session["UserEmail"].ToString()); // Refresh booking list
                    }
                    else
                    {
                        lblMessage.Text = "Failed to cancel the booking.";
                    }
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = "Error canceling booking.";
            }
        }
    }
}
