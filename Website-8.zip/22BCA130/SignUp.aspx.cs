﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.UI;

public partial class SignUp : System.Web.UI.Page
{
    string connStr = ConfigurationManager.ConnectionStrings["TheaterBookingDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        lblMessage.Text = "";
    }

    protected void btnSignUp_Click(object sender, EventArgs e)
    {
        if (txtPassword.Text != txtConfirmPassword.Text)
        {
            lblMessage.Text = "Passwords do not match!";
            return;
        }

        try
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                string query = "INSERT INTO Users (FullName, Email, Mobile, Password) VALUES (@FullName, @Email, @Mobile, @Password)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@FullName", txtFullName.Text.Trim());
                cmd.Parameters.AddWithValue("@Email", txtEmail.Text.Trim());
                cmd.Parameters.AddWithValue("@Mobile", txtMobile.Text.Trim());
                cmd.Parameters.AddWithValue("@Password", txtPassword.Text.Trim());

                cmd.ExecuteNonQuery();
                lblMessage.Text = "Registration Successful! Redirecting to Login...";
                Response.Redirect("Login.aspx");
            }
        }
        catch (SqlException ex)
        {
            if (ex.Number == 2627) // Unique constraint error
                lblMessage.Text = "Email already exists!";
            else
                lblMessage.Text = "Error: " + ex.Message;
        }
        catch (Exception ex)
        {
            lblMessage.Text = "Error: " + ex.Message;
        }
    }
}
