﻿using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI;

public partial class Checkout : System.Web.UI.Page
{
    string connStr = ConfigurationManager.ConnectionStrings["TheaterBookingDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserEmail"] == null)
            {
                Response.Redirect("Login.aspx");
            }

            string movieID = Request.QueryString["ID"];
            if (!string.IsNullOrEmpty(movieID))
            {
                LoadMovieDetails(movieID);
            }
            else
            {
                lblMessage.Text = "Invalid Movie ID.";
            }
        }
    }

    private void LoadMovieDetails(string movieID)
    {
        using (SqlConnection con = new SqlConnection(connStr))
        {
            try
            {
                string query = "SELECT MovieName FROM Movies WHERE MovieID = @MovieID";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@MovieID", movieID);
                    con.Open();

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            lblMovieName.Text = reader["MovieName"].ToString();
                        }
                        else
                        {
                            lblMovieName.Text = "Movie not found.";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = "Error loading movie details. " + ex.Message;
            }
        }
    }

    protected void ddlSeatType_SelectedIndexChanged(object sender, EventArgs e)
    {
        UpdateTotalPrice();
    }

    protected void txtSeatCount_TextChanged(object sender, EventArgs e)
    {
        UpdateTotalPrice();
    }

    private void UpdateTotalPrice()
    {
        int seatCount;
        if (!int.TryParse(txtSeatCount.Text, out seatCount) || seatCount <= 0)
        {
            lblMessage.Text = "Please enter a valid seat count.";
            return;
        }

        int pricePerSeat = 0;
        switch (ddlSeatType.SelectedValue)
        {
            case "Gold": pricePerSeat = 500; break;
            case "Platinum": pricePerSeat = 700; break;
            case "Silver": pricePerSeat = 300; break;
        }

        int totalPrice = pricePerSeat * seatCount;
        lblTotalPrice.Text = "₹ " + totalPrice;
    }

    protected void btnProceed_Click(object sender, EventArgs e)
    {
        string userEmail = (Session["UserEmail"] != null) ? Session["UserEmail"].ToString() : string.Empty;

        if (string.IsNullOrEmpty(userEmail))
        {
            Response.Redirect("Login.aspx");
            return;
        }

        string movieID = Request.QueryString["ID"];
        string seatType = ddlSeatType.SelectedValue;

        int seatCount;
        if (!int.TryParse(txtSeatCount.Text, out seatCount) || seatCount <= 0)
        {
            lblMessage.Text = "Please enter a valid number of seats.";
            return;
        }

        int pricePerSeat = 0;
        switch (seatType)
        {
            case "Gold": pricePerSeat = 500; break;
            case "Platinum": pricePerSeat = 700; break;
            case "Silver": pricePerSeat = 300; break;
        }

        int totalPrice = pricePerSeat * seatCount;

        using (SqlConnection con = new SqlConnection(connStr))
        {
            try
            {
                string query = "INSERT INTO Orders (UserEmail, MovieID, SeatType, NumberOfSeats, TotalPrice, PaymentStatus, OrderDate) " +
                               "VALUES (@UserEmail, @MovieID, @SeatType, @SeatCount, @TotalPrice, 'Pending', GETDATE())";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@UserEmail", userEmail);
                    cmd.Parameters.AddWithValue("@MovieID", movieID);
                    cmd.Parameters.AddWithValue("@SeatType", seatType);
                    cmd.Parameters.AddWithValue("@SeatCount", seatCount);
                    cmd.Parameters.AddWithValue("@TotalPrice", totalPrice);

                    con.Open();
                    cmd.ExecuteNonQuery();
                }

                // Get the last inserted order's UserEmail
                string lastOrderEmail = GetLastOrderEmail();
                if (!string.IsNullOrEmpty(lastOrderEmail))
                {
                    Response.Redirect("Payment.aspx?UserEmail=" + lastOrderEmail);
                }
                else
                {
                    lblMessage.Text = "Error processing order. Please try again.";
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = "Error while processing order. " + ex.Message;
            }
        }
    }

    private string GetLastOrderEmail()
    {
        using (SqlConnection con = new SqlConnection(connStr))
        {
            con.Open();
            using (SqlCommand cmd = new SqlCommand("SELECT TOP 1 UserEmail FROM Orders ORDER BY OrderDate DESC", con))
            {
                object result = cmd.ExecuteScalar();
                return (result != DBNull.Value && result != null) ? result.ToString() : string.Empty;
            }
        }
    }
}
