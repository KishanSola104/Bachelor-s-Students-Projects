﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="ManagePayment.aspx.cs" Inherits="ManagePayment" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
<title>Manage Payments</title>
 <style>
           body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    color: white;
    
    /* Background image */
   
    background-size: cover;
    height: 100vh; /* Ensures body covers full viewport height */
}

        .header {
            background: #004080;
            color: white;
            padding: 15px;
            text-align: center;
            position: relative;
        }
        .logout-btn {
            position: absolute;
            right: 20px;
            top: 15px;
            background: white;
            color: #004080;
            padding: 8px 15px;
            text-decoration: none;
            border-radius: 5px;
        }
        .logout-btn:hover {
            background: #ff4d4d;
            color: white;
        }
        .sidebar {
            width: 200px;
            background: #333;
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            padding-top: 60px;
        }
        .sidebar a {
            display: block;
            padding: 15px;
            color: white;
            text-decoration: none;
            border-bottom: 1px solid #555;
        }
        .sidebar a:hover {
            background: #575757;
        }
        .main-content {
            margin-left: 220px;
            padding: 20px;
        }
        .card {
            background: white;
            padding: 20px;
            margin: 20px 0;
            border-radius: 8px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
        }
        .footer {
            background: #222;
            color: white;
            text-align: center;
            padding: 15px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
    <style>
    /* Main Content Styling */
.main-content {
    width: 80%;
    margin: 20px auto;
    padding: 20px;
    background: #f8f9fa;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    margin-left:220px;
}

/* GridView Styling */
.GridViewStyle {
    width: 100%;
    border-collapse: collapse;
    font-family: Arial, sans-serif;
}

/* Table Header */
.GridViewStyle th {
    background: #343a40;
    color:White;
    padding: 12px;
    text-align: left;
    border-bottom: 2px solid #6c757d;
}

/* Table Rows */
.GridViewStyle td {
    padding: 10px;
    border-bottom: 1px solid #ddd;
    color:Black;
}

/* Alternate Row Color */
.GridViewStyle tr:nth-child(even) {
    background: #f2f2f2;
}

/* Hover Effect */
.GridViewStyle tr:hover {
    background: #d1e7dd;
    cursor: pointer;
}

/* Responsive Grid */
@media (max-width: 768px) {
    .main-content {
        width: 95%;
    }

    .GridViewStyle {
        font-size: 14px;
    }
}

    </style>
</head>
<body>
    <form id="form1" runat="server">
        <!-- Header Section -->
        <div class="header">
            <h2>Admin Dashboard</h2>
            <asp:Button ID="btnLogout" runat="server" Text="Logout" CssClass="logout-btn" OnClick="btnLogout_Click" />
        </div>

        <!-- Sidebar Navigation -->
        <!-- Sidebar Navigation -->
        <div class="sidebar">
            <a href="ManageStudents.aspx">Manage Students</a>
            <a href="ManageRooms.aspx">Manage Rooms</a>
              <a href="ManageEmployees.aspx">Manage Employees</a>
            <a href="ManagePayment.aspx">Manage Payments</a>
          <a href="ManageAnnouncements.aspx">Manage Announcements</a>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False" 
    CssClass="GridViewStyle" DataSourceID="SqlDataSource1">

                <Columns>
                    <asp:BoundField DataField="StudentEmail" HeaderText="StudentEmail" 
                        SortExpression="StudentEmail" />
                    <asp:BoundField DataField="RoomNumber" HeaderText="RoomNumber" 
                        SortExpression="RoomNumber" />
                    <asp:BoundField DataField="Amount" HeaderText="Amount" 
                        SortExpression="Amount" />
                    <asp:BoundField DataField="PaymentMethod" HeaderText="PaymentMethod" 
                        SortExpression="PaymentMethod" />
                    <asp:BoundField DataField="PaymentDate" HeaderText="PaymentDate" 
                        SortExpression="PaymentDate" />
                </Columns>
            </asp:GridView>
            <asp:SqlDataSource ID="SqlDataSource1" runat="server" 
                ConnectionString="<%$ ConnectionStrings:CollegeHostelDB %>" 
                SelectCommand="SELECT * FROM [Payment]"></asp:SqlDataSource>
        </div>

        <!-- Footer -->
        <div class="footer">
            <p>CES Girls Hostel - Admin Dashboard | Contact: ceshostel@gmail.com | +91-9876543210</p>
        </div>
    </form>
</body>
</html>