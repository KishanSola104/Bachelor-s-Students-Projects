﻿using System;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class AdminLogin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        string email = txtEmail.Text.Trim();
        string password = txtPassword.Text.Trim();

        // Ensure the connection string name matches the Web.config
        string connString = WebConfigurationManager.ConnectionStrings["CollegeHostelDB"].ConnectionString;

        using (SqlConnection conn = new SqlConnection(connString))
        {
            string query = "SELECT COUNT(*) FROM Admins WHERE Email=@Email AND Password=@Password";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@Email", email);
            cmd.Parameters.AddWithValue("@Password", password);

            conn.Open();
            int count = (int)cmd.ExecuteScalar();

            if (count > 0)
            {
                Session["AdminEmail"] = email;
                Response.Redirect("AdminDashboard.aspx");
            }
            else
            {
                lblMessage.Text = "Invalid email or password!";
            }
        }
    }
}
