﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Web.UI.WebControls;


public partial class ManageRooms : System.Web.UI.Page
{
    string connString = WebConfigurationManager.ConnectionStrings["CollegeHostelDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        // Check if admin is logged in
        if (Session["AdminEmail"] == null)
        {
            Response.Redirect("AdminLogin.aspx");
        }

        if (!IsPostBack)
        {
            LoadRooms();
        }
    }

    private void LoadRooms()
    {
        using (SqlConnection conn = new SqlConnection(connString))
        {
            string query = "SELECT * FROM Rooms";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            GridViewRooms.DataSource = dt;
            GridViewRooms.DataBind();
        }
    }



    
    private void ClearFields()
    {
        txtRoomNumber.Text = "";
        txtCapacity.Text = "";
        ddlRoomType.SelectedIndex = 0;
        ddlStatus.SelectedIndex = 0;
    }

    protected void GridViewRooms_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridViewRow row = GridViewRooms.SelectedRow;
        txtRoomNumber.Text = row.Cells[1].Text;
        ddlRoomType.SelectedValue = row.Cells[2].Text;
        txtCapacity.Text = row.Cells[3].Text;
        ddlStatus.SelectedValue = row.Cells[4].Text;
    }
    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminLogin.aspx");
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        using (SqlConnection conn = new SqlConnection(connString))
        {
            string query = "INSERT INTO Rooms (RoomNumber, RoomType, Capacity, Status) VALUES (@RoomNumber, @RoomType, @Capacity, @Status)";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@RoomNumber", txtRoomNumber.Text);
            cmd.Parameters.AddWithValue("@RoomType", ddlRoomType.SelectedValue);
            cmd.Parameters.AddWithValue("@Capacity", Convert.ToInt32(txtCapacity.Text));
            cmd.Parameters.AddWithValue("@Status", ddlStatus.SelectedValue);

            GridViewRooms.DataBind();
            conn.Open();
            cmd.ExecuteNonQuery();
        }
        LoadRooms();
        ClearFields();
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        using (SqlConnection conn = new SqlConnection(connString))
        {
            string query = "UPDATE Rooms SET RoomType=@RoomType, Capacity=@Capacity, Status=@Status WHERE RoomNumber=@RoomNumber";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@RoomNumber", txtRoomNumber.Text);
            cmd.Parameters.AddWithValue("@RoomType", ddlRoomType.SelectedValue);
            cmd.Parameters.AddWithValue("@Capacity", Convert.ToInt32(txtCapacity.Text));
            cmd.Parameters.AddWithValue("@Status", ddlStatus.SelectedValue);
            GridViewRooms.DataBind();
            conn.Open();
            cmd.ExecuteNonQuery();
        }
        LoadRooms();
        ClearFields();
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        using (SqlConnection conn = new SqlConnection(connString))
        {
            string query = "DELETE FROM Rooms WHERE RoomNumber=@RoomNumber";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@RoomNumber", txtRoomNumber.Text);
            GridViewRooms.DataBind();
            conn.Open();
            cmd.ExecuteNonQuery();
        }
        LoadRooms();
        ClearFields();
    }
    protected void GridViewRooms_SelectedIndexChanged1(object sender, EventArgs e)
    {
      
    }
    protected void ddlRoomNumber_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlRoomNumber.SelectedIndex > 0)
        {
            using (SqlConnection con = new SqlConnection(connString))
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("SELECT * FROM Rooms WHERE RoomNumber = @RoomNumber", con);
                    cmd.Parameters.AddWithValue("@RoomNumber", ddlRoomNumber.SelectedValue);
                    SqlDataReader dr = cmd.ExecuteReader();

                    if (dr.Read())
                    {
                        txtRoomNumber.Text = dr["RoomNumber"].ToString();
                        ddlRoomType.SelectedValue = dr["RoomType"].ToString();
                        txtCapacity.Text = dr["Capacity"].ToString();
                        ddlStatus.SelectedValue = dr["Status"].ToString();
                       // ddlOccupied.SelectedValue = dr["Occupied"].ToString();
                    }
                    dr.Close();
                }
                catch (Exception ex)
                {
                    // Handle exception
                }
            }
        
   
    }
    }
}
