﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="ManageAnnouncements.aspx.cs" Inherits="ManageAnnouncements" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Manage Announcements</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .header {
            background: #004080;
            color: white;
            padding: 15px;
            text-align: center;
            position: relative;
        }
        .logout-btn {
            position: absolute;
            right: 20px;
            top: 15px;
            background: white;
            color: #004080;
            padding: 8px 15px;
            text-decoration: none;
            border-radius: 5px;
        }
        .logout-btn:hover {
            background: #ff4d4d;
            color: white;
        }
        .sidebar {
            width: 200px;
            background: #333;
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            padding-top: 60px;
        }
        .sidebar a {
            display: block;
            padding: 15px;
            color: white;
            text-decoration: none;
            border-bottom: 1px solid #555;
        }
        .sidebar a:hover {
            background: #575757;
        }
        .main-content {
            margin-left: 220px;
            padding: 20px;
        }
        .card {
            background: white;
            padding: 20px;
            margin: 20px 0;
            border-radius: 8px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
        }
        .footer {
            background: #222;
            color: white;
            text-align: center;
            padding: 15px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
        
          body { font-family: Arial, sans-serif; background-color: #f4f4f4; }
        .container { width: 50%; margin: auto; background: white; padding: 20px; border-radius: 10px; }
        .form-group { margin-bottom: 15px; }
        .input-field { width: 100%; padding: 8px; }
        .btn { padding: 10px 15px; background: #007bff; color: white; border: none; cursor: pointer; }
        .table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        .table, th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <!-- Header Section -->
        <div class="header">
            <h2>Admin Dashboard</h2>
            <asp:Button ID="btnLogout" runat="server" Text="Logout" CssClass="logout-btn" OnClick="btnLogout_Click" />
        </div>

        <!-- Sidebar Navigation -->
        <div class="sidebar">
            <a href="ManageStudents.aspx">Manage Students</a>
            <a href="ManageRooms.aspx">Manage Rooms</a>
              <a href="ManageEmployees.aspx">Manage Employees</a>
            <a href="ManagePayment.aspx">Manage Payments</a>
          <a href="ManageAnnouncements.aspx">Manage Announcements</a>
        </div>

        <!-- Main Content -->
        <div class="main-content">
           <div class="container">
        <h2>Manage Announcements</h2>

         <div class="form-group">
            <label>Announcement ID:</label>
            <asp:TextBox ID="txtAnID" runat="server" CssClass="input-field"></asp:TextBox>
        </div>

        <div class="form-group">
            <label>Title:</label>
            <asp:TextBox ID="txtTitle" runat="server" CssClass="input-field"></asp:TextBox>
        </div>
        <div class="form-group">
            <label>Message:</label>
            <asp:TextBox ID="txtDescription" runat="server" CssClass="input-field" TextMode="MultiLine"></asp:TextBox>
        </div>
        <div class="form-group">
            <asp:Button ID="btnAdd" runat="server" Text="Add Announcement" CssClass="btn" OnClick="btnAdd_Click" />
            <asp:Button ID="btnUpdate" runat="server" Text="Update" CssClass="btn" OnClick="btnUpdate_Click" />
            <asp:Button ID="btnDelete" runat="server" Text="Delete" CssClass="btn" OnClick="btnDelete_Click" />
        </div>
        
        <h3>Announcements List</h3>
        <asp:GridView ID="GridViewAnnouncements" runat="server" AutoGenerateColumns="False" 
                   CssClass="table" 
               
                   DataKeyNames="AnnouncementID" DataSourceID="SqlDataSource1">
            <Columns>
                <asp:BoundField DataField="AnnouncementID" HeaderText="AnnouncementID" 
                    ReadOnly="True" SortExpression="AnnouncementID" />
                <asp:BoundField DataField="Title" HeaderText="Title" SortExpression="Title" />
                <asp:BoundField DataField="Description" HeaderText="Description" 
                    SortExpression="Description" />
                <asp:BoundField DataField="DatePosted" HeaderText="DatePosted" 
                    SortExpression="DatePosted" />
            </Columns>
        </asp:GridView>
               <asp:SqlDataSource ID="SqlDataSource1" runat="server" 
                   ConnectionString="<%$ ConnectionStrings:CollegeHostelDB %>" 
                   SelectCommand="SELECT * FROM [Announcements]"></asp:SqlDataSource>
    </div>
        </div>

        <!-- Footer -->
        <div class="footer">
            <p>CES Girls Hostel - Admin Dashboard | Contact: ceshostel@gmail.com | +91-9876543210</p>
        </div>
    </form>
</body>
</html>