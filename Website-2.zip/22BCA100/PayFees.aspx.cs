﻿using System;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class PayFees : System.Web.UI.Page
{
    string connString = WebConfigurationManager.ConnectionStrings["CollegeHostelDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserEmail"] == null)
            {
                Response.Redirect("StudentLogin.aspx");
            }
            LoadStudentDetails(Session["UserEmail"].ToString());
        }
    }

    private void LoadStudentDetails(string studentEmail)
    {
        using (SqlConnection conn = new SqlConnection(connString))
        {
            string query = "SELECT S.StudentName, S.Email, S.RoomNumber, P.PaymentDate, F.TotalFees, F.AmountPaid, F.DueAmount " +
                           "FROM Students S " +
                           "LEFT JOIN Payment P ON S.Email = P.StudentEmail " +
                           "LEFT JOIN Fees F ON S.Email = F.StudentEmail " +
                           "WHERE S.Email = @Email";

            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@Email", studentEmail);

            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                lblStudentName.Text = reader["StudentName"].ToString();
                lblEmail.Text = reader["Email"].ToString();
                lblRoomNumber.Text = reader["RoomNumber"].ToString();

                // If PaymentDate is NULL, show amount to be paid
                lblAmountDue.Text = reader["PaymentDate"] == DBNull.Value ? reader["TotalFees"].ToString() : "Paid";
            }
            conn.Close();
        }
    }

    protected void btnPay_Click(object sender, EventArgs e)
    {
        if (ddlPaymentMethod.SelectedValue == "")
        {
            Response.Write("<script>alert('Please select a payment method!');</script>");
            return;
        }

        using (SqlConnection conn = new SqlConnection(connString))
        {
            conn.Open();
            SqlTransaction transaction = conn.BeginTransaction(); // Start Transaction

            try
            {
                // Update Payment Table
                string updatePaymentQuery = "UPDATE Payment SET PaymentDate = @PaymentDate, PaymentMethod = @PaymentMethod " +
                                            "WHERE StudentEmail = @Email";
                SqlCommand cmdPayment = new SqlCommand(updatePaymentQuery, conn, transaction);
                cmdPayment.Parameters.AddWithValue("@Email", Session["UserEmail"].ToString());
                cmdPayment.Parameters.AddWithValue("@PaymentDate", DateTime.Now);
                cmdPayment.Parameters.AddWithValue("@PaymentMethod", ddlPaymentMethod.SelectedValue);
                int paymentRows = cmdPayment.ExecuteNonQuery();

                // Update Fees Table (Set Status to Paid)
                string updateFeesQuery = "UPDATE Fees SET Status = 'Paid', AmountPaid = TotalFees, DueAmount = 0 WHERE StudentEmail = @Email";
                SqlCommand cmdFees = new SqlCommand(updateFeesQuery, conn, transaction);
                cmdFees.Parameters.AddWithValue("@Email", Session["UserEmail"].ToString());
                int feesRows = cmdFees.ExecuteNonQuery();

               
                    transaction.Commit();
                    Response.Write("<script>alert('Payment Successful!');</script>");

                    // Retrieve payment details for Bill Slip
                    string roomNumber = lblRoomNumber.Text;
                    string amountPaid = "3000"; // You can dynamically fetch this from Fees table

                    // Redirect to BillSlip.aspx with Payment Details
                    Response.Redirect("BillSlip.aspx?RoomNumber=" + roomNumber + "&Amount=" + amountPaid + "&Method=" + ddlPaymentMethod.SelectedValue);
                
              
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                Response.Write("<script>alert('Error: " + ex.Message + "');</script>");
            }
        }
    }
    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Response.Redirect("StudentLogin.aspx");
    }
}
