﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="ManageEmployees.aspx.cs" Inherits="ManageEmployees" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<script runat="server">

  
   
</script>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Manage Employees</title>
  <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .header {
            background: #004080;
            color: white;
            padding: 15px;
            text-align: center;
            position: relative;
        }
        .logout-btn {
            position: absolute;
            right: 20px;
            top: 15px;
            background: white;
            color: #004080;
            padding: 8px 15px;
            text-decoration: none;
            border-radius: 5px;
        }
        .logout-btn:hover {
            background: #ff4d4d;
            color: white;
        }
        .sidebar {
            width: 200px;
            background: #333;
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            padding-top: 60px;
        }
        .sidebar a {
            display: block;
            padding: 15px;
            color: white;
            text-decoration: none;
            border-bottom: 1px solid #555;
        }
        .sidebar a:hover {
            background: #575757;
        }
        .main-content {
            margin-left: 220px;
            padding: 20px;
        }
        .card {
            background: white;
            padding: 20px;
            margin: 20px 0;
            border-radius: 8px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
        }
        .footer {
            background: #222;
            color: white;
            text-align: center;
            padding: 15px;
            position: relative;
            bottom: 0;
            width: 100%;
        }
    </style>

    <style>
    /* General Styles */
body {
    font-family: Arial, sans-serif;
    background-color: #f5f5f5;
    margin: 0;
    padding: 0;
}

/* Main Content */
.main-content {
    padding: 20px;
}

/* Container */
.container {
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    max-width: 600px;
    margin: auto;
}

/* Headings */
h2, h3 {
    color: #333;
    text-align: center;
}

/* Form Groups */
.form-group {
    margin-bottom: 15px;
}

label {
    font-weight: bold;
    display: block;
    margin-bottom: 5px;
}

/* Input Fields & Dropdown */
.input-field {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 16px;
}

/* Buttons */
.btn {
    width: 32%;
    padding: 10px;
    border: none;
    border-radius: 5px;
    font-size: 16px;
    cursor: pointer;
    margin-right: 5px;
    color: #fff;
}

#btnAdd {
    background-color: #28a745;
}

#btnUpdate {
    background-color: #007bff;
}

#btnDelete {
    background-color: #dc3545;
}

.btn:hover {
    opacity: 0.9;
}

/* GridView Table */
.table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 15px;
}

.table th, .table td {
    border: 1px solid #ddd;
    padding: 8px;
    text-align: center;
}

.table th {
    background-color: #007bff;
    color: white;
}

.table tr:nth-child(even) {
    background-color: #f2f2f2;
}

/* Responsive Design */
@media screen and (max-width: 600px) {
    .container {
        padding: 15px;
    }

    .btn {
        width: 100%;
        margin-bottom: 10px;
    }
}

    </style>
</head>
<body>
    <form id="form1" runat="server">
        <!-- Header Section -->
        <div class="header">
            <h2>Admin Dashboard</h2>
            <asp:Button ID="btnLogout" runat="server" Text="Logout" CssClass="logout-btn" OnClick="btnLogout_Click" />
        </div>

        <!-- Sidebar Navigation -->
        <!-- Sidebar Navigation -->
        <div class="sidebar">
            <a href="ManageStudents.aspx">Manage Students</a>
            <a href="ManageRooms.aspx">Manage Rooms</a>
              <a href="ManageEmployees.aspx">Manage Employees</a>
            <a href="ManagePayment.aspx">Manage Payments</a>
          <a href="ManageAnnouncements.aspx">Manage Announcements</a>
        </div>

        <!-- Main Content -->
        <div class="main-content">
               <h2>Manage Employees</h2>
               <p>
                   <asp:Label ID="Label1" runat="server" ForeColor="#FF6600"></asp:Label>
               </p>

        <!-- Dropdown to Select Employee -->
        <div class="form-group">
            <label for="ddlEmployee">Select Employee:</label>
            <asp:DropDownList ID="ddlEmployee" runat="server" CssClass="input-field"
                AutoPostBack="True" OnSelectedIndexChanged="ddlEmployee_SelectedIndexChanged"
                DataSourceID="SqlDataSource1" DataTextField="EmployeeName"
                DataValueField="EmployeeID">
            </asp:DropDownList>
            <asp:SqlDataSource ID="SqlDataSource1" runat="server"
                ConnectionString="<%$ ConnectionStrings:CollegeHostelDB %>"
                SelectCommand="SELECT [EmployeeID], [EmployeeName] FROM [Employees]">
            </asp:SqlDataSource>
        </div>

        <!-- Employee Form -->
        <div class="form-group">
            <label for="txtEmployeeName">Enter Employee ID:</label>
            <asp:TextBox ID="txtEmployeeID" runat="server" CssClass="input-field" required="required"></asp:TextBox>
        </div>

        <div class="form-group">
            <label for="txtEmployeeName">Employee Name:</label>
            <asp:TextBox ID="txtEmployeeName" runat="server" CssClass="input-field" required="required"></asp:TextBox>
        </div>
        <div class="form-group">
            <label for="txtPosition">Position:</label>
            <asp:TextBox ID="txtPosition" runat="server" CssClass="input-field" required="required"></asp:TextBox>
        </div>
        <div class="form-group">
            <label for="txtDepartment">Department:</label>
            <asp:TextBox ID="txtDepartment" runat="server" CssClass="input-field" required="required"></asp:TextBox>
        </div>
        <div class="form-group">
            <label for="txtContact">Contact:</label>
            <asp:TextBox ID="txtContact" runat="server" CssClass="input-field" required="required"></asp:TextBox>
        </div>
        <div class="form-group">
            <label for="ddlStatus">Status:</label>
            <asp:DropDownList ID="ddlStatus" runat="server" CssClass="input-field">
                <asp:ListItem Value="Active">Active</asp:ListItem>
                <asp:ListItem Value="Inactive">Inactive</asp:ListItem>
            </asp:DropDownList>
        </div>

        <!-- Buttons -->
        <div class="form-group">
            <asp:Button ID="btnAdd" runat="server" Text="Add Employee" CssClass="btn" OnClick="btnAdd_Click" />
            <asp:Button ID="btnUpdate" runat="server" Text="Update Employee" CssClass="btn" OnClick="btnUpdate_Click" />
            <asp:Button ID="btnDelete" runat="server" Text="Delete Employee" CssClass="btn btn-delete" OnClick="btnDelete_Click" />
        </div>

        <!-- Employee List -->
        <h3>Employee List</h3>
        <asp:GridView ID="GridViewEmployees" runat="server" AutoGenerateColumns="False" 
                   CssClass="table" DataKeyNames="EmployeeID" DataSourceID="SqlDataSource2">
            <Columns>
                <asp:BoundField DataField="EmployeeID" HeaderText="EmployeeID" ReadOnly="True" 
                    SortExpression="EmployeeID" />
                <asp:BoundField DataField="EmployeeName" HeaderText="EmployeeName" 
                    SortExpression="EmployeeName" />
                <asp:BoundField DataField="Position" HeaderText="Position" 
                    SortExpression="Position" />
                <asp:BoundField DataField="Department" HeaderText="Department" 
                    SortExpression="Department" />
                <asp:BoundField DataField="Contact" HeaderText="Contact" 
                    SortExpression="Contact" />
                <asp:BoundField DataField="Status" HeaderText="Status" 
                    SortExpression="Status" />
            </Columns>
        </asp:GridView>
               <asp:SqlDataSource ID="SqlDataSource2" runat="server" 
                   ConnectionString="<%$ ConnectionStrings:CollegeHostelDB %>" 
                   SelectCommand="SELECT * FROM [Employees]"></asp:SqlDataSource>
    </div>
        </div>

        <!-- Footer -->
        <div class="footer">
            <p>CES Girls Hostel - Admin Dashboard | Contact: ceshostel@gmail.com | +91-9876543210</p>
        </div>
    </form>
</body>
</html>