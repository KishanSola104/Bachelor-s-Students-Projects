﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="StudentDashboard.aspx.cs" Inherits="StudentDashboard" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>Student Dashboard</title>
    <style>
      body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    color: white;
    
    /* Background image */
    background: url('images/img3.jpg') no-repeat center center fixed;
    background-size: cover;
    height: 100vh; /* Ensures body covers full viewport height */
}

        .header {
            background: #007bff;
            color: white;
            padding: 20px;
            text-align: center;
            font-size: 22px;
        }
        .sidebar {
            width: 250px;
            height: 100vh;
            background: #333;
            color: white;
            position: fixed;
            padding-top: 20px;
        }
        .sidebar a {
            display: block;
            color: white;
            padding: 15px;
            text-decoration: none;
            transition: 0.3s;
           
        }
        .sidebar a:hover {
            background: #575757;
        }
        .content {
            margin-left: 260px;
            padding: 20px;
          
        }
        .logout-btn {
            background: #dc3545;
            color: white;
            padding: 10px 15px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            position: absolute;
            right: 20px;
            top: 15px;
        }
    </style>
    <style>
        .notice-section, .facility-section, .rules-section {
    background: rgba(255, 255, 255, 0.1);
    padding: 5px;
    border-radius: 10px;
    margin-top: 10px;
}

h3 {
    color: #ffcc00;
    border-bottom: 2px solid #ffcc00;
    padding-bottom: 5px;
}

ul {
    list-style-type: none;
    padding: 0;
}

ul li {
    margin: 8px 0;
    font-size: 16px;
}

    </style>
</head>
<body>
<form runat="server">
    <div class="header">
        Welcome, <asp:Label ID="lblStudentName" runat="server" Text="Student"></asp:Label>  
        <asp:Button ID="btnLogout" runat="server" Text="Logout" CssClass="logout-btn" OnClick="btnLogout_Click" />
    </div>

    <div class="sidebar">
        <a href="BookRoom.aspx"> Book a Room</a>
        <a href="PayFees.aspx"> Pay Fees</a>
        <a href="Announce.aspx"> Announcements</a>
        <a href="StudProfile.aspx"> Profile</a>
    </div>

  <div class="content">
    <h2>Student Dashboard</h2>
    <p>Welcome to CES Hostel Student Portal. Use the menu to navigate.</p>

    <!-- Important Notices -->
    <div class="notice-section">
        <h3> Important Notices</h3>
        <ul>
            <li> Hostel gates will be locked at **10:00 PM** daily.</li>
            <li> Visitors are only allowed **between 4:00 PM - 7:00 PM**.</li>
            <li> Room inspections will be conducted every **Monday & Thursday**.</li>
            <li> Mess fees must be cleared **by the 10th of each month**.</li>
        </ul>
    </div>

    <!-- Hostel Facilities -->
    <div class="facility-section">
        <h3>Hostel Facilities</h3>
        <ul>
            <li> **24/7 Security & CCTV Surveillance**</li>
            <li> **High-Speed WiFi** available in all rooms</li>
            <li> **Laundry & Housekeeping Services**</li>
            <li> **Mess with Nutritious Meals** (Veg & Non-Veg options)</li>
            <li> **Reading Room & Study Hall**</li>
            <li> **Medical Assistance Available 24/7**</li>
        </ul>
    </div>

    <!-- Rules & Regulations -->
    <div class="rules-section">
        <h3>Rules & Regulations</h3>
        <ul>
            <li> **No loud music or disturbances after 9:00 PM**.</li>
            <li> **Smoking, alcohol, and drugs are strictly prohibited**.</li>
            <li> **Students must inform warden before leaving the hostel overnight**.</li>
            <li> **Maintaining cleanliness in rooms and common areas is mandatory**.</li>
            
        </ul>
    </div>
</div>





    </form>
</body>
</html>