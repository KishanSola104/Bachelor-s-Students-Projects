﻿using System;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class StudentSignUp : System.Web.UI.Page
{
    protected void btnSignUp_Click(object sender, EventArgs e)
    {
        string connString = WebConfigurationManager.ConnectionStrings["CollegeHostelDB"].ConnectionString;
        using (SqlConnection conn = new SqlConnection(connString))
        {
            string query = "INSERT INTO Users (StudentID,FullName, Email, Mobile, State, City, Address, Password) " +
                           "VALUES (@ID,@FullName, @Email, @Mobile, @State, @City, @Address, @Password)";

            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@ID",txtID.Text);
            cmd.Parameters.AddWithValue("@FullName", txtFullName.Text);
            cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
            cmd.Parameters.AddWithValue("@Mobile", txtMobile.Text);
            cmd.Parameters.AddWithValue("@State", ddlState.SelectedValue);
            cmd.Parameters.AddWithValue("@City", txtCity.Text);
            cmd.Parameters.AddWithValue("@Address", txtAddress.Text);
            cmd.Parameters.AddWithValue("@Password", txtPassword.Text);

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();

            Response.Write("<script>alert('Registration successful! Please login.');window.location='StudentLogin.aspx';</script>");
        }
    }
}
