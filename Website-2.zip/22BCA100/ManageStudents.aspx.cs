﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Web.UI.WebControls;


public partial class ManageStudents : System.Web.UI.Page
{
    string connString = WebConfigurationManager.ConnectionStrings["CollegeHostelDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        // Check if admin is logged in
        if (Session["AdminEmail"] == null)
        {
            Response.Redirect("AdminLogin.aspx");
        }

        if (!IsPostBack)
        {
            LoadStudentsDropdown();
            LoadRoomsDropdown();
        }
    }

    private void LoadStudentsDropdown()
    {
        ddlStudent.Items.Clear();
        using (SqlConnection conn = new SqlConnection(connString))
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("SELECT StudentID, StudentName FROM Students", conn);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                ddlStudent.Items.Add(new ListItem(dr["StudentName"].ToString(), dr["StudentID"].ToString()));
            }
            dr.Close();
        }
    }

    private void LoadRoomsDropdown()
    {
        ddlRoom.Items.Clear();
        using (SqlConnection conn = new SqlConnection(connString))
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("SELECT RoomNumber FROM Rooms WHERE Status = 'Available'", conn);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                ddlRoom.Items.Add(new ListItem(dr["RoomNumber"].ToString(), dr["RoomNumber"].ToString()));
            }
            dr.Close();
        }
    }

    protected void ddlStudent_SelectedIndexChanged(object sender, EventArgs e)
    {
        using (SqlConnection conn = new SqlConnection(connString))
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Students WHERE StudentID = @StudentID", conn);
            cmd.Parameters.AddWithValue("@StudentID", ddlStudent.SelectedValue);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                txtStudentID.Text=dr["StudentID"].ToString();
                txtStudentName.Text = dr["StudentName"].ToString();
                txtEmail.Text = dr["Email"].ToString();
                txtMobile.Text = dr["Mobile"].ToString();
                ddlRoom.SelectedValue = dr["RoomNumber"].ToString();
            }
            dr.Close();
        }
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        using (SqlConnection conn = new SqlConnection(connString))
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("INSERT INTO Students (StudentID,StudentName, Email, Mobile, RoomNumber) VALUES (@ID,@Name, @Email, @Mobile, @Room)", conn);
            cmd.Parameters.Add("@ID",txtStudentID.Text);
            cmd.Parameters.AddWithValue("@Name", txtStudentName.Text);
            cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
            cmd.Parameters.AddWithValue("@Mobile", txtMobile.Text);
            cmd.Parameters.AddWithValue("@Room", ddlRoom.SelectedValue);
            cmd.ExecuteNonQuery();
        }
        LoadStudentsDropdown();
        Label1.Text = "Student Added ";
        GridViewStudents.Visible = true;
        GridViewStudents.DataBind();
        ClearFields();
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        using (SqlConnection conn = new SqlConnection(connString))
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("UPDATE Students SET StudentName=@Name, Email=@Email, Mobile=@Mobile, RoomNumber=@Room WHERE StudentID=@StudentID", conn);
            cmd.Parameters.AddWithValue("@StudentID", txtStudentID.Text);
            cmd.Parameters.AddWithValue("@Name", txtStudentName.Text);
            cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
            cmd.Parameters.AddWithValue("@Mobile", txtMobile.Text);
            cmd.Parameters.AddWithValue("@Room", ddlRoom.SelectedValue);
            cmd.ExecuteNonQuery();
            GridViewStudents.DataBind();
        }
        LoadStudentsDropdown();
        ClearFields();
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        using (SqlConnection conn = new SqlConnection(connString))
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("DELETE FROM Students WHERE StudentID=@StudentID", conn);
            cmd.Parameters.AddWithValue("@StudentID", txtStudentID.Text);
            cmd.ExecuteNonQuery();
            GridViewStudents.DataBind();
        }
        LoadStudentsDropdown();
        ClearFields();
    }

    private void ClearFields()
    {
        txtStudentName.Text = "";
        txtEmail.Text = "";
        txtMobile.Text = "";
        ddlRoom.SelectedIndex = 0;
    }
    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminLogin.aspx");
    }
}
