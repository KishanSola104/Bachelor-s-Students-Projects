﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class StudProfile : System.Web.UI.Page  // ✅ Changed class name from Profile to StudentProfile
{
    string connString = WebConfigurationManager.ConnectionStrings["CollegeHostelDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserEmail"] != null)
            {
                LoadStudentProfile(Session["UserEmail"].ToString());
            }
            else
            {
                Response.Redirect("StudentLogin.aspx"); // Redirect to login if not logged in
            }
        }
    }

    private void LoadStudentProfile(string studentEmail)
    {
        using (SqlConnection conn = new SqlConnection(connString))
        {
            string query = @"
            SELECT s.StudentName, s.Email, s.Mobile, 
                   r.RoomNumber, r.RoomType, 
                   f.TotalFees, f.AmountPaid, f.DueAmount, 
                   (CASE WHEN f.DueAmount <= 0 THEN 'Paid' ELSE 'Pending' END) AS FeesStatus
            FROM Students s
            LEFT JOIN Rooms r ON s.RoomNumber= r.RoomNumber
            LEFT JOIN Fees f ON s.StudentID = f.StudentID
            WHERE s.Email = @Email";

            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@Email", studentEmail);

            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                lblName.Text = reader["StudentName"].ToString();
                lblEmail.Text = reader["Email"].ToString();
                lblMobile.Text = reader["Mobile"].ToString();
             //   lblAddress.Text = reader["Address"].ToString();
                lblRoomNumber.Text = reader["RoomNumber"].ToString();
                lblRoomType.Text = reader["RoomType"].ToString();

                // Display Fees Details
                lblTotalFees.Text = reader["TotalFees"] != DBNull.Value ? "₹" + reader["TotalFees"].ToString() : "N/A";
                lblAmountPaid.Text = reader["AmountPaid"] != DBNull.Value ? "₹" + reader["AmountPaid"].ToString() : "N/A";
                lblDueAmount.Text = reader["DueAmount"] != DBNull.Value ? "₹" + reader["DueAmount"].ToString() : "N/A";
                lblFeesStatus.Text = reader["FeesStatus"].ToString();
            }
            conn.Close();
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        using (SqlConnection conn = new SqlConnection(connString))
        {
            string query = "UPDATE Students SET Mobile = @Mobile WHERE Email = @Email";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@Mobile", txtMobile.Text);
          
            cmd.Parameters.AddWithValue("@Email", Session["UserEmail"].ToString());

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();

            Response.Write("<script>alert('Profile Updated Successfully');</script>");
            LoadStudentProfile(Session["UserEmail"].ToString()); // Reload updated profile details
        }
    }


    // Logout User
    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Redirect("StudentLogin.aspx");
    }
}
