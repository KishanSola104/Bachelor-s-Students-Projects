﻿using System;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class StudentDashboard : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserEmail"] == null)
        {
            Response.Redirect("StudentLogin.aspx");
        }
        else
        {
            LoadStudentName();
        }
    }

    private void LoadStudentName()
    {
        string connString = WebConfigurationManager.ConnectionStrings["CollegeHostelDB"].ConnectionString;
        using (SqlConnection conn = new SqlConnection(connString))
        {
            string query = "SELECT FullName FROM Users WHERE Email=@Email";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@Email", Session["UserEmail"].ToString());

            conn.Open();
            object result = cmd.ExecuteScalar();
            conn.Close();

            if (result != null)
            {
                lblStudentName.Text = result.ToString();
            }
        }
    }

    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Response.Redirect("StudentLogin.aspx");
    }
}
