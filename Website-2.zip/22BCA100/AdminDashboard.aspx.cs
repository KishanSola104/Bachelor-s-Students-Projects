﻿using System;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class AdminDashboard : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // Check if admin is logged in
        if (Session["AdminEmail"] == null)
        {
            Response.Redirect("AdminLogin.aspx");
        }

        if (!IsPostBack)
        {
            LoadDashboardData();
        }
    }

    private void LoadDashboardData()
    {
        string connString = WebConfigurationManager.ConnectionStrings["CollegeHostelDB"].ConnectionString;

        using (SqlConnection conn = new SqlConnection(connString))
        {
            conn.Open();
            
                        // Get total students
                        using (SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM Students", conn))
                        {
                            lblTotalStudents.Text = cmd.ExecuteScalar().ToString();
                        }
              
                
             using (SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM Employees", conn))
                        {
                            lblEmployees.Text = cmd.ExecuteScalar().ToString();
                        }

                        // Get available rooms
                        using (SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM Rooms WHERE Status='Available'", conn))
                        {
                            lblAvailableRooms.Text = cmd.ExecuteScalar().ToString();
                        }

                      
        }
    }

    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session["AdminEmail"] = null;
        Response.Redirect("AdminLogin.aspx");
    }
}
