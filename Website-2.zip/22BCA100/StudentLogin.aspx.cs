﻿using System;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class StudentLogin : System.Web.UI.Page
{
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        string connString = WebConfigurationManager.ConnectionStrings["CollegeHostelDB"].ConnectionString;
        using (SqlConnection conn = new SqlConnection(connString))
        {
            string query = "SELECT Email FROM Users WHERE Email=@Email AND Password=@Password";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
            cmd.Parameters.AddWithValue("@Password", txtPassword.Text);

            conn.Open();
            object result = cmd.ExecuteScalar();
            conn.Close();

            if (result != null)
            {
                // Store student email in session
                Session["UserEmail"] = txtEmail.Text;

                // Redirect to Student Dashboard
                Response.Redirect("StudentDashboard.aspx");
            }
            else
            {
                Response.Write("<script>alert('Invalid email or password!');</script>");
            }
        }
    }
}
