﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Web.UI.WebControls;

public partial class ManageEmployees : System.Web.UI.Page
{
    string connString = WebConfigurationManager.ConnectionStrings["CollegeHostelDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
       

        // Check if admin is logged in
        if (Session["AdminEmail"] == null)
        {
            Response.Redirect("AdminLogin.aspx");
        }

        if (!IsPostBack)
        {
            LoadEmployeesDropdown();
        }
    }

    private void LoadEmployeesDropdown()
    {
        ddlEmployee.Items.Clear();
        using (SqlConnection conn = new SqlConnection(connString))
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("SELECT EmployeeID, EmployeeName FROM Employees", conn);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                ddlEmployee.Items.Add(new ListItem(dr["EmployeeName"].ToString(), dr["EmployeeID"].ToString()));
            }
            dr.Close();
        }
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        using (SqlConnection conn = new SqlConnection(connString))
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("INSERT INTO Employees (EmployeeID,EmployeeName, Position, Department, Contact, Status) VALUES (@ID,@name, @position, @department, @contact, @status)", conn);
            cmd.Parameters.AddWithValue("@ID",txtEmployeeID.Text);
            cmd.Parameters.AddWithValue("@name", txtEmployeeName.Text);
            cmd.Parameters.AddWithValue("@position", txtPosition.Text);
            cmd.Parameters.AddWithValue("@department", txtDepartment.Text);
            cmd.Parameters.AddWithValue("@contact", txtContact.Text);
            cmd.Parameters.AddWithValue("@status", ddlStatus.SelectedValue);
            cmd.ExecuteNonQuery();
            GridViewEmployees.DataBind();
            Label1.Text = "Record For Employee Is Inserted";
        }
        Response.Redirect(Request.RawUrl);
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        using (SqlConnection conn = new SqlConnection(connString))
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("UPDATE Employees SET EmployeeName=@name, Position=@position, Department=@department, Contact=@contact, Status=@status WHERE EmployeeID=@id", conn);
            cmd.Parameters.AddWithValue("@id", ddlEmployee.SelectedValue);
            cmd.Parameters.AddWithValue("@name", txtEmployeeName.Text);
            cmd.Parameters.AddWithValue("@position", txtPosition.Text);
            cmd.Parameters.AddWithValue("@department", txtDepartment.Text);
            cmd.Parameters.AddWithValue("@contact", txtContact.Text);
            cmd.Parameters.AddWithValue("@status", ddlStatus.SelectedValue);
            cmd.ExecuteNonQuery();
            GridViewEmployees.DataBind();
        }
        Response.Redirect(Request.RawUrl);
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        using (SqlConnection conn = new SqlConnection(connString))
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("DELETE FROM Employees WHERE EmployeeID=@id", conn);
            cmd.Parameters.AddWithValue("@id", ddlEmployee.SelectedValue);
            cmd.ExecuteNonQuery();
            GridViewEmployees.DataBind();
        }
        Response.Redirect(Request.RawUrl);
    }

     protected void btnLogout_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminLogin.aspx");
    }

     protected void ddlEmployee_SelectedIndexChanged(object sender, EventArgs e)
     {
         using (SqlConnection conn = new SqlConnection(connString))
         {
             conn.Open();
             SqlCommand cmd = new SqlCommand("SELECT * FROM Employees WHERE EmployeeID = @id", conn);
             cmd.Parameters.AddWithValue("@id", ddlEmployee.SelectedValue);

             SqlDataReader dr = cmd.ExecuteReader();
             if (dr.Read())
             {
                 txtEmployeeID.Text=dr["EmployeeID"].ToString();
                 txtEmployeeName.Text = dr["EmployeeName"].ToString();
                 txtPosition.Text = dr["Position"].ToString();
                 txtDepartment.Text = dr["Department"].ToString();
                 txtContact.Text = dr["Contact"].ToString();
                 ddlStatus.SelectedValue = dr["Status"].ToString();
             }
             dr.Close();
         }
     }

}
