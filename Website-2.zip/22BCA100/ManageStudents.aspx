﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="ManageStudents.aspx.cs" Inherits="ManageStudents" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Manage Students</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .header {
            background: #004080;
            color: white;
            padding: 15px;
            text-align: center;
            position: relative;
        }
        .logout-btn {
            position: absolute;
            right: 20px;
            top: 15px;
            background: white;
            color: #004080;
            padding: 8px 15px;
            text-decoration: none;
            border-radius: 5px;
        }
        .logout-btn:hover {
            background: #ff4d4d;
            color: white;
        }
        .sidebar {
            width: 200px;
            background: #333;
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            padding-top: 60px;
        }
        .sidebar a {
            display: block;
            padding: 15px;
            color: white;
            text-decoration: none;
            border-bottom: 1px solid #555;
        }
        .sidebar a:hover {
            background: #575757;
        }
        .main-content {
            margin-left: 220px;
            padding: 20px;
        }
        .card {
            background: white;
            padding: 20px;
            margin: 20px 0;
            border-radius: 8px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
        }
        .footer {
            background: #222;
            color: white;
            text-align: center;
            padding: 15px;
            position: relative;
            bottom: 0;
            width: 100%;
        }
    </style>

    <style>
    /* General Styles */
body {
    font-family: Arial, sans-serif;
    background-color: #f5f5f5;
    margin: 0;
    padding: 0;
}

/* Main Content */
.main-content {
    padding: 20px;
}

/* Container */
.container {
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    max-width: 600px;
    margin: auto;
}

/* Headings */
h2, h3 {
    color: #333;
    text-align: center;
}

/* Form Groups */
.form-group {
    margin-bottom: 15px;
}

label {
    font-weight: bold;
    display: block;
    margin-bottom: 5px;
}

/* Input Fields & Dropdown */
.input-field {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 16px;
}

/* Buttons */
.btn {
    width: 32%;
    padding: 10px;
    border: none;
    border-radius: 5px;
    font-size: 16px;
    cursor: pointer;
    margin-right: 5px;
    color: #fff;
}

#btnAdd {
    background-color: #28a745;
}

#btnUpdate {
    background-color: #007bff;
}

#btnDelete {
    background-color: #dc3545;
}

.btn:hover {
    opacity: 0.9;
}

/* GridView Table */
.table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 15px;
}

.table th, .table td {
    border: 1px solid #ddd;
    padding: 8px;
    text-align: center;
}

.table th {
    background-color: #007bff;
    color: white;
}

.table tr:nth-child(even) {
    background-color: #f2f2f2;
}

/* Responsive Design */
@media screen and (max-width: 600px) {
    .container {
        padding: 15px;
    }

    .btn {
        width: 100%;
        margin-bottom: 10px;
    }
}

    </style>
</head>
<body>
    <form id="form1" runat="server">
        <!-- Header Section -->
        <div class="header">
            <h2>Admin Dashboard</h2>
            <asp:Button ID="btnLogout" runat="server" Text="Logout" CssClass="logout-btn" OnClick="btnLogout_Click" />
        </div>

       <!-- Sidebar Navigation -->
        <div class="sidebar">
            <a href="ManageStudents.aspx">Manage Students</a>
            <a href="ManageRooms.aspx">Manage Rooms</a>
              <a href="ManageEmployees.aspx">Manage Employees</a>
            <a href="ManagePayment.aspx">Manage Payments</a>
          <a href="ManageAnnouncements.aspx">Manage Announcements</a>
        </div>

        <!-- Main Content -->
        <div class="main-content">
         <div class="container">
            <h2>Manage Students</h2>
             <p>
                 <asp:Label ID="Label1" runat="server" ForeColor="#FF5050"></asp:Label>
             </p>

            <!-- Dropdown for Selecting Student -->
            <div class="form-group">
                <label for="ddlStudent">Select Student:</label>
                <asp:DropDownList ID="ddlStudent" runat="server" CssClass="input-field"
                                  AutoPostBack="True" OnSelectedIndexChanged="ddlStudent_SelectedIndexChanged"
                                  DataSourceID="SqlDataSource1" DataTextField="StudentName"
                                  DataValueField="StudentID">
                </asp:DropDownList>
                <asp:SqlDataSource ID="SqlDataSource1" runat="server"
                                   ConnectionString="<%$ ConnectionStrings:CollegeHostelDB %>"
                                   SelectCommand="SELECT [StudentID], [StudentName] FROM [Students]"></asp:SqlDataSource>
            </div>

            <!-- Student Name -->
              <div class="form-group">
                <label for="txtStudentName">Student ID:</label>
                <asp:TextBox ID="txtStudentID" runat="server" CssClass="input-field" required="required"></asp:TextBox>
            </div>

            <div class="form-group">
                <label for="txtStudentName">Student Name:</label>
                <asp:TextBox ID="txtStudentName" runat="server" CssClass="input-field" required="required"></asp:TextBox>
            </div>

            <!-- Student Email -->
            <div class="form-group">
                <label for="txtEmail">Email:</label>
                <asp:TextBox ID="txtEmail" runat="server" CssClass="input-field" required="required"></asp:TextBox>
            </div>

            <!-- Mobile Number -->
            <div class="form-group">
                <label for="txtMobile">Mobile Number:</label>
                <asp:TextBox ID="txtMobile" runat="server" CssClass="input-field" required="required"></asp:TextBox>
            </div>

            <!-- Assigned Room -->
            <div class="form-group">
                <label for="ddlRoom">Assigned Room:</label>
                <asp:DropDownList ID="ddlRoom" runat="server" CssClass="input-field"
                                  DataSourceID="SqlDataSource2" DataTextField="RoomNumber"
                                  DataValueField="RoomNumber">
                </asp:DropDownList>
                <asp:SqlDataSource ID="SqlDataSource2" runat="server"
                                   ConnectionString="<%$ ConnectionStrings:CollegeHostelDB %>"
                                   SelectCommand="SELECT [RoomNumber] FROM [Rooms] WHERE [Status] = 'Available'"></asp:SqlDataSource>
            </div>

            <!-- Buttons -->
            <div class="form-group">
                <asp:Button ID="btnAdd" runat="server" Text="Add Student" CssClass="btn" OnClick="btnAdd_Click" />
                <asp:Button ID="btnUpdate" runat="server" Text="Update Student" CssClass="btn" OnClick="btnUpdate_Click" />
                <asp:Button ID="btnDelete" runat="server" Text="Delete Student" CssClass="btn" OnClick="btnDelete_Click" />
            </div>

            <hr>
            <h3>Student List</h3>
            <asp:GridView ID="GridViewStudents" runat="server" AutoGenerateColumns="False" 
                 CssClass="table" DataKeyNames="StudentID" DataSourceID="SqlDataSource3">
                <Columns>
                    <asp:BoundField DataField="StudentID" HeaderText="StudentID" ReadOnly="True" 
                        SortExpression="StudentID" />
                    <asp:BoundField DataField="StudentName" HeaderText="StudentName" 
                        SortExpression="StudentName" />
                    <asp:BoundField DataField="Email" HeaderText="Email" SortExpression="Email" />
                    <asp:BoundField DataField="Mobile" HeaderText="Mobile" 
                        SortExpression="Mobile" />
                    <asp:BoundField DataField="RoomNumber" HeaderText="RoomNumber" 
                        SortExpression="RoomNumber" />
                </Columns>
            </asp:GridView>
             <asp:SqlDataSource ID="SqlDataSource3" runat="server" 
                 ConnectionString="<%$ ConnectionStrings:CollegeHostelDB %>" 
                 SelectCommand="SELECT * FROM [Students]"></asp:SqlDataSource>
        </div>
        </div>

        <!-- Footer -->
        <div class="footer">
            <p>CES Girls Hostel - Admin Dashboard | Contact: ceshostel@gmail.com | +91-9876543210</p>
        </div>
    </form>
</body>
</html>