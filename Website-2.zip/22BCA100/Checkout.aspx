﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="Checkout.aspx.cs" Inherits="Checkout" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
<title>Checkout - Room Booking</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
        }
        .container {
            background: white;
            width: 40%;
            margin: 50px auto;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        h2 {
            color: #333;
        }
        .details {
            text-align: left;
            margin: 20px 0;
        }
        .details p {
            font-size: 18px;
            margin: 10px 0;
        }
        select, button {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            font-size: 16px;
        }
        .btn-pay {
            background: #28a745;
            color: white;
            border: none;
            cursor: pointer;
        }
        .btn-pay:hover {
            background: #218838;
        }
        .btn-cancel {
            background: #dc3545;
            color: white;
            border: none;
            cursor: pointer;
        }
        .btn-cancel:hover {
            background: #c82333;
        }
    </style>
</head>
<body>
    <form id="Form1" runat="server">
        <div class="container">
            <h2>Room Booking Checkout</h2>
            <div class="details">
                <p><strong>Student Name:</strong> <asp:Label ID="lblStudentName" runat="server"></asp:Label></p>
                <p><strong>Email:</strong> <asp:Label ID="lblEmail" runat="server"></asp:Label></p>
                <p><strong>Room Number:</strong> <asp:Label ID="lblRoomNumber" runat="server"></asp:Label></p>
                <p><strong>Price:</strong> ₹<asp:Label ID="lblPrice" runat="server"></asp:Label>/month</p>
            </div>

            <p><strong>Select Payment Method:</strong></p>
            <asp:DropDownList ID="ddlPaymentMethod" runat="server">
                <asp:ListItem Text="-- Select Payment Method --" Value="" />
                <asp:ListItem Text="Credit Card" Value="Credit Card" />
                <asp:ListItem Text="Debit Card" Value="Debit Card" />
                <asp:ListItem Text="UPI" Value="UPI" />
                <asp:ListItem Text="Net Banking" Value="Net Banking" />
            </asp:DropDownList>

            <asp:Button ID="btnPayNow" runat="server" Text="Pay Now" CssClass="btn-pay" OnClick="btnPayNow_Click" />
            <asp:Button ID="btnCancel" runat="server" Text="Cancel" CssClass="btn-cancel" OnClick="btnCancel_Click" />
        </div>
    </form>
</body>
</html>