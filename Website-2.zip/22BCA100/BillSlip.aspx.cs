﻿using System;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class BillSlip : System.Web.UI.Page
{
    string connString = WebConfigurationManager.ConnectionStrings["CollegeHostelDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserEmail"] == null)
            {
                Response.Redirect("StudentLogin.aspx");
            }

            if (Request.QueryString["RoomNumber"] != null && Request.QueryString["Amount"] != null)
            {
                LoadPaymentDetails(Request.QueryString["RoomNumber"], Session["UserEmail"].ToString());
            }
            else
            {
                Response.Redirect("BookRoom.aspx");
            }
        }
    }

    private void LoadPaymentDetails(string roomNumber, string studentEmail)
    {
        using (SqlConnection conn = new SqlConnection(connString))
        {
            string query = "SELECT P.PaymentDate, P.Amount, P.PaymentMethod, S.FullName, S.Email " +
                           "FROM Payment P " +
                           "JOIN Users S ON P.StudentEmail = S.Email " +
                           "WHERE P.RoomNumber = @RoomNumber AND P.StudentEmail = @StudentEmail " +
                           "ORDER BY P.PaymentDate DESC";

            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@RoomNumber", roomNumber);
            cmd.Parameters.AddWithValue("@StudentEmail", studentEmail);

            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                lblStudentName.Text = reader["FullName"].ToString();
                lblEmail.Text = reader["Email"].ToString();
                lblRoomNumber.Text = roomNumber;
                lblAmount.Text = reader["Amount"].ToString();
                lblPaymentMethod.Text = reader["PaymentMethod"].ToString();
                lblPaymentDate.Text = Convert.ToDateTime(reader["PaymentDate"]).ToString("dd-MM-yyyy hh:mm tt");
            }
            conn.Close();
        }
    }
    protected void Unnamed1_Click(object sender, EventArgs e)
    {
        Response.Redirect("StudentDashboard.aspx");
    }
}
