﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Text;

public partial class Announce : System.Web.UI.Page
{
    string connString = WebConfigurationManager.ConnectionStrings["CollegeHostelDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadAnnouncements();
        }
    }

    private void LoadAnnouncements()
    {
        using (SqlConnection conn = new SqlConnection(connString))
        {
            string query = "SELECT Title, Description, CONVERT(VARCHAR, DatePosted, 106) AS DatePosted FROM Announcements ORDER BY DatePosted DESC";
            SqlCommand cmd = new SqlCommand(query, conn);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();

            StringBuilder announcementsHtml = new StringBuilder();
            while (reader.Read())
            {
                announcementsHtml.Append("<div class='announcement'>");
                announcementsHtml.Append("<h3>" + reader["Title"] + "</h3>");
                announcementsHtml.Append("<p>" + reader["Description"] + "</p>");
                announcementsHtml.Append("<p class='date'>Posted on: " + reader["DatePosted"] + "</p>");
                announcementsHtml.Append("</div>");
            }
            ltlAnnouncements.Text = announcementsHtml.ToString();
            conn.Close();
        }
    }
    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Response.Redirect("StudentLogin.aspx");
    }
}
