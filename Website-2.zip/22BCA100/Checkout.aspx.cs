﻿using System;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class Checkout : System.Web.UI.Page
{
    string connString = WebConfigurationManager.ConnectionStrings["CollegeHostelDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            // Check if the student is logged in
            if (Session["UserEmail"] == null)
            {
                Response.Redirect("StudentLogin.aspx");
            }

            LoadStudentDetails();

            if (Request.QueryString["RoomNumber"] != null && Request.QueryString["Price"] != null)
            {
                lblRoomNumber.Text = Request.QueryString["RoomNumber"];
                lblPrice.Text = Request.QueryString["Price"];
            }
            else
            {
                Response.Redirect("BookRoom.aspx");
            }
        }
    }

    private void LoadStudentDetails()
    {
        using (SqlConnection conn = new SqlConnection(connString))
        {
            string query = "SELECT FullName, Email FROM Users WHERE Email=@Email";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@Email", Session["UserEmail"]);

            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                lblStudentName.Text = reader["FullName"].ToString();
                lblEmail.Text = reader["Email"].ToString();
            }
            conn.Close();
        }
    }

    protected void btnPayNow_Click(object sender, EventArgs e)
    {
        if (ddlPaymentMethod.SelectedValue == "")
        {
            Response.Write("<script>alert('Please select a payment method!');</script>");
            return;
        }

        using (SqlConnection conn = new SqlConnection(connString))
        {
            string query = "INSERT INTO Payment (StudentEmail, RoomNumber, Amount, PaymentMethod, PaymentDate) " +
                           "VALUES (@StudentEmail, @RoomNumber, @Amount, @PaymentMethod, GETDATE())";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@StudentEmail", Session["UserEmail"]);
            cmd.Parameters.AddWithValue("@RoomNumber", lblRoomNumber.Text);
            cmd.Parameters.AddWithValue("@Amount", lblPrice.Text);
            cmd.Parameters.AddWithValue("@PaymentMethod", ddlPaymentMethod.SelectedValue);

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        // Mark the room as booked
        using (SqlConnection conn = new SqlConnection(connString))
        {
            string query = "UPDATE Rooms SET Status='Booked' WHERE RoomNumber=@RoomNumber";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@RoomNumber", lblRoomNumber.Text);

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        Response.Write("<script>alert('Your payment is successfully made!');</script>");
        Response.Redirect("BillSlip.aspx?RoomNumber=" + lblRoomNumber.Text + "&Amount=" + lblPrice.Text);
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("BookRoom.aspx");
    }
}
