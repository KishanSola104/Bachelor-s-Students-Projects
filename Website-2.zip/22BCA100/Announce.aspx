﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="Announce.aspx.cs" Inherits="Announce" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>Student Dashboard - Announcement</title>
    <style>
      body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
   
    background-size: cover;
    height: 100vh; /* Ensures body covers full viewport height */
}

        .header {
            background: #007bff;
            color: white;
            padding: 20px;
            text-align: center;
            font-size: 22px;
        }
        .sidebar {
            width: 200px;
            height: 100vh;
            background: #333;
            color: white;
            position: fixed;
            padding-top: 20px;
        }
        .sidebar a {
            display: block;
            color: white;
            padding: 15px;
            text-decoration: none;
            transition: 0.3s;
           
        }
        .sidebar a:hover {
            background: #575757;
        }
        .content {
            margin-left: 260px;
            padding: 20px;
          
        }
        .logout-btn {
            background: #dc3545;
            color: white;
            padding: 10px 15px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            position: absolute;
            right: 20px;
            top: 15px;
        }
    </style>
  
   
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .container 
        {
            margin-left:auto;
            width: 70%;
            margin: 20px auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        .announcement 
        {
             margin-left:220px;
            background: #e9f5ff;
            padding: 15px;
            margin: 10px 0;
            border-left: 6px solid #007BFF;
            border-radius: 5px;
            transition: 0.3s;
        }
        .announcement:hover {
            background: #d0ebff;
        }
        .announcement h3 {
            margin: 0;
            color: #0056b3;
        }
        .announcement p {
            margin: 5px 0;
            color: #333;
        }
        .date {
            font-size: 0.9em;
            color: #666;
        }
    </style>

</head>
<body>
<form id="Form1" runat="server">
    <div class="header">
        Welcome, <asp:Label ID="lblStudentName" runat="server" Text="Student"></asp:Label>  
        <asp:Button ID="btnLogout" runat="server" Text="Logout" CssClass="logout-btn" OnClick="btnLogout_Click" />
    </div>

    <div class="sidebar">
        <a href="BookRoom.aspx"> Book a Room</a>
        <a href="PayFees.aspx"> Pay Fees</a>
        <a href="Announce.aspx"> Announcements</a>
        <a href="StudProfile.aspx"> Profile</a>
    </div>

 <div class="container">
        <h2>Latest Announcements</h2>
        <asp:Literal ID="ltlAnnouncements" runat="server"></asp:Literal>
    </div>





    </form>
</body>
</html>