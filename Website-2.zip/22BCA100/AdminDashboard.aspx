﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="AdminDashboard.aspx.cs" Inherits="AdminDashboard" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
<title>Admin Dashboard</title>
    <style>
           body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    color: white;
    
    /* Background image */
    background: url('images/img3.jpg') no-repeat center center fixed;
    background-size: cover;
    height: 100vh; /* Ensures body covers full viewport height */
}

        .header {
            background: #004080;
            color: white;
            padding: 15px;
            text-align: center;
            position: relative;
        }
        .logout-btn {
            position: absolute;
            right: 20px;
            top: 15px;
            background: white;
            color: #004080;
            padding: 8px 15px;
            text-decoration: none;
            border-radius: 5px;
        }
        .logout-btn:hover {
            background: #ff4d4d;
            color: white;
        }
        .sidebar {
            width: 200px;
            background: #333;
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            padding-top: 60px;
        }
        .sidebar a {
            display: block;
            padding: 15px;
            color: white;
            text-decoration: none;
            border-bottom: 1px solid #555;
        }
        .sidebar a:hover {
            background: #575757;
        }
        .main-content {
            margin-left: 220px;
            padding: 20px;
        }
        .card {
            background: white;
            padding: 20px;
            margin: 20px 0;
            border-radius: 8px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
            color:Black;
        }
        .footer {
            background: #222;
            color: white;
            text-align: center;
            padding: 15px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <!-- Header Section -->
        <div class="header">
            <h2>Admin Dashboard</h2>
            <asp:Button ID="btnLogout" runat="server" Text="Logout" CssClass="logout-btn" OnClick="btnLogout_Click" />
        </div>

        <!-- Sidebar Navigation -->
        <!-- Sidebar Navigation -->
        <div class="sidebar">
            <a href="ManageStudents.aspx">Manage Students</a>
            <a href="ManageRooms.aspx">Manage Rooms</a>
              <a href="ManageEmployees.aspx">Manage Employees</a>
            <a href="ManagePayment.aspx">Manage Payments</a>
          <a href="ManageAnnouncements.aspx">Manage Announcements</a>
        </div>

        <!-- Main Content -->
        <div class="main-content">
          <h2>Admin Dashboard</h2>
    <p>Welcome to CES Hostel Admin Portal. Use the menu to navigate.</p>

       
            <p>Here is an overview of the hostel management system.</p>

            <div class="card">
                <h3>Total Students: <asp:Label ID="lblTotalStudents" runat="server" Text="0"></asp:Label></h3>
            </div>

            <div class="card">
                <h3>Available Rooms: <asp:Label ID="lblAvailableRooms" runat="server" Text="0"></asp:Label></h3>
            </div>

             <div class="card">
                <h3>Total Employees: <asp:Label ID="lblEmployees" runat="server" Text="0"></asp:Label></h3>
            </div>

          
        </div>

        <!-- Footer -->
        <div class="footer">
            <p>CES Girls Hostel - Admin Dashboard | Contact: ceshostel@gmail.com | +91-9876543210</p>
        </div>
    </form>
</body>
</html>