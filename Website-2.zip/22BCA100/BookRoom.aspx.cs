﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class BookRoom : System.Web.UI.Page
{
    string connString = WebConfigurationManager.ConnectionStrings["CollegeHostelDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadAvailableRooms();
        }
    }

    private void LoadAvailableRooms()
    {
        using (SqlConnection conn = new SqlConnection(connString))
        {
            string query = "SELECT  RoomNumber, RoomType, Capacity FROM Rooms WHERE Status='Available'";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                rptRooms.DataSource = dt;
                rptRooms.DataBind();
            }
            else
            {
                lblMessage.Text = "No available rooms at the moment.";
            }
        }
    }

    protected void btnBook_Click(object sender, EventArgs e)
    {
        string roomId = (sender as System.Web.UI.WebControls.Button).CommandArgument;

        Response.Redirect("Checkout.aspx?RoomNumber=" + roomId + "&Price=3000");
    }

    public string GetRoomImage(string roomType)
    {
        switch (roomType)
        {
            case "Single": return "images/image1.jpg";
            case "Double": return "images/image2.jpg";
            case "Triple": return "images/image3.jpg";
            default: return "images/default.jpg"; // In case of unexpected data
        }
    }
    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Response.Redirect("StudentLogin.aspx");
    }
}
