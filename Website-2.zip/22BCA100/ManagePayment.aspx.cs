﻿using System;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class ManagePayment : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // Check if admin is logged in
        if (Session["AdminEmail"] == null)
        {
            Response.Redirect("AdminLogin.aspx");
        }

      
    }

    
    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session["AdminEmail"] = null;
        Response.Redirect("AdminLogin.aspx");
    }
}
