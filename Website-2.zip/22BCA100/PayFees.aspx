﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="PayFees.aspx.cs" Inherits="PayFees" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
   <title>Student Dashboard - Pay Fees </title>
    <style>
      body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
   
    background-size: cover;
    height: 100vh; /* Ensures body covers full viewport height */
}

        .header {
            background: #007bff;
            color: white;
            padding: 20px;
            text-align: center;
            font-size: 22px;
        }
        .sidebar {
            width: 250px;
            height: 100vh;
            background: #333;
            color: white;
            position: fixed;
            padding-top: 20px;
        }
        .sidebar a {
            display: block;
            color: white;
            padding: 15px;
            text-decoration: none;
            transition: 0.3s;
           
        }
        .sidebar a:hover {
            background: #575757;
        }
        .content {
            margin-left: 260px;
            padding: 20px;
          
        }
        .logout-btn1 {
            background: #dc3545;
            color: white;
            padding: 10px 15px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            position: absolute;
            right: 20px;
            top: 15px;
        }
    </style>
    <style>
        .notice-section, .facility-section, .rules-section {
    background: rgba(255, 255, 255, 0.1);
    padding: 5px;
    border-radius: 10px;
    margin-top: 10px;
}

h3 {
    color: #ffcc00;
    border-bottom: 2px solid #ffcc00;
    padding-bottom: 5px;
}

ul {
    list-style-type: none;
    padding: 0;
}

ul li {
    margin: 8px 0;
    font-size: 16px;
}

    </style>
     <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
        }
        .container {
            background: white;
            width: 50%;
            margin: 50px auto;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        h2 {
            color: #333;
        }
        label {
            font-size: 18px;
        }
        input, select {
            width: 80%;
            padding: 10px;
            margin: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .btn-pay1 {
            background: #28a745;
            color: white;
            border: none;
            padding: 10px;
            font-size: 16px;
            cursor: pointer;
        }
        .btn-pay:hover {
            background: #218838;
        }
    </style>




</head>
<body>
<form id="Form1" runat="server">
    <div class="header">
        Welcome, <asp:Label ID="lblStudentName" runat="server" Text="Student"></asp:Label>  
        <asp:Button ID="btnLogout" runat="server" Text="Logout" CssClass="logout-btn1" Style="width:100px;" OnClick="btnLogout_Click" />
    </div>

    <div class="sidebar">
        <a href="BookRoom.aspx"> Book a Room</a>
        <a href="PayFees.aspx"> Pay Fees</a>
        <a href="Announce.aspx"> Announcements</a>
        <a href="StudProfile.aspx"> Profile</a>
    </div>

 
        <div class="container">
            <h2>CES Girls Hostel - Pay Fees</h2>
            <hr>
            <div>
                <label>Student Name:</label>
                <asp:Label ID="Label1" runat="server"></asp:Label>
            </div>
            <div>
                <label>Email:</label>
                <asp:Label ID="lblEmail" runat="server"></asp:Label>
            </div>
            <div>
                <label>Room Number:</label>
                <asp:Label ID="lblRoomNumber" runat="server"></asp:Label>
            </div>
            <div>
                <label>Amount Due (₹):</label>
                <asp:Label ID="lblAmountDue" runat="server"></asp:Label>
            </div>
            <div>
                <label>Payment Method:</label>
                <asp:DropDownList ID="ddlPaymentMethod" runat="server">
                    <asp:ListItem Text="Select Payment Method" Value="" />
                    <asp:ListItem Text="Credit Card" Value="Credit Card" />
                    <asp:ListItem Text="Debit Card" Value="Debit Card" />
                    <asp:ListItem Text="UPI" Value="UPI" />
                    <asp:ListItem Text="Net Banking" Value="Net Banking" />
                </asp:DropDownList>
            </div>
            <asp:Button ID="btnPay" runat="server" CssClass="btn-pay1" Text="Pay Now" OnClick="btnPay_Click" />
        </div>





    </form>
</body>
</html>