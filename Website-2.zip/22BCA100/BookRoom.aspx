﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="BookRoom.aspx.cs" Inherits="BookRoom" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>Student Dashboard Book A Room</title>
    <style>
      body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
  
    background-size: cover;
    height: 100vh; /* Ensures body covers full viewport height */
}

        .header {
            background: #007bff;
            color: white;
            padding: 20px;
            text-align: center;
            font-size: 22px;
        }
        .sidebar {
            width: 250px;
            height: 100vh;
            background: #333;
            color: white;
            position: fixed;
            padding-top: 20px;
        }
        .sidebar a {
            display: block;
            color: white;
            padding: 15px;
            text-decoration: none;
            transition: 0.3s;
           
        }
        .sidebar a:hover {
            background: #575757;
        }
        .content {
            margin-left: 260px;
            padding: 20px;
          
        }
        .logout-btn {
            background: #dc3545;
            color: white;
            padding: 10px 15px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            position: absolute;
            right: 20px;
            top: 15px;
        }
    </style>
  
 <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
        }
        .room-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }
        .room-card {
            border: 1px solid #ccc;
            border-radius: 8px;
            padding: 15px;
            margin: 15px;
            background: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 250px;
        }
        .room-card img {
            width: 100%;
            height: 150px;
            border-radius: 5px;
        }
        .btn-book {
            background: #28a745;
            color: white;
            padding: 10px;
            border: none;
            cursor: pointer;
            width: 100%;
            margin-top: 10px;
        }
        .btn-book:hover {
            background: #218838;
        }
    </style>
</head>
<body>
<form id="Form1" runat="server">
    <div class="header">
        Welcome, <asp:Label ID="lblStudentName" runat="server" Text="Student"></asp:Label>  
        <asp:Button ID="btnLogout" runat="server" Text="Logout" CssClass="logout-btn" OnClick="btnLogout_Click" />
    </div>

    <div class="sidebar">
        <a href="BookRoom.aspx"> Book a Room</a>
        <a href="PayFees.aspx"> Pay Fees</a>
        <a href="Announce.aspx"> Announcements</a>
        <a href="StudProfile.aspx"> Profile</a>
    </div>

  <div class="content">
    <h2>Available Rooms</h2>
        <asp:Label ID="lblMessage" runat="server" ForeColor="Red"></asp:Label>

        <div class="room-container">
            <asp:Repeater ID="rptRooms" runat="server">
                <ItemTemplate>
                    <div class="room-card">
                        <asp:Image ID="roomImage" runat="server" ImageUrl='<%# GetRoomImage(Eval("RoomType").ToString()) %>' />
                        <h3>Room No: <%# Eval("RoomNumber") %></h3>
                        <p>Type: <%# Eval("RoomType") %></p>
                        <p>Capacity: <%# Eval("Capacity") %> persons</p>
                        <p><b>Price: ₹3000/month</b></p>
                        <asp:Button ID="btnBook" runat="server" Text="Book Now" CssClass="btn-book"
                            CommandArgument='<%# Eval("RoomNumber") %>' OnClick="btnBook_Click" />
                    </div>
                </ItemTemplate>
            </asp:Repeater>
        </div>

</div>





    </form>
</body>
</html>