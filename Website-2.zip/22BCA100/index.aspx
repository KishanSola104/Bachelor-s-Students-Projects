﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="index.aspx.cs" Inherits="index" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>CES Hostel</title>
    <style>
    /* Header */
/* General Styles */
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background: #f5f5f5;
}

/* Header */
.header {
    background: #004080;
    color: white;
    padding: 15px 20px;
    text-align: center;
    position: relative;
    font-size: 22px;
    font-weight: bold;
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
}

/* Login Dropdown */
.dropdown {
    position: absolute;
    top: 50%;
    margin-right:60px;
    right: 20px;
    transform: translateY(-50%);
}

.dropbtn {
    background: white;
    color: #004080;
    padding: 12px 20px;
    border: none;
    cursor: pointer;
    font-weight: bold;
    border-radius: 5px;
    transition: 0.3s;
}

.dropbtn:hover {
    background: #003366;
    color: white;
}

.dropdown-content {
    display: none;
    position: absolute;
    background: white;
    min-width: 140px;
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
    border-radius: 5px;
}

.dropdown-content a {
    display: block;
    padding: 12px;
    color: black;
    text-decoration: none;
    transition: 0.3s;
}

.dropdown-content a:hover {
    background: #004080;
    color: white;
}

.dropdown:hover .dropdown-content {
    display: block;
}

/* Main Content */
.main-content {
    text-align: center;
    padding: 40px 20px;
    background: linear-gradient(rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.3)), url('Images/img3.jpg');
    background-size: cover;
    background-position: center;
    height: 400px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.main-content h2 {
    font-size: 32px;
    color: white;
    background: rgba(0, 0, 0, 0.5);
    padding: 15px 30px;
    border-radius: 5px;
}

/* Footer */
.footer {
    background: #222;
    color: white;
    padding: 20px;
    text-align: center;
}

.footer .container {
    display: flex;
    justify-content: space-around;
    flex-wrap: wrap;
    max-width: 1000px;
    margin: auto;
}

.footer-column {
    width: 30%;
    text-align: left;
}

.footer-column h3 {
    border-bottom: 2px solid white;
    padding-bottom: 5px;
    margin-bottom: 10px;
}

.footer-column p,
.footer-column a {
    color: #ccc;
    text-decoration: none;
}

.footer-column a:hover {
    color: white;
}

.top-bar {
    background: #333;
    padding: 10px;
    font-size: 14px;
    color: #ddd;
}

    </style>
</head>
  <body>
    <form id="form1" runat="server">
        <!-- Header Section -->
        <div class="header">
            CES Girls Hostel
            <div class="dropdown">
                <button class="dropbtn">Login</button>
                <div class="dropdown-content">
                    <a href="AdminLogin.aspx">Admin</a>
                    <a href="StudentLogin.aspx">Student</a>
                </div>
            </div>
        </div>

        <!-- Main Section -->
        <div class="main-content">
            <h2>Welcome to CES GirlsHostel</h2>
        </div>

        <!-- Footer Section -->
        <div class="footer">
            <div class="top-bar">
                <asp:Label ID="Label1" runat="server" Text="Safe & Secure Hostel  & "></asp:Label>
                <asp:Label ID="Label2" runat="server" Text="24/7 Support"></asp:Label>
            </div>
            <div class="container">
                <div class="footer-column">
                    <h3>INFORMATION</h3>
        <ul>
    <li><a href="AboutUs.aspx">About Us</a></li>
    <li><a href="Contact.aspx">Contact</a></li>
</ul>

                </div>
                <div class="footer-column">
                    <h3>CONTACT US</h3>
                    <p> Address: Anand, Gujarat, India</p>
                    <p>Email: <asp:HyperLink ID="HyperLink1" runat="server" NavigateUrl="mailto:ceshostel@gmail.com">ceshostel@gmail.com</asp:HyperLink></p>
                    <p>Phone: <asp:HyperLink ID="HyperLink2" runat="server" NavigateUrl="tel:+919876543210">+91-9876543210</asp:HyperLink></p>
                </div>
            </div>
        </div>
    </form>
</body>
</html>