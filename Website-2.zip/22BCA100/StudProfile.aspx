﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="StudProfile.aspx.cs" Inherits="StudProfile" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  
 <title>Student Dashboard</title>
    <style>
      body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
  
    background-size: cover;
    height: 100vh; /* Ensures body covers full viewport height */
}

        .header {
            background: #007bff;
            color: white;
            padding: 20px;
            text-align: center;
            font-size: 22px;
        }
        .sidebar {
            width: 250px;
            height: 100vh;
            background: #333;
            color: white;
            position: fixed;
            padding-top: 20px;
        }
        .sidebar a {
            display: block;
            color: white;
            padding: 15px;
            text-decoration: none;
            transition: 0.3s;
           
        }
        .sidebar a:hover {
            background: #575757;
        }
        .content {
            margin-left: 260px;
            padding: 20px;
          
        }
        .logout-btn {
            background: #dc3545;
            color: white;
            padding: 10px 15px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            position: absolute;
            right: 20px;
            top: 15px;
        }
    </style>
    <style>
        .notice-section, .facility-section, .rules-section {
    background: rgba(255, 255, 255, 0.1);
    padding: 5px;
    border-radius: 10px;
    margin-top: 10px;
}

h3 {
    color: #ffcc00;
    border-bottom: 2px solid #ffcc00;
    padding-bottom: 5px;
}

ul {
    list-style-type: none;
    padding: 0;
}

ul li {
    margin: 8px 0;
    font-size: 16px;
}

    </style>
    <style>
        
<style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
        }
        .profile-container {
            width: 50%;
            margin: auto;
            background: white;
            padding: 20px;
            box-shadow: 0px 0px 10px gray;
            border-radius: 10px;
        }
        h2 {
            color: #333;
        }
        .profile-info {
            text-align: left;
            padding: 10px;
        }
        .btn {
            padding: 8px 15px;
            background: #007bff;
            color: white;
            border: none;
            cursor: pointer;
        }
    </style>
    </style>
</head>
<body>
<form id="Form1" runat="server">
    <div class="header">
        Welcome, <asp:Label ID="lblStudentName" runat="server" Text="Student"></asp:Label>  
        <asp:Button ID="btnLogout" runat="server" Text="Logout" CssClass="logout-btn" OnClick="btnLogout_Click" />
    </div>

    <div class="sidebar">
        <a href="BookRoom.aspx"> Book a Room</a>
        <a href="PayFees.aspx"> Pay Fees</a>
        <a href="Announce.aspx"> Announcements</a>
        <a href="StudProfile.aspx"> Profile</a>
    </div>

 <div class="profile-container">
    <h2>Student Profile</h2>
    <div class="profile-info">
        <p><strong>Name:</strong> <asp:Label ID="lblName" runat="server" /></p>
        <p><strong>Email:</strong> <asp:Label ID="lblEmail" runat="server" /></p>
        <p><strong>Mobile:</strong> <asp:Label ID="lblMobile" runat="server" /></p>
      
        <p><strong>Room Number:</strong> <asp:Label ID="lblRoomNumber" runat="server" /></p>
        <p><strong>Room Type:</strong> <asp:Label ID="lblRoomType" runat="server" /></p>

        <h3>Fees Information</h3>
        <p><strong>Total Fees:</strong> <asp:Label ID="lblTotalFees" runat="server" ForeColor="Blue" /></p>
        <p><strong>Amount Paid:</strong> <asp:Label ID="lblAmountPaid" runat="server" ForeColor="Green" /></p>
        <p><strong>Due Amount:</strong> <asp:Label ID="lblDueAmount" runat="server" ForeColor="Red" /></p>
        <p><strong>Fees Status:</strong> <asp:Label ID="lblFeesStatus" runat="server" Font-Bold="true" ForeColor="Red" /></p>
    </div>

    <h3>Update Contact Details</h3>
    <asp:TextBox ID="txtMobile" runat="server" placeholder="Update Mobile Number"></asp:TextBox><br /><br />
  
    <asp:Button ID="btnUpdate" runat="server" Text="Update" CssClass="btn" OnClick="btnUpdate_Click" /><br /><br />
    
    <asp:Button ID="Button1" runat="server" Text="Logout" CssClass="btn" OnClick="btnLogout_Click" />
</div>





    </form>
</body>
</html>