﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Web.UI.WebControls;

public partial class ManageAnnouncements : System.Web.UI.Page
{
    string connString = WebConfigurationManager.ConnectionStrings["CollegeHostelDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadAnnouncements();
        }
    }

    // Load Announcements into GridView
    private void LoadAnnouncements()
    {
        try
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "SELECT * FROM Announcements ORDER BY DatePosted DESC";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
               
            }
        }
        catch (Exception ex)
        {
            Response.Write("<script>alert('Error loading announcements: " + ex.Message + "');</script>");
        }
    }

    // Add Announcement
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "INSERT INTO Announcements (AnnouncementID, Title, Description, DatePosted) VALUES (@ID, @Title, @Description, @DatePosted)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@ID", txtAnID.Text);
                cmd.Parameters.AddWithValue("@Title", txtTitle.Text);
                cmd.Parameters.AddWithValue("@Description", txtDescription.Text);
                cmd.Parameters.AddWithValue("@DatePosted", DateTime.Now); // Store the current date & time

                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();

                Response.Write("<script>alert('Announcement added successfully!');</script>");
                ClearFields();
                LoadAnnouncements();
            }
        }
        catch (Exception ex)
        {
            Response.Write("<script>alert('Error adding announcement: " + ex.Message + "');</script>");
        }
    }


    // Update Announcement
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "UPDATE Announcements SET Title=@Title, Description=@Description WHERE AnnouncementID=@ID";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Title", txtTitle.Text);
                cmd.Parameters.AddWithValue("@Description", txtDescription.Text);
                cmd.Parameters.AddWithValue("@ID", ViewState["AnnouncementID"]);

                conn.Open();
                int rowsAffected = cmd.ExecuteNonQuery();
                conn.Close();

                if (rowsAffected > 0)
                {
                    Response.Write("<script>alert('Announcement updated successfully!');</script>");
                    ClearFields();
                    LoadAnnouncements();
                }
                else
                {
                    Response.Write("<script>alert('No announcement found to update.');</script>");
                }
            }
        }
        catch (Exception ex)
        {
            Response.Write("<script>alert('Error updating announcement: " + ex.Message + "');</script>");
        }
    }

    // Delete Announcement
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "DELETE FROM Announcements WHERE AnnouncementID=@ID";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@ID", ViewState["AnnouncementID"]);

                conn.Open();
                int rowsAffected = cmd.ExecuteNonQuery();
                conn.Close();

                if (rowsAffected > 0)
                {
                    Response.Write("<script>alert('Announcement deleted successfully!');</script>");
                    ClearFields();
                    LoadAnnouncements();
                }
                else
                {
                    Response.Write("<script>alert('No announcement found to delete.');</script>");
                }
            }
        }
        catch (Exception ex)
        {
            Response.Write("<script>alert('Error deleting announcement: " + ex.Message + "');</script>");
        }
    }

    // Logout Functionality
    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminLogin.aspx");
    }

    // Clear Fields
    private void ClearFields()
    {
        txtAnID.Text = "";
        txtTitle.Text = "";
        txtDescription.Text = "";
        ViewState["AnnouncementID"] = null;
    }
}
