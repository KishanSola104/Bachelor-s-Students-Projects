﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="BillSlip.aspx.cs" Inherits="BillSlip" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
 <title>Payment Receipt</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
        }
        .container {
            background: white;
            width: 50%;
            margin: 50px auto;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        h2 {
            color: #333;
        }
        .details {
            text-align: left;
            margin: 20px 0;
        }
        .details p {
            font-size: 18px;
            margin: 10px 0;
        }
        .btn-print {
            background: #007bff;
            color: white;
            border: none;
            padding: 10px;
            font-size: 16px;
            cursor: pointer;
        }
        .btn-print:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>
    <form id="Form1" runat="server">
        <div class="container">
            <h2>CES Girls Hostel - Payment Receipt</h2>
            <hr>
            <div class="details">
                <p><strong>Student Name:</strong> <asp:Label ID="lblStudentName" runat="server"></asp:Label></p>
                <p><strong>Email:</strong> <asp:Label ID="lblEmail" runat="server"></asp:Label></p>
                <p><strong>Room Number:</strong> <asp:Label ID="lblRoomNumber" runat="server"></asp:Label></p>
                <p><strong>Amount Paid:</strong> ₹<asp:Label ID="lblAmount" runat="server"></asp:Label></p>
                <p><strong>Payment Method:</strong> <asp:Label ID="lblPaymentMethod" runat="server"></asp:Label></p>
                <p><strong>Payment Date:</strong> <asp:Label ID="lblPaymentDate" runat="server"></asp:Label></p>
            </div>
            <button class="btn-print" onclick="window.print();">Print Receipt</button>
            <br />
            <br />
            <asp:button class="btn-print" Text="Back To Home" runat="server" 
                onclick="Unnamed1_Click"></asp:button>
        </div>
    </form>
</body>
</html>