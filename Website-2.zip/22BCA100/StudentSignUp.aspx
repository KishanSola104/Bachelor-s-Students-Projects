﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="StudentSignUp.aspx.cs" Inherits="StudentSignUp" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
 <title>Student Sign Up</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
        }
        .container {
            width: 50%;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px gray;
        }
        .input-field {
            width: 100%;
            padding: 8px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .btn {
            background: #28a745;
            color: white;
            padding: 10px 15px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }
    </style>
</head>
<body>
<form runat="server">
    <div class="container">
        <h2>Student Sign Up</h2>
        <asp:TextBox ID="txtID" runat="server" CssClass="input-field" Placeholder="Enter Your College Allocated ID" required="true"></asp:TextBox>
        <asp:TextBox ID="txtFullName" runat="server" CssClass="input-field" Placeholder="Full Name" required="true"></asp:TextBox>
        <asp:TextBox ID="txtEmail" runat="server" CssClass="input-field" Placeholder="Email" required="true"></asp:TextBox>
        <asp:TextBox ID="txtMobile" runat="server" CssClass="input-field" Placeholder="Mobile Number" required="true"></asp:TextBox>
        <asp:DropDownList ID="ddlState" runat="server" CssClass="input-field">
            <asp:ListItem Value="Gujarat">Gujarat</asp:ListItem>
            <asp:ListItem Value="Maharashtra">Maharashtra</asp:ListItem>
            <asp:ListItem Value="Rajasthan">Rajasthan</asp:ListItem>
        </asp:DropDownList>
        <asp:TextBox ID="txtCity" runat="server" CssClass="input-field" Placeholder="City" required="true"></asp:TextBox>
        <asp:TextBox ID="txtAddress" runat="server" CssClass="input-field" Placeholder="Address" TextMode="MultiLine" required="true"></asp:TextBox>
        <asp:TextBox ID="txtPassword" runat="server" CssClass="input-field" Placeholder="Password" TextMode="Password" required="true"></asp:TextBox>
        <asp:TextBox ID="txtConfirmPassword" runat="server" CssClass="input-field" Placeholder="Confirm Password" TextMode="Password" required="true"></asp:TextBox>
        <asp:Button ID="btnSignUp" runat="server" Text="Sign Up" CssClass="btn" OnClick="btnSignUp_Click"/>
        <br /><br />
        <a href="StudentLogin.aspx">Already have an account? Login here</a>
    </div>
    </form>
</body>
</html>