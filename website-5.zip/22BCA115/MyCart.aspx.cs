﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MyCart : Page
{
    string connectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\gkpat\OneDrive\Desktop\22BCA115\App_Data\Database.mdf;Integrated Security=True;User Instance=True";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserEmail"] == null)
        {
            Response.Redirect("login.aspx");
            return;
        }

        if (!IsPostBack)
        {
            LoadCart();
        }
    }

    private void LoadCart()
    {
        string userEmail = Session["UserEmail"].ToString();
        using (SqlConnection con = new SqlConnection(connectionString))
        {
            string query = "SELECT BookID, BookName, BookImage, BookPrice, Quantity FROM Cart WHERE UserEmail = @UserEmail";
            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                cmd.Parameters.AddWithValue("@UserEmail", userEmail);
                using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                {
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    gvCart.DataSource = dt;
                    gvCart.DataBind();

                    // Calculate total price
                    decimal totalPrice = 0;
                    foreach (DataRow row in dt.Rows)
                    {
                        totalPrice += Convert.ToDecimal(row["BookPrice"]) * Convert.ToInt32(row["Quantity"]);
                    }
                    lblTotalPrice.Text = totalPrice.ToString("C");
                }
            }
        }
    }

    protected void gvCart_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        string userEmail = Session["UserEmail"].ToString();
        int productId = Convert.ToInt32(e.CommandArgument);

        using (SqlConnection con = new SqlConnection(connectionString))
        {
            con.Open();

            if (e.CommandName == "UpdateQuantity")
            {
                GridViewRow row = (GridViewRow)((Control)e.CommandSource).NamingContainer;
                TextBox txtQuantity = (TextBox)row.FindControl("txtQuantity");

                int newQuantity;
                if (int.TryParse(txtQuantity.Text, out newQuantity) && newQuantity > 0)
                {
                    string updateQuery = "UPDATE Cart SET Quantity = @Quantity WHERE UserEmail = @UserEmail AND BookID = @BookID";
                    using (SqlCommand cmd = new SqlCommand(updateQuery, con))
                    {
                        cmd.Parameters.AddWithValue("@Quantity", newQuantity);
                        cmd.Parameters.AddWithValue("@UserEmail", userEmail);
                        cmd.Parameters.AddWithValue("@BookID", productId);
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            else if (e.CommandName == "RemoveItem")
            {
                string deleteQuery = "DELETE FROM Cart WHERE UserEmail = @UserEmail AND BookID = @BookID";
                using (SqlCommand cmd = new SqlCommand(deleteQuery, con))
                {
                    cmd.Parameters.AddWithValue("@UserEmail", userEmail);
                    cmd.Parameters.AddWithValue("@BookID", productId);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        LoadCart();
    }

    protected void btnCheckout_Click(object sender, EventArgs e)
    {
        Response.Redirect("Checkout.aspx");
    }
}
