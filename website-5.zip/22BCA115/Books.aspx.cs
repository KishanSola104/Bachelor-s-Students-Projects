﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI.WebControls;


public partial class Books : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserEmail"] == null)
            {
                Response.Redirect("login.aspx");
            }
            else
            {
                // Label1.Text = "Welcome, " + Session["UserEmail"].ToString();
            }

            BindProducts();
        }
    }


    private void BindProducts()
    {
        string connectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\gkpat\OneDrive\Desktop\22BCA115\App_Data\Database.mdf;Integrated Security=True;User Instance=True";

        using (SqlConnection con = new SqlConnection(connectionString))
        {
            try
            {
                con.Open();

                // Fetch 4 Namkeen products
                //   string queryNamkeen = "SELECT TOP 4 Product_ID, Product_Name, Price, Image FROM Products WHERE Category = 'Collection' ORDER BY NEWID()";


                // Fetch 4 Namkeen products
                string queryNamkeen = "SELECT  Book_ID, Book_Name, Price, Author , Image FROM Books  ORDER BY NEWID()";
                using (SqlCommand cmd = new SqlCommand(queryNamkeen, con))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        DataTable dtNamkeen = new DataTable();
                        sda.Fill(dtNamkeen);
                        Repeater1.DataSource = dtNamkeen;
                        Repeater1.DataBind();
                    }
                }


              
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('Error: " + ex.Message + "');</script>");
            }
        }
    }


    protected void btnAddToCart_Click(object sender, EventArgs e)
    {
        if (Session["UserEmail"] == null)
        {
            Response.Redirect("login.aspx"); // Redirect to login if user is not logged in
            return;
        }

        Button btn = (Button)sender;
        string productIdString = btn.CommandArgument;

        // Declare productId before using int.TryParse
        int productId;
        if (string.IsNullOrEmpty(productIdString) || !int.TryParse(productIdString, out productId))
        {
            Response.Write("<script>alert('Invalid Book ID.');</script>");
            return;
        }

        string userEmail = Session["UserEmail"].ToString();

        string connectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\gkpat\OneDrive\Desktop\22BCA115\App_Data\Database.mdf;Integrated Security=True;User Instance=True";

        using (SqlConnection con = new SqlConnection(connectionString))
        {
            try
            {
                con.Open();

                // Check if the product is already in the cart
                string checkQuery = "SELECT COUNT(*) FROM Cart WHERE UserEmail = @UserEmail AND BookID = @BookID";
                using (SqlCommand cmd = new SqlCommand(checkQuery, con))
                {
                    cmd.Parameters.AddWithValue("@UserEmail", userEmail);
                    cmd.Parameters.AddWithValue("@BookID", productId);
                    int count = (int)cmd.ExecuteScalar();

                    if (count > 0)
                    {
                        // If product exists, increase quantity
                        string updateQuery = "UPDATE Cart SET Quantity = Quantity + 1 WHERE UserEmail = @UserEmail AND BookID = @BookID";
                        using (SqlCommand updateCmd = new SqlCommand(updateQuery, con))
                        {
                            updateCmd.Parameters.AddWithValue("@UserEmail", userEmail);
                            updateCmd.Parameters.AddWithValue("@BookID", productId);
                            updateCmd.ExecuteNonQuery();
                        }
                    }
                    else
                    {
                        // If product is new, insert into cart
                        string insertQuery = "INSERT INTO Cart (UserEmail, BookID, BookName, BookImage, BookPrice, Quantity, DateAdded) VALUES (@UserEmail, @BookID, @BookName, @BookImage, @BookPrice, @Quantity, GETDATE())";
                        using (SqlCommand insertCmd = new SqlCommand(insertQuery, con))
                        {
                            insertCmd.Parameters.AddWithValue("@UserEmail", userEmail);
                            insertCmd.Parameters.AddWithValue("@BookID", productId);
                            insertCmd.Parameters.AddWithValue("@BookName", GetProductDetail(productId, "Book_Name"));
                            insertCmd.Parameters.AddWithValue("@BookImage", GetProductDetail(productId, "Image"));

                            string priceStr = GetProductDetail(productId, "Price");

                            // Validate Price before conversion
                            decimal productPrice;
                            if (string.IsNullOrEmpty(priceStr) || !decimal.TryParse(priceStr, out productPrice))
                            {
                                Response.Write("<script>alert('Invalid Book Price.');</script>");
                                return;
                            }

                            insertCmd.Parameters.AddWithValue("@BookPrice", productPrice);
                            insertCmd.Parameters.AddWithValue("@Quantity", 1);
                            insertCmd.ExecuteNonQuery();
                        }
                    }
                }

                // Show success message
                Response.Write("<script>alert('Book added to cart successfully!');</script>");
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('Error: " + ex.Message + "');</script>");
            }
        }
    }


    private string GetProductDetail(int productId, string columnName)
    {
        string connectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\gkpat\OneDrive\Desktop\22BCA098\App_Data\Database.mdf;Integrated Security=True;User Instance=True";
        string value = "";

        using (SqlConnection con = new SqlConnection(connectionString))
        {
            con.Open();
            string query = "SELECT " + columnName + " FROM Products WHERE Product_ID = @ProductID"; // Removed $ sign
            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                cmd.Parameters.AddWithValue("@ProductID", productId);
                object result = cmd.ExecuteScalar();
                if (result != null)
                {
                    value = result.ToString();
                }
            }
        }
        return value;
    }


}
