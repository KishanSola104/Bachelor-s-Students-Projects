﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Checkout : Page
{
    string connectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\gkpat\OneDrive\Desktop\22BCA115\App_Data\Database.mdf;Integrated Security=True;User Instance=True";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserEmail"] == null)
        {
            Response.Redirect("login.aspx");
            return;
        }

        if (!IsPostBack)
        {
            LoadUserDetails();
            LoadCart();
        }
    }

    private void LoadUserDetails()
    {
        string userEmail = Session["UserEmail"].ToString();
        using (SqlConnection con = new SqlConnection(connectionString))
        {
            string query = "SELECT name, email, mobile, address FROM Users WHERE Email = @Email";
            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                cmd.Parameters.AddWithValue("@Email", userEmail);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    lblName.Text = "Name: " + dr["name"].ToString();
                    lblEmail.Text = "Email: " + dr["email"].ToString();
                    lblPhone.Text = "Phone: " + dr["mobile"].ToString();
                    lblAddress.Text = "Address: " + dr["address"].ToString();
                }
            }
        }
    }

    private void LoadCart()
    {
        string userEmail = Session["UserEmail"].ToString();
        using (SqlConnection con = new SqlConnection(connectionString))
        {
            string query = "SELECT BookName, BookPrice, Quantity, (BookPrice * Quantity) AS TotalPrice FROM Cart WHERE UserEmail = @UserEmail";
            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                cmd.Parameters.AddWithValue("@UserEmail", userEmail);
                using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                {
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    gvCart.DataSource = dt;
                    gvCart.DataBind();

                    decimal totalPrice = 0;
                    foreach (DataRow row in dt.Rows)
                    {
                        totalPrice += Convert.ToDecimal(row["TotalPrice"]);
                    }
                    lblTotalPrice.Text = totalPrice.ToString("C");
                }
            }
        }
    }

    protected void btnPayNow_Click(object sender, EventArgs e)
    {
        if (ddlPaymentMethod.SelectedValue == "")
        {
            Response.Write("<script>alert('Please select a payment method.');</script>");
            return;
        }

        string userEmail = Session["UserEmail"].ToString();
        string paymentMethod = ddlPaymentMethod.SelectedValue;
        decimal totalPrice = decimal.Parse(lblTotalPrice.Text, System.Globalization.NumberStyles.Currency);

        using (SqlConnection con = new SqlConnection(connectionString))
        {
            con.Open();
            string insertOrder = "INSERT INTO Payment (UserEmail, TotalAmount, PaymentMethod, PaymentDate) VALUES (@UserEmail, @TotalAmount, @PaymentMethod, GETDATE())";
            using (SqlCommand cmd = new SqlCommand(insertOrder, con))
            {
                cmd.Parameters.AddWithValue("@UserEmail", userEmail);
                cmd.Parameters.AddWithValue("@TotalAmount", totalPrice);
                cmd.Parameters.AddWithValue("@PaymentMethod", paymentMethod);
                cmd.ExecuteNonQuery();
            }

            string deleteCart = "DELETE FROM Cart WHERE UserEmail = @UserEmail";
            using (SqlCommand cmd = new SqlCommand(deleteCart, con))
            {
                cmd.Parameters.AddWithValue("@UserEmail", userEmail);
                cmd.ExecuteNonQuery();
            }
        }

        Response.Write("<script>alert('Your payment was successfully made.');</script>");
        Response.Redirect("OrderConfirmation.aspx");
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("MyCart.aspx");
    }
}
