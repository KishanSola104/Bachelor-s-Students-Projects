﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;

public partial class AdminResetPassword : Page
{
    // Define the AdminDetails class here
    public class AdminDetails
    {
        public string AdminName { get; set; }
        public string ImageUrl { get; set; }
    }

    // Page_Load event
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DateTime yesterday = DateTime.Now.AddDays(-1);


            if (Session["AdminEmail"] == null)
            {
                Response.Redirect("AdminLogin.aspx"); // Redirect if session is empty
                return; // Stop execution
            }

            string adminEmail = (Session["AdminEmail"] != null) ? Session["AdminEmail"].ToString() : string.Empty;
            AdminDetails adminDetails = GetAdminDetails(adminEmail); // Get admin details (name & image)

            lblAdminName.Text = !string.IsNullOrEmpty(adminDetails.AdminName) ? adminDetails.AdminName : "Admin"; // Set admin name
            if (!string.IsNullOrEmpty(adminDetails.ImageUrl))
            {
                imgAdminProfile.ImageUrl = adminDetails.ImageUrl; // Set admin image URL
            }
            else
            {
                imgAdminProfile.ImageUrl = "~/images/default-profile.png"; // Fallback image
            }


            string adminEmail1 = Session["AdminEmail"].ToString();
            AdminDetails adminDetails1 = GetAdminDetails(adminEmail1);




        }
    }

    // Method to get admin details from the database
    private AdminDetails GetAdminDetails(string email)
    {
        AdminDetails adminDetails = new AdminDetails
        {
            AdminName = "Admin", // Default value
            ImageUrl = "" // Default value for image URL
        };

        string connStr = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\gkpat\OneDrive\Desktop\22BCA115\App_Data\Database.mdf;Integrated Security=True;User Instance=True";

        try
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string query = "SELECT name, image FROM admins WHERE email = @Email";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Email", email);
                    conn.Open();

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            adminDetails.AdminName = reader["name"].ToString();
                            adminDetails.ImageUrl = reader["image"] != DBNull.Value ? reader["image"].ToString() : "";
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            // Log the error (optional)
            System.Diagnostics.Debug.WriteLine("Database Error: " + ex.Message);
        }

        return adminDetails; // Return the AdminDetails object
    }

    // Logout button click handler
    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Redirect("AdminLogin.aspx"); // Redirect to login after logout
    }


    private void ShowAlert(string message)
    {
        string script = "alert('" + message.Replace("'", "\\'") + "');";
        ClientScript.RegisterStartupScript(this.GetType(), "alert", script, true);
    }

    protected void btnResetPassword_Click(object sender, EventArgs e)
    {
        // Ensure session exists
        if (Session["AdminEmail"] == null)
        {
            ShowAlert("Session expired. Please log in again.");
            Response.Redirect("AdminLogin.aspx");
            return;
        }

        string adminEmail = Session["AdminEmail"].ToString();

        // Ensure password fields exist on the page
        if (txtOldPassword == null || txtNewPassword == null || txtConfirmPassword == null)
        {
            ShowAlert("Error: Password fields are missing on the page.");
            return;
        }

        // Get user input
        string oldPassword = txtOldPassword.Text.Trim();
        string newPassword = txtNewPassword.Text.Trim();
        string confirmPassword = txtConfirmPassword.Text.Trim();

        // Validate input fields
        if (string.IsNullOrEmpty(oldPassword) || string.IsNullOrEmpty(newPassword) || string.IsNullOrEmpty(confirmPassword))
        {
            ShowAlert("All fields are required.");
            return;
        }

        if (newPassword != confirmPassword)
        {
            ShowAlert("New password and confirm password do not match.");
            return;
        }

        // Get database connection string
        string connStr = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\gkpat\OneDrive\Desktop\22BCA115\App_Data\Database.mdf;Integrated Security=True;User Instance=True";
        if (string.IsNullOrEmpty(connStr))
        {
            ShowAlert("Database connection error. Please try again later.");
            return;
        }

        bool isOldPasswordCorrect = false;

        try
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();

                // Validate old password
                string checkPasswordQuery = "SELECT password FROM admins WHERE email = @Email";
                using (SqlCommand cmd = new SqlCommand(checkPasswordQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@Email", adminEmail);
                    object result = cmd.ExecuteScalar();

                    // FIX: Remove null-conditional operator (?.) and use explicit null check
                    string storedPassword = (result != null) ? result.ToString() : "";

                    if (storedPassword == oldPassword)
                    {
                        isOldPasswordCorrect = true;
                    }
                }

                if (!isOldPasswordCorrect)
                {
                    ShowAlert("Incorrect current password.");
                    return;
                }

                // Update new password
                string updatePasswordQuery = "UPDATE admins SET password = @NewPassword WHERE email = @Email";
                using (SqlCommand cmd = new SqlCommand(updatePasswordQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@NewPassword", newPassword);
                    cmd.Parameters.AddWithValue("@Email", adminEmail);

                    int rowsAffected = cmd.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        ShowAlert("Password reset successfully!");
                    }
                    else
                    {
                        ShowAlert("Password reset failed. Please try again.");
                    }
                }
            }
        }
        catch (Exception ex)
        {
            ShowAlert("Database error: " + ex.Message);
        }
    }


}
