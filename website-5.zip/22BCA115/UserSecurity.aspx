﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="UserSecurity.aspx.cs" Inherits="UserSecurity" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
<title>User Security - Auto Mobile Decor</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f3f4f7;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: white;
            padding: 20px;
            border-radius: 6px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            width: 400px;
            text-align: center;
        }
        
        h1
        {
            color:blue;
            margin-bottom:15px;
        }
        h2 {
            color: #333;
            margin-bottom: 15px;
        }
        .input {
            width: 90%;
            padding: 10px;
            margin: 8px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
            background-color: #f9f9f9;
            outline: none;
        }
        .button {
            width: 100%;
            padding: 12px;
            background-color: #2980b9;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 15px;
        }
        .button:hover {
            background-color: #3498db;
        }
        .error-message {
            color: red;
            font-size: 12px;
            text-align: left;
            display: block;
            margin-bottom: 5px;
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="container">
         <h1>Buy Your Book</h1>
            <h2>User Security Questions</h2>

            <asp:TextBox ID="txtFirstSchool" runat="server" CssClass="input" placeholder="What is Your First School?"></asp:TextBox>
            <asp:RequiredFieldValidator ID="rfvFirstSchool" runat="server" ControlToValidate="txtFirstSchool"
                ErrorMessage="This field is required" CssClass="error-message" Display="Dynamic" />

            <asp:TextBox ID="txtBirthPlace" runat="server" CssClass="input" placeholder="What is Your Birth Place Name?"></asp:TextBox>
            <asp:RequiredFieldValidator ID="rfvBirthPlace" runat="server" ControlToValidate="txtBirthPlace"
                ErrorMessage="This field is required" CssClass="error-message" Display="Dynamic" />

       

            <asp:Button ID="btnSaveSecurity" runat="server" Text="Save Security Info" CssClass="button" OnClick="btnSaveSecurity_Click" />
        </div>
    </form>
</body>
