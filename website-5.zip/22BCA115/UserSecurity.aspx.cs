﻿using System;
using System.Configuration;
using System.Data.SqlClient;

public partial class UserSecurity : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // Check if session variable exists
        if (Session["UserEmail"] != null)
        {
            // lblEmail.Text = "Email: " + Session["UserEmail"].ToString(); // Display email
        }
        else
        {
            Response.Redirect("SignUp.aspx"); // Redirect if session expired
        }
    }

    protected void btnSaveSecurity_Click(object sender, EventArgs e)
    {
        string userEmail = Session["UserEmail"].ToString();
        string connStr = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\gkpat\OneDrive\Desktop\22BCA115\App_Data\Database.mdf;Integrated Security=True;User Instance=True";

        using (SqlConnection conn = new SqlConnection(connStr))
        {
            try
            {
                conn.Open();
                string query = "INSERT INTO UserSecurity (email, firstschool, birthplace) " +
                               "VALUES (@Email, @FirstSchool, @BirthPlace)";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Email", userEmail);
                    cmd.Parameters.AddWithValue("@FirstSchool", txtFirstSchool.Text.Trim());
                    cmd.Parameters.AddWithValue("@BirthPlace", txtBirthPlace.Text.Trim());


                    int rowsAffected = cmd.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        Response.Write("<script>alert('Security Information Saved Successfully!'); window.location='login.aspx';</script>");
                    }
                    else
                    {
                        Response.Write("<script>alert('Failed to save security information. Please try again.');</script>");
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('Error: " + ex.Message + "');</script>");
            }
        }
    }
}
