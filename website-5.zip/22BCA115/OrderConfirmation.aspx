﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="OrderConfirmation.aspx.cs" Inherits="OrderConfirmation" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>Order Confirmation</title>
  <style>
 body {
    font-family: Arial, sans-serif;
    background-color: #f8f9fa;
}

.confirmation-container {
    width: 50%;
    margin: auto;
    background: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    text-align: center;
}

h2, h3 {
    color: #333;
}

p {
    font-size: 16px;
    margin-bottom: 10px;
}

.btn-home {
    background-color: #007bff;
    color: white;
    padding: 10px 20px;
    font-size: 16px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    margin-top: 20px;
}

  </style>
</head>
<body>
<form id="form1" runat="server">
        <div class="confirmation-container">
            <h2>Thank You for Your Purchase!</h2>
            <p>Your Books ordered has been successfully placed.</p>

            <h3>Order Details</h3>
            <p><strong>Email:</strong> <asp:Label ID="lblUserEmail" runat="server"></asp:Label></p>
            <p><strong>Total Amount:</strong> <asp:Label ID="lblTotalAmount" runat="server"></asp:Label></p>
            <p><strong>Payment Method:</strong> <asp:Label ID="lblPaymentMethod" runat="server"></asp:Label></p>
            <p><strong>Payment Date:</strong> <asp:Label ID="lblPaymentDate" runat="server"></asp:Label></p>
            <p>An email confirmation has been sent to you.</p>

            <asp:Button ID="btnBackToHome" runat="server" Text="Continue Buying" CssClass="btn-home" OnClick="btnBackToHome_Click" />
        </div>
    </form>
</body>
</html>