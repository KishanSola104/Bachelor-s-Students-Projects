﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI.WebControls;

public partial class UserDashboard : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserEmail"] == null)
            {
                Response.Redirect("login.aspx");
            }

            BindProducts();
        }
    }

    private void BindProducts()
    {
        string connectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\gkpat\OneDrive\Desktop\22BCA115\App_Data\Database.mdf;Integrated Security=True;User Instance=True";

        using (SqlConnection con = new SqlConnection(connectionString))
        {
            try
            {
                con.Open();

                // Fetch Finance Books
                string queryFinance = "SELECT TOP 4 Book_ID, Book_Name, Price, Author, Image FROM Books WHERE Category = 'Finance' ORDER BY NEWID()";
                using (SqlCommand cmd = new SqlCommand(queryFinance, con))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        DataTable dtFinance = new DataTable();
                        sda.Fill(dtFinance);
                        Repeater1.DataSource = dtFinance;
                        Repeater1.DataBind();
                    }
                }

                // Fetch Marketing Books
                string queryMarketing = "SELECT TOP 4 Book_ID, Book_Name, Price, Author, Image FROM Books WHERE Category = 'Marketing' ORDER BY NEWID()";
                using (SqlCommand cmd = new SqlCommand(queryMarketing, con))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        DataTable dtMarketing = new DataTable();
                        sda.Fill(dtMarketing);
                        rptSweets.DataSource = dtMarketing;
                        rptSweets.DataBind();
                    }
                }

                // Fetch Marketing Books
                string queryMarketing1 = "SELECT TOP 4 Book_ID, Book_Name, Price, Author, Image FROM Books WHERE Category = 'HR' ORDER BY NEWID()";
                using (SqlCommand cmd = new SqlCommand(queryMarketing, con))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        DataTable dtMarketing = new DataTable();
                        sda.Fill(dtMarketing);
                        rptCombos.DataSource = dtMarketing;
                         rptCombos.DataBind();
                    }
                }

                // Fetch Marketing Books
                string queryMarketing2 = "SELECT TOP 4 Book_ID, Book_Name, Price, Author, Image FROM Books WHERE Category = 'Biography' ORDER BY NEWID()";
                using (SqlCommand cmd = new SqlCommand(queryMarketing, con))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        DataTable dtMarketing = new DataTable();
                        sda.Fill(dtMarketing);
                        Repeater2.DataSource = dtMarketing;
                       Repeater2.DataBind();
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('Error: " + ex.Message + "');</script>");
            }
        }
    }

    protected void btnAddToCart_Click(object sender, EventArgs e)
    {
        if (Session["UserEmail"] == null)
        {
            Response.Redirect("login.aspx");
            return;
        }

        Button btn = (Button)sender;
        int bookId = Convert.ToInt32(btn.CommandArgument);
        string userEmail = Session["UserEmail"].ToString();

        string connectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\gkpat\OneDrive\Desktop\22BCA115\App_Data\Database.mdf;Integrated Security=True;User Instance=True";

        using (SqlConnection con = new SqlConnection(connectionString))
        {
            try
            {
                con.Open();

                string query = "INSERT INTO Cart (UserEmail, BookID, BookName, BookImage, BookPrice, Quantity, DateAdded) " +
                               "VALUES (@UserEmail, @BookID, @BookName, @BookImage, @BookPrice, @Quantity, GETDATE())";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@UserEmail", userEmail);
                    cmd.Parameters.AddWithValue("@BookID", bookId);
                    cmd.Parameters.AddWithValue("@BookName", GetBookDetail(bookId, "Book_Name"));
                    cmd.Parameters.AddWithValue("@BookImage", GetBookDetail(bookId, "Image"));
                    cmd.Parameters.AddWithValue("@BookPrice", Convert.ToDecimal(GetBookDetail(bookId, "Price")));
                    cmd.Parameters.AddWithValue("@Quantity", 1);
                    cmd.ExecuteNonQuery();
                }

                Response.Write("<script>alert('Book added to cart successfully!');</script>");
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('Error: " + ex.Message + "');</script>");
            }
        }
    }

    private string GetBookDetail(int bookId, string column)
    {
        string connectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\gkpat\OneDrive\Desktop\22BCA115\App_Data\Database.mdf;Integrated Security=True;User Instance=True";
        using (SqlConnection con = new SqlConnection(connectionString))
        {
            con.Open();
            string query = "SELECT " + column + " FROM Books WHERE Book_ID = @BookID";
            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                cmd.Parameters.AddWithValue("@BookID", bookId);
                object result = cmd.ExecuteScalar();
                return (result != null) ? result.ToString() : "";

            }
        }
    }
}
