﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="SignUp.aspx.cs" Inherits="SignUp" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
<title>Sign Up</title>
    <style>
      

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f3f4f7;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            overflow: auto;
        }

        .container 
        {
            margin-top:70px;
            background-color: #ffffff;
            padding: 25px;
            border-radius: 6px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            width: 400px;
            text-align: center;
            margin-top: 40px;
        }

        .logo 
        {
            margin-top:30px;
            font-size: 24px;
            font-weight: bold;
            color: blue;
            margin-bottom: 10px;
        }

        h1 {
            font-size: 22px;
            font-weight: 600;
            color: #333;
            margin-bottom: 15px;
        }

        .input, .textarea, .dropdown {
            width: 90%;
            padding: 10px;
            margin: 8px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
            background-color: #f9f9f9;
            outline: none;
        }

        .textarea {
            resize: none;
            height: 70px;
        }

        .radio-group {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin: 10px 0;
        }

        .radio-group label {
            font-size: 14px;
            color: #555;
        }

        .button {
            width: 100%;
            padding: 12px;
            background-color: #2980b9;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 15px;
        }

        .button:hover {
            background-color: #3498db;
        }

        .error-message {
            color: red;
            font-size: 12px;
            text-align: left;
            display: block;
            margin-bottom: 5px;
        }

        .back-to-login {
            margin-top: 10px;
            font-size: 14px;
            color: #555;
        }

        .back-to-login a {
            color: #2980b9;
            text-decoration: none;
            font-weight: bold;
        }

        .back-to-login a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <form id="signupForm" runat="server">
        <div class="container">
            <div class="logo">Buy Your Book</div>
            <h1>Sign Up</h1>

            <asp:TextBox ID="txtName" runat="server" CssClass="input" placeholder="Full Name"></asp:TextBox>
            <asp:RequiredFieldValidator ID="rfvName" runat="server" ControlToValidate="txtName"
                ErrorMessage="Full Name is required" CssClass="error-message" Display="Dynamic" />

            <asp:TextBox ID="txtEmail" runat="server" CssClass="input" placeholder="Email"></asp:TextBox>
            <asp:RequiredFieldValidator ID="rfvEmail" runat="server" ControlToValidate="txtEmail"
                ErrorMessage="Email is required" CssClass="error-message" Display="Dynamic" />
            <asp:RegularExpressionValidator ID="revEmail" runat="server" ControlToValidate="txtEmail"
                ValidationExpression="^[^@\s]+@[^@\s]+\.[^@\s]+$" ErrorMessage="Enter a valid email address"
                CssClass="error-message" Display="Dynamic" />

            <asp:TextBox ID="txtMobile" runat="server" CssClass="input" placeholder="Mobile Number"></asp:TextBox>
            <asp:RequiredFieldValidator ID="rfvMobile" runat="server" ControlToValidate="txtMobile"
                ErrorMessage="Mobile number is required" CssClass="error-message" Display="Dynamic" />
            <asp:RegularExpressionValidator ID="revMobile" runat="server" ControlToValidate="txtMobile"
                ValidationExpression="^\d{10}$" ErrorMessage="Enter a valid 10-digit mobile number"
                CssClass="error-message" Display="Dynamic" />

            <asp:DropDownList ID="ddlCity" runat="server" CssClass="dropdown">
                <asp:ListItem Value="">Select City</asp:ListItem>
                <asp:ListItem Value="Anand">Anand</asp:ListItem>
                <asp:ListItem Value="Vasad">Vasad</asp:ListItem>
                <asp:ListItem Value="Vadodara">Vadodara</asp:ListItem>
            </asp:DropDownList>
            <asp:RequiredFieldValidator ID="rfvCity" runat="server" ControlToValidate="ddlCity"
                InitialValue="" ErrorMessage="Please select a city" CssClass="error-message" Display="Dynamic" />

            <asp:TextBox ID="txtDOB" runat="server" CssClass="input" TextMode="Date"></asp:TextBox>
            <asp:RequiredFieldValidator ID="rfvDOB" runat="server" ControlToValidate="txtDOB"
                ErrorMessage="Date of Birth is required" CssClass="error-message" Display="Dynamic" />

            <div class="radio-group">
                <label>Gender:</label>
                <asp:RadioButton ID="rbMale" runat="server" GroupName="gender" /> Male
                <asp:RadioButton ID="rbFemale" runat="server" GroupName="gender" /> Female
                <asp:RadioButton ID="rbOther" runat="server" GroupName="gender" /> Other
            </div>

            <asp:TextBox ID="txtAddress" runat="server" CssClass="textarea" TextMode="MultiLine" placeholder="Full Address"></asp:TextBox>
            <asp:RequiredFieldValidator ID="rfvAddress" runat="server" ControlToValidate="txtAddress"
                ErrorMessage="Full Address is required" CssClass="error-message" Display="Dynamic" />

            <asp:TextBox ID="txtPincode" runat="server" CssClass="input" placeholder="Pincode"></asp:TextBox>
            <asp:RequiredFieldValidator ID="rfvPincode" runat="server" ControlToValidate="txtPincode"
                ErrorMessage="Pincode is required" CssClass="error-message" Display="Dynamic" />
            <asp:RegularExpressionValidator ID="revPincode" runat="server" ControlToValidate="txtPincode"
                ValidationExpression="^\d{6}$" ErrorMessage="Enter a valid 6-digit pincode"
                CssClass="error-message" Display="Dynamic" />

            <asp:TextBox ID="txtPassword" runat="server" CssClass="input" TextMode="Password" placeholder="Password"></asp:TextBox>
            <asp:RequiredFieldValidator ID="rfvPassword" runat="server" ControlToValidate="txtPassword"
                ErrorMessage="Password is required" CssClass="error-message" Display="Dynamic" />

            <asp:TextBox ID="txtConfirmPassword" runat="server" CssClass="input" TextMode="Password" placeholder="Confirm Password"></asp:TextBox>
            <asp:CompareValidator ID="cvPassword" runat="server" ControlToValidate="txtConfirmPassword"
                ControlToCompare="txtPassword" Operator="Equal"
                ErrorMessage="Passwords do not match" CssClass="error-message" Display="Dynamic" />

            <asp:Button ID="btnSignUp" runat="server" Text="Create Account" 
                CssClass="button" onclick="btnSignUp_Click1" />

            <p class="back-to-login">Already have an account? <a href="login.aspx">Login</a></p>
        </div>
    </form>
</body>
</html>
