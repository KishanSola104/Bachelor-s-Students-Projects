﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="AdminResetPassword.aspx.cs" Inherits="AdminResetPassword" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
<title>Admin Reset password</title>
 
  <style>
        /* General Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        /* Admin Header Styling */
        .admin-header {
            background-color: blue;
            color: white;
            font-size: large;
            font-weight: bold;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 100; /* Keeps the header above the sidebar */
            position: fixed;
            width: 100%;
            top: 0;
        }

        .admin-info {
            display: flex;
            align-items: center;
        }

        .admin-profile-img {
            border-radius: 50%;
            border: 2px solid #fff;
            object-fit: cover;
            margin-left: 10px;
        }

        .logout-btn {
            margin-left: 15px;
            background-color: #f44336;
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
        }

        .logout-btn:hover {
            background-color: #d32f2f;
        }

        /* Main Content */
        .main-content {
            margin-left: 200px; /* Adjusted for sidebar width */
            padding: 20px;
            transition: margin-left 0.3s;
            margin-top: 60px; /* To account for header height */
        }

        /* Footer Styling */
        footer {
            background-color: blue;
            color: white;
            text-align: center;
            padding: 10px;
            position: fixed;
            width: 100%;
            bottom: 0;
        }

        /* Sidebar Styling */
        .sidebar {
            width: 180px; /* Reduced width */
            background: #222;
            color: white;
            padding: 15px;
            position: fixed;
            height: 100%;
            transition: 0.3s ease-in-out;
        }

        .sidebar a {
            display: flex;
            align-items: center;
            color: white;
            padding: 12px;
            font-size: 14px;
            text-decoration: none;
            transition: background 0.3s ease-in-out;
        }

        .sidebar a i {
            margin-right: 10px;
            font-size: 16px;
        }

        .sidebar a:hover {
            background: #333;
            border-radius: 5px;
        }

        /* Settings Dropdown */
        .settings {
            margin-top: 10px;
        }

        .settings a {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .dropdown {
            display: none;
            background: #333;
            padding: 5px;
            border-radius: 5px;
            flex-direction: column;
        }

        .dropdown a {
            padding: 8px 15px;
            font-size: 13px;
            display: flex;
            align-items: center;
            gap: 10px;
            transition: 0.3s;
        }

        .dropdown a:hover {
            background: #444;
        }

        .settings .fa-chevron-down {
            transition: transform 0.3s ease;
        }

        .settings.open .fa-chevron-down {
            transform: rotate(180deg);
        }
        
        
        
         /* Quick Actions Styling */
.quick-actions {
    display: flex;
    justify-content: center;
    gap: 15px;
    margin-bottom: 15px;
}

.action-btn {
    background: #ff9800;
    color: white;
    text-decoration: none;
    padding: 10px 15px;
    border-radius: 5px;
    transition: background 0.3s;
}

.action-btn:hover {
    background: #e68900;
}

.action-btn.logout {
    background: #f44336;
}

.action-btn.logout:hover {
    background: #d32f2f;
}
        
        
        /* Reset Password Section */
.reset-password-container {
    text-align: center;
    margin: auto;
    max-width: 400px;
    padding: 20px;
}

.reset-card {
    background: blue;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    text-align: left;
}

.reset-card label {
    display: block;
    font-weight: bold;
    margin-top: 10px;
    color: #333;
}

.input-field {
    width: 100%;
    padding: 10px;
    margin-top: 5px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 14px;
}

.reset-btn {
    width: 100%;
    margin-top: 15px;
    padding: 10px;
    background: #ff9800;
    color: white;
    border: none;
    border-radius: 5px;
    font-size: 16px;
    cursor: pointer;
    transition: background 0.3s;
}

.reset-btn:hover {
    background: #e68900;
}

    </style>
</head>
<body>

    <form id="adminDashboardForm" runat="server">
        <!-- Header Section -->
        <header class="admin-header">
            <div class="logo">Buy Your Book</div>
            <div class="admin-info">
                <span>Welcome, <asp:Label ID="lblAdminName" runat="server" Text="Admin"></asp:Label></span>
                <asp:Image ID="imgAdminProfile" runat="server" CssClass="admin-profile-img" Width="40px" Height="40px" />
                <asp:Button ID="btnLogout" runat="server" Text="Logout" CssClass="logout-btn" OnClick="btnLogout_Click" />
            </div>
        </header>

        <!-- Sidebar Section -->
        <div class="sidebar">
            <a href="AdminDashboard.aspx"><i class="fas fa-home"></i>Dashboard</a>
           <a href="ManageProducts.aspx"><i class="fas fa-box"></i> Products</a>

            <a href="orders.aspx"><i class="fas fa-shopping-cart"></i> Orders</a>
            <a href="customers.aspx"><i class="fas fa-users"></i> Customers</a>

            <div class="settings">
                <a href="#" id="settings-btn"><i class="fas fa-cogs"></i> Settings <i class="fas fa-chevron-down"></i></a>
                <div class="dropdown" id="settings-dropdown">
                    <a href="AdminAccount.aspx"><i class="fas fa-user"></i> My Account</a>
                    <a href="AdminResetPassword.aspx"><i class="fas fa-key"></i> Reset Password</a>
                    <a href="Delivery.aspx"><i class="fa fa-truck"></i> Manage Delivery</a>
                    <a href="AdminLogin.aspx"><i class="fas fa-sign-out-alt"></i> Log Out</a>
                </div>
            </div>
        </div>


<!-- Main Content Section -->
<div class="main-content">
    <!-- Quick Actions Section -->
    <div class="quick-actions">
        <a href="AdminAccount.aspx" class="action-btn">My Account</a>
        <a href="AdminResetPassword.aspx" class="action-btn">Reset Password</a>
        <a href="AdminLogin.aspx" class="action-btn logout">Log Out</a>
    </div>

    <hr class="divider"> <!-- Separator Line -->

    <!-- Reset Password Container -->
    <div class="reset-password-container">
        <h2>Reset Password</h2>
        <div class="reset-card">
            <label for="txtOldPassword">Current Password</label>
            <asp:TextBox ID="txtOldPassword" runat="server" CssClass="input-field" TextMode="Password" Placeholder="Enter current password"></asp:TextBox>

            <label for="txtNewPassword">New Password</label>
            <asp:TextBox ID="txtNewPassword" runat="server" CssClass="input-field" TextMode="Password" Placeholder="Enter new password"></asp:TextBox>

            <label for="txtConfirmPassword">Confirm Password</label>
            <asp:TextBox ID="txtConfirmPassword" runat="server" CssClass="input-field" TextMode="Password" Placeholder="Confirm new password"></asp:TextBox>

            <asp:Button ID="btnResetPassword" runat="server" Text="Reset Password" 
                CssClass="reset-btn" onclick="btnResetPassword_Click"  />
        </div>
    </div>
</div>



        <!-- Footer Section -->
        <footer>
            <p>© 2025 Buy Your Book. All Rights Reserved.</p>
        </footer>

    </form>

    <!-- JavaScript for Settings Dropdown -->
    <script>
        document.getElementById('settings-btn').addEventListener('click', function (event) {
            event.preventDefault();
            var dropdown = document.getElementById('settings-dropdown');
            var settings = document.querySelector('.settings');

            dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
            settings.classList.toggle('open');
        });
    </script>
</body>
</html>