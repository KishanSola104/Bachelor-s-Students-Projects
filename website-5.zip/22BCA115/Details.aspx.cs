﻿using System;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Details : Page
{
    string connectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\gkpat\OneDrive\Desktop\22BCA115\App_Data\Database.mdf;Integrated Security=True;User Instance=True";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request.QueryString["ID"] != null)
            {
                int productId;
                if (int.TryParse(Request.QueryString["ID"], out productId))
                {
                    LoadProductDetails(productId);
                    btnAddToCart.CommandArgument = productId.ToString(); // Store Product ID in button
                }
                else
                {
                    Response.Write("<script>alert('Invalid Book ID.');</script>");
                    Response.Redirect("UserDashboard.aspx");
                }
            }
            else
            {
                Response.Redirect("UserDashboard.aspx");
            }
        }
    }

    private void LoadProductDetails(int productId)
    {
        using (SqlConnection con = new SqlConnection(connectionString))
        {
            string query = "SELECT Book_Name, Image, Price, Description, Category FROM Books WHERE Book_ID = @BookID";
            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                cmd.Parameters.AddWithValue("@BookID", productId);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    lblProductName.Text = dr["Book_Name"].ToString();
                    imgProduct.ImageUrl = dr["Image"].ToString();
                    lblPrice.Text = "₹" + Convert.ToDecimal(dr["Price"]).ToString("N2");
                    lblDescription.Text = dr["Description"].ToString();
                    lblCategory.Text = dr["Category"].ToString();
                }
                else
                {
                    Response.Write("<script>alert('Book not found.');</script>");
                    Response.Redirect("UserDashboard.aspx");
                }
            }
        }
    }

    protected void btnAddToCart_Click(object sender, EventArgs e)
    {
        if (Session["UserEmail"] == null)
        {
            Response.Redirect("login.aspx");
            return;
        }

        // Get User Email from Session
        string userEmail = Session["UserEmail"].ToString();

        // Get Product ID from the Button Command Argument
        Button btn = (Button)sender;
        int productId;
        if (!int.TryParse(btn.CommandArgument, out productId))
        {
            Response.Write("<script>alert('Invalid Book ID');</script>");
            return;
        }

        // Get Product Price from the Label and Convert it to Decimal
        decimal productPrice;
        if (!decimal.TryParse(lblPrice.Text.Replace("₹", "").Trim(), out productPrice))
        {
            Response.Write("<script>alert('Invalid Product Price');</script>");
            return;
        }

        // Get Product Name and Image
        string productName = lblProductName.Text;
        string productImage = imgProduct.ImageUrl;

        using (SqlConnection con = new SqlConnection(connectionString))
        {
            try
            {
                con.Open();

                // Check if the product is already in the cart
                string checkQuery = "SELECT COUNT(*) FROM Cart WHERE UserEmail = @UserEmail AND BookID = @BookID";
                using (SqlCommand cmd = new SqlCommand(checkQuery, con))
                {
                    cmd.Parameters.AddWithValue("@UserEmail", userEmail);
                    cmd.Parameters.AddWithValue("@BookID", productId);
                    int count = (int)cmd.ExecuteScalar();

                    if (count > 0)
                    {
                        // If the product exists, increase quantity
                        string updateQuery = "UPDATE Cart SET Quantity = Quantity + 1 WHERE UserEmail = @UserEmail AND ProductID = @BookID";
                        using (SqlCommand updateCmd = new SqlCommand(updateQuery, con))
                        {
                            updateCmd.Parameters.AddWithValue("@UserEmail", userEmail);
                            updateCmd.Parameters.AddWithValue("@BookID", productId);
                            updateCmd.ExecuteNonQuery();
                        }
                    }
                    else
                    {
                        // If the product is new, insert into cart
                        string insertQuery = "INSERT INTO Cart (UserEmail, BookID, BookName, BookImage, BookPrice, Quantity, DateAdded) VALUES (@UserEmail, @BookID, @BookName, @BookImage, @BookPrice, @Quantity, GETDATE())";
                        using (SqlCommand insertCmd = new SqlCommand(insertQuery, con))
                        {
                            insertCmd.Parameters.AddWithValue("@UserEmail", userEmail);
                            insertCmd.Parameters.AddWithValue("@BookID", productId);
                            insertCmd.Parameters.AddWithValue("@BookName", productName);
                            insertCmd.Parameters.AddWithValue("@BookImage", productImage);
                            insertCmd.Parameters.AddWithValue("@BookPrice", productPrice);
                            insertCmd.Parameters.AddWithValue("@Quantity", 1);
                            insertCmd.ExecuteNonQuery();
                        }
                    }
                }

                // Show success message
                Response.Write("<script>alert('Book added to cart successfully!');</script>");
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('Error: " + ex.Message + "');</script>");
            }
        }
    }


    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("UserDashboard.aspx");
    }
}
