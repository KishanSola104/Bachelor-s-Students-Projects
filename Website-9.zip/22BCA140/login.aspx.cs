﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.UI;

public partial class login : Page
{
    string connStr = ConfigurationManager.ConnectionStrings["CESStationaryDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            string query = "SELECT * FROM Users WHERE Email=@Email AND Password=@Password";

            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                cmd.Parameters.AddWithValue("@Password", txtPassword.Text);

                try
                {
                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.HasRows)
                    {
                        Session["UserEmail"] = txtEmail.Text;
                        Response.Redirect("UserDashboard.aspx");
                    }
                    else
                    {
                        lblMessage.Text = "Invalid email or password!";
                    }
                }
                catch (Exception ex)
                {
                    lblMessage.Text = "Error: " + ex.Message;
                }
            }
        }
    }
}
