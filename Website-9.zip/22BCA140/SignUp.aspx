﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="SignUp.aspx.cs" Inherits="SignUp" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Sign Up</title>
    <style>
    /* Reset default browser styles */
/* Reset default styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Arial', sans-serif;
}

/* Full-page styling */
body {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    background: #f4f4f4;
}

/* Centered Sign-Up Box */
.container {
    width: 400px;
    background: #fff;
    padding: 30px;
    border-radius: 8px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    text-align: center;
}

/* Page Title */
h2 {
    margin-bottom: 20px;
    font-size: 22px;
    color: #333;
}

/* Form fields */
.form-group {
    text-align: left;
    margin-bottom: 15px;
}

label {
    font-size: 14px;
    font-weight: 600;
    color: #444;
}

/* Input styling */
input[type="text"],
input[type="email"],
input[type="password"],
select {
    width: 100%;
    padding: 10px;
    margin-top: 5px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 14px;
    transition: border-color 0.3s ease;
}

/* Focus effect */
input:focus, select:focus {
    border-color: #007bff;
    outline: none;
}

/* Sign-Up Button */
.btn {
    width: 100%;
    padding: 10px;
    background: #007bff;
    border: none;
    color: white;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
    border-radius: 5px;
    margin-top: 15px;
    transition: 0.3s ease-in-out;
}

/* Button hover effect */
.btn:hover {
    background: #0056b3;
}

/* Error Message */
#lblMessage {
    margin-top: 10px;
    font-size: 14px;
    color: red;
    font-weight: bold;
}

/* Login Link */
.link {
    display: block;
    margin-top: 15px;
    font-size: 14px;
    color: #007bff;
    text-decoration: none;
    font-weight: bold;
}

/* Link hover effect */
.link:hover {
    text-decoration: underline;
}


    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="container">
    <h2>Sign Up</h2>

    <div class="form-group">
        <asp:Label ID="lblFullName" runat="server" Text="Full Name:"></asp:Label>
        <asp:TextBox ID="txtFullName" runat="server"></asp:TextBox>
    </div>

    <div class="form-group">
        <asp:Label ID="lblEmail" runat="server" Text="Email:"></asp:Label>
        <asp:TextBox ID="txtEmail" runat="server"></asp:TextBox>
    </div>

    <div class="form-group">
        <asp:Label ID="lblMobile" runat="server" Text="Mobile:"></asp:Label>
        <asp:TextBox ID="txtMobile" runat="server"></asp:TextBox>
    </div>

    <div class="form-group">
        <asp:Label ID="lblDepartment" runat="server" Text="Department:"></asp:Label>
        <asp:DropDownList ID="ddlDepartment" runat="server">
            <asp:ListItem Value="">-- Select Department --</asp:ListItem>
            <asp:ListItem>DNICA</asp:ListItem>
            <asp:ListItem>DNIBA</asp:ListItem>
            <asp:ListItem>A.N. Patel</asp:ListItem>
            <asp:ListItem>V.Z. Patel</asp:ListItem>
            <asp:ListItem>Bhikabhai Arts College</asp:ListItem>
            <asp:ListItem>M.B. Patel Science College</asp:ListItem>
        </asp:DropDownList>
    </div>

    <div class="form-group">
        <asp:Label ID="lblStudentID" runat="server" Text="Student ID:"></asp:Label>
        <asp:TextBox ID="txtStudentID" runat="server"></asp:TextBox>
    </div>

    <div class="form-group">
        <asp:Label ID="lblPassword" runat="server" Text="Password:"></asp:Label>
        <asp:TextBox ID="txtPassword" runat="server" TextMode="Password"></asp:TextBox>
    </div>

    <div class="form-group">
        <asp:Label ID="lblConfirmPassword" runat="server" Text="Confirm Password:"></asp:Label>
        <asp:TextBox ID="txtConfirmPassword" runat="server" TextMode="Password"></asp:TextBox>
    </div>

    <asp:Button ID="btnSignUp" CssClass="btn" runat="server" Text="Sign Up" OnClick="btnSignUp_Click" />

    <asp:Label ID="lblMessage" runat="server" ForeColor="Red"></asp:Label>

    <asp:HyperLink ID="lnkLogin" CssClass="link" runat="server" NavigateUrl="Login.aspx">Already have an account? Login here.</asp:HyperLink>
</div>

    </form>
</body>
</html>
