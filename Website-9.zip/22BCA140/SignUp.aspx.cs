﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.UI;

public partial class SignUp : Page
{
    string connStr = ConfigurationManager.ConnectionStrings["CESStationaryDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void btnSignUp_Click(object sender, EventArgs e)
    {
        if (txtPassword.Text != txtConfirmPassword.Text)
        {
            lblMessage.Text = "Passwords do not match!";
            return;
        }

        using (SqlConnection conn = new SqlConnection(connStr))
        {
            string query = "INSERT INTO Users (FullName, Email, Mobile, Department, StudentID, Password) " +
                           "VALUES (@FullName, @Email, @Mobile, @Department, @StudentID, @Password)";

            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@FullName", txtFullName.Text);
                cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                cmd.Parameters.AddWithValue("@Mobile", txtMobile.Text);
                cmd.Parameters.AddWithValue("@Department", ddlDepartment.SelectedValue);
                cmd.Parameters.AddWithValue("@StudentID", txtStudentID.Text);
                cmd.Parameters.AddWithValue("@Password", txtPassword.Text);

                try
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    lblMessage.Text = "Account created successfully!";
                    lblMessage.ForeColor = System.Drawing.Color.Green;
                    Response.Redirect("login.aspx");
                }
                catch (Exception ex)
                {
                    lblMessage.Text = "Error: " + ex.Message;
                }
            }
        }
    }
}
