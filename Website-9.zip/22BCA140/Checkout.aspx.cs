﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;

public partial class Checkout : Page
{
    string connString = ConfigurationManager.ConnectionStrings["CESStationaryDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserEmail"] == null)
        {
            Response.Redirect("login.aspx");
            return;
        }

        if (!IsPostBack)
        {
            LoadUserDetails();
            LoadCart();
        }
    }

    private void LoadUserDetails()
    {
        string userEmail = Session["UserEmail"].ToString();
        using (SqlConnection con = new SqlConnection(connString))
        {
            string query = "SELECT FullName, email, mobile FROM Users WHERE Email = @Email";
            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                cmd.Parameters.AddWithValue("@Email", userEmail);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    lblName.Text = "Name: " + dr["FullName"].ToString();
                    lblEmail.Text = "Email: " + dr["email"].ToString();
                    lblPhone.Text = "Phone: " + dr["mobile"].ToString();
                  
                }
            }
        }
    }

    private void LoadCart()
    {
        string userEmail = Session["UserEmail"].ToString();
        using (SqlConnection con = new SqlConnection(connString))
        {
            string query = "SELECT ProductName, ProductPrice, Quantity, (ProductPrice * Quantity) AS TotalPrice FROM Cart WHERE UserEmail = @UserEmail";
            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                cmd.Parameters.AddWithValue("@UserEmail", userEmail);
                using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                {
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    gvCart.DataSource = dt;
                    gvCart.DataBind();

                    decimal totalPrice = 0;
                    foreach (DataRow row in dt.Rows)
                    {
                        totalPrice += Convert.ToDecimal(row["TotalPrice"]);
                    }
                    lblTotalPrice.Text = totalPrice.ToString("C");
                }
            }
        }
    }

    protected void btnPayNow_Click(object sender, EventArgs e)
    {
        if (ddlPaymentMethod.SelectedValue == "")
        {
            Response.Write("<script>alert('Please select a payment method.');</script>");
            return;
        }

        string userEmail = Session["UserEmail"].ToString();
        string paymentMethod = ddlPaymentMethod.SelectedValue;
        decimal totalPrice = decimal.Parse(lblTotalPrice.Text, System.Globalization.NumberStyles.Currency);
        string Address = DropDownList1.SelectedValue;

        using (SqlConnection con = new SqlConnection(connString))
        {
            con.Open();
            string insertOrder = "INSERT INTO Payments (UserEmail, TotalAmount, PaymentMethod, PaymentDate , Address ) VALUES (@UserEmail, @TotalAmount, @PaymentMethod, GETDATE() , @Address)";
            using (SqlCommand cmd = new SqlCommand(insertOrder, con))
            {
                cmd.Parameters.AddWithValue("@UserEmail", userEmail);
                cmd.Parameters.AddWithValue("@TotalAmount", totalPrice);
                cmd.Parameters.AddWithValue("@PaymentMethod", paymentMethod);
                cmd.Parameters.AddWithValue("@Address", Address);
                cmd.ExecuteNonQuery();
            }

            string deleteCart = "DELETE FROM Cart WHERE UserEmail = @UserEmail";
            using (SqlCommand cmd = new SqlCommand(deleteCart, con))
            {
                cmd.Parameters.AddWithValue("@UserEmail", userEmail);
                cmd.ExecuteNonQuery();
            }
        }

        Response.Write("<script>alert('Your payment was successfully made.');</script>");
        Response.Redirect("OrderConfirmation.aspx");
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("MyCart.aspx");
    }
}
