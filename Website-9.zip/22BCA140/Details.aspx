﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="Details.aspx.cs" Inherits="Details" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
   <style>
    body {
    font-family: Arial, sans-serif;
    background-color: #f8f9fa;
}

.details-container {
    width: 60%;
    margin: auto;
    background: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    display: flex;
}

.image-section {
    width: 40%;
    text-align: center;
}

.product-image {
    width: 100%;
    height: auto;
    border-radius: 8px;
}

.info-section {
    width: 60%;
    padding-left: 20px;
}

h2 {
    color: #333;
    font-size: 24px;
}

p {
    font-size: 16px;
    margin-bottom: 10px;
}

.btn-add-cart, .btn-back {
    background-color: #007bff;
    color: white;
    padding: 10px 20px;
    font-size: 16px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    margin-top: 20px;
}

.btn-add-cart {
    margin-right: 10px;
}

.btn-back {
    background-color: #6c757d;
}

    </style>
    </head>
    <body>
<form id="form1" runat="server">
        <div class="details-container">
            <div class="image-section">
                <asp:Image ID="imgProduct" runat="server" CssClass="product-image" />
            </div>
            <div class="info-section">
                <h2><asp:Label ID="lblProductName" runat="server"></asp:Label></h2>
                <p><strong>Category:</strong> <asp:Label ID="lblCategory" runat="server"></asp:Label></p>
                <p><strong>Price:</strong> <asp:Label ID="lblPrice" runat="server"></asp:Label></p>
                <p><strong>Description:</strong></p>
                <p><asp:Label ID="lblDescription" runat="server"></asp:Label></p>
                <asp:Button ID="btnAddToCart" runat="server" Text="Add to Cart" CssClass="btn-add-cart" OnClick="btnAddToCart_Click" />
                <asp:Button ID="btnBack" runat="server" Text="Back to Products" CssClass="btn-back" OnClick="btnBack_Click" />
            </div>
        </div>
    </form>
</body>
</html>