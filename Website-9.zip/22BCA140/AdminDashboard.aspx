﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="AdminDashboard.aspx.cs" Inherits="AdminDashboard" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
<title>Admin Dashboard - CES Stationary</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f8f8;
        }
        .header {
            background-color: #0073e6;
            padding: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: white;
        }
        .sidebar {
            width: 250px;
            height: 100vh;
            background-color: #004494;
            position: fixed;
            padding-top: 20px;
            color: white;
        }
        .sidebar a {
            display: block;
            color: white;
            padding: 15px;
            text-decoration: none;
            border-bottom: 1px solid #0073e6;
        }
        .sidebar a:hover {
            background-color: #0073e6;
        }
        .content {
            margin-left: 270px;
            padding: 20px;
        }
        .footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px;
            position: absolute;
            bottom: 0;
            width: 100%;
        }
        
        /* Dashboard Stats Section */
.dashboard-stats {
    display: flex;
    justify-content: space-around;
    margin-top: 20px;
}

/* Each Box */
.stat-box {
    width: 200px;
    padding: 15px;
    text-align: center;
    background: #007bff;
    color: white;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

/* Labels inside Boxes */
.stat-label {
    font-size: 22px;
    font-weight: bold;
    display: block;
    margin-top: 10px;
}

    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="header">
            <h2>Admin Dashboard</h2>
            <asp:Button ID="btnLogout" runat="server" Text="Logout" OnClick="btnLogout_Click" />
        </div>
        
        <div class="sidebar">
        <a href="AdminDashboard.aspx">Home</a>
            <a href="ManageProducts.aspx">Manage Products</a>
            <a href="Orders.aspx">Orders</a>
            <a href="Customers.aspx">Users</a>
        </div>
        
        <div class="content">
    <h3>Welcome, Admin!</h3>
    <p>Use the left menu to manage the stationary shop.</p>

    <div class="dashboard-stats">
        <div class="stat-box">
            <h4>Total Products</h4>
            <asp:Label ID="lblTotalProducts" runat="server" CssClass="stat-label"></asp:Label>
        </div>

        <div class="stat-box">
            <h4>Total Users</h4>
            <asp:Label ID="lblTotalUsers" runat="server" CssClass="stat-label"></asp:Label>
        </div>

        <div class="stat-box">
            <h4>Total Orders</h4>
            <asp:Label ID="lblTotalOrders" runat="server" CssClass="stat-label"></asp:Label>
        </div>
    </div>
</div>


        <div class="footer">
            <p>&copy; 2025 CES Stationary. All rights reserved.</p>
        </div>
    </form>
</body>
</html>
