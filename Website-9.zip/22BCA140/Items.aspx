﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="Items.aspx.cs" Inherits="Items" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Items </title>
<style>
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f8f8;
        }
        .header {
            height: 100px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 30px;
            background-color: black;
            color:White;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }
        .logo {
            height: 70px;
            width: 120px;
            border-radius: 10px;
        }
        .menu {
            display: flex;
            list-style: none;
        }
        .menu a {
            text-decoration: none;
            color: #fff;
            margin: 0 20px;
            font-size: 18px;
            font-weight: 500;
            transition: 0.3s;
        }
        .menu a:hover {
            color:red;
        }
        .search-cart {
            display: flex;
            align-items: center;
        }
        .search-box {
            padding: 8px;
            border: none;
            border-radius: 20px;
            outline: none;
        }
        .search-btn {
            background: #FFD700;
            border: none;
            padding: 8px 12px;
            border-radius: 50%;
            cursor: pointer;
            margin-left: 8px;
            transition: 0.3s;
        }
        .search-btn:hover {
            background: #fff;
        }
        .cart-icon {
            font-size: 22px;
            margin-left: 15px;
            cursor: pointer;
            color: #fff;
            transition: 0.3s;
        }
        .cart-icon:hover {
            color: #FFD700;
        }
        .banner {
            position: relative;
            width: 100%;
            text-align: center;
            overflow: hidden;
        }
        .banner-img {
            width: 100%;
            height: 450px;
            object-fit: cover;
            transition: 1s ease-in-out;
        }
        .banner-text {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: rgba(0, 0, 0, 0.6);
            padding: 20px 40px;
            border-radius: 8px;
            color: #fff;
            font-size: 26px;
            font-weight: bold;
        }
          .product-section 
          {
              margin-top:0;
            text-align: center;
            padding: 50px 0;
            background:maroon;
            animation: fadeIn 1s ease-in-out;
        }
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        .product-title {
            font-size: 28px;
            font-weight: bold;
            color: white;
            margin-bottom: 20px;
        }
        .product-container {
            display: flex;
            justify-content: center;
            gap: 30px;
            flex-wrap: wrap;
        }
        .product-item {
            text-align: center;
            transform: translateY(20px);
            margin-right:30px;
            opacity: 0;
            transition: transform 0.5s ease-out, opacity 0.5s ease-out;
        }
        .product-img {
            width: 200px;
            height: 200px;
            border-radius: 50%;
            object-fit: cover;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
            transition: transform 0.3s ease-in-out;
        }
        .product-img:hover {
          
        }
        .product-name {
            margin-top: 10px;
            font-size: 18px;
            font-weight: bold;
            color:White;
        }
     .container {
            max-width: 1200px;
            margin: auto;
        }
        .product-list {
            display: flex;
            justify-content: center;
            gap: 20px;
            flex-wrap: wrap;
        }
        .product {
            width: 250px;
            border: 1px solid #ddd;
            border-radius: 10px;
            padding: 15px;
            text-align: center;
        }
        .product img {
            width: 100%;
            height: auto;
            border-radius: 10px;
        }
        .add-to-cart {
            background-color: red;
            color: white;
            border: none;
            padding: 10px;
            cursor: pointer;
            width: 100%;
            border-radius: 5px;
        }
        .product a {
            text-decoration: none;
            display: block;
        }
        
      .footer {
            background-color: black;
            color:White;
            color: white;
            padding: 10px 0;
            text-align: center;
            font-size: 14px;
        }
        .footer .top-bar {
            display: flex;
            justify-content: space-around;
            padding: 10px 0;
            border-bottom: 1px solid white;
        }
        .footer .top-bar div {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .footer .container {
            max-width: 1200px;
            margin: auto;
            padding: 30px 10px;
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            color: black;
        }
        .footer-column {
            width: 22%;
            min-width: 200px;
            text-align: left;
        }
        .footer-column h3 {
            color: black;
            font-size: 16px;
            margin-bottom: 10px;
        }
        .footer-column p {
            font-size: 14px;
            color: white;
        }
        .footer-column ul {
            list-style: none;
            padding: 0;
        }
        .footer-column ul li {
            margin: 5px 0;
        }
        .footer-column ul li a {
            text-decoration: none;
            color: white;
            font-size: 14px;
        }
        .social-icons {
            display: flex;
            gap: 10px;
            margin-top: 10px;
        }
        .social-icons a {
            font-size: 20px;
            text-decoration: none;
            color: red;
            transition: color 0.3s;
        }
        .social-icons a:hover {
            color: darkred;
        }
        .newsletter {
            display: flex;
            border: 1px solid #ddd;
            border-radius: 5px;
            overflow: hidden;
        }
        .newsletter input {
            width: 100%;
            padding: 8px;
            border: none;
            outline: none;
        }
        .newsletter button {
            background-color: red;
            color: white;
            border: none;
            padding: 8px;
            cursor: pointer;
        }
        
        .user-icon {
    font-size: 24px;
    color: #333;
    margin-right: 10px;
}

.cart-icon {
    font-size: 24px;
    color: #ff5733;
}

    </style>
</head>
<body>
  <form id="form1" runat="server">
       
       <div class="header">
    <asp:Image ID="imgLogo" runat="server" ImageUrl="logo.webp" CssClass="logo" />
    
    <!-- Main Navigation Menu -->
    <asp:Menu ID="MainMenu" runat="server" CssClass="menu" Orientation="Horizontal">
        <Items>
            <asp:MenuItem Text="Home" NavigateUrl="UserDashboard.aspx" />
            <asp:MenuItem Text="Items" NavigateUrl="Items.aspx" />
            <asp:MenuItem Text="My Cart" NavigateUrl="MyCart.aspx" />
             <asp:MenuItem Text="My Orders" NavigateUrl="MyOrders.aspx" />
             <asp:MenuItem Text="Logout" NavigateUrl="login.aspx" />
           
        </Items>
    </asp:Menu>

    
   
     
 
</div>


<div class="container">
    <h1 style="text-align:center;">Our Items</h1>
    <div class="product-list">
        <asp:Repeater ID="Repeater1" runat="server" 
            >
            <ItemTemplate>
                <div class="product">
                    <asp:HyperLink ID="HyperLink2" runat="server" NavigateUrl='<%# "details.aspx?ID=" + Eval("Product_ID") %>'>
                        <asp:Image ID="Image1" runat="server" ImageUrl='<%# Eval("Image") %>' Alt='<%# Eval("Product_Name") %>' />
                    </asp:HyperLink>
                    <h3><%# Eval("Product_Name") %></h3>
                    <h3><%# Eval("Description") %></h3>
                    <p>Rs. <%# Eval("Price") %></p>
                  <asp:Button ID="btnAddToCart" runat="server" CssClass="add-to-cart" 
    Text="Add to Cart" CommandArgument='<%# Eval("Product_ID") %>' 
    OnClick="btnAddToCart_Click" />

                </div>
            </ItemTemplate>
        </asp:Repeater>
    </div>
</div>





<div class="footer">
    <div class="top-bar">
        <asp:Label ID="Label1" runat="server" Text="📦 Free Delivery for College Departments"></asp:Label>
        <asp:Label ID="Label2" runat="server" Text="🖊️ Quality Stationery & Office Supplies"></asp:Label>
        <asp:Label ID="Label3" runat="server" Text="⚡ Fast & Reliable Order Processing"></asp:Label>
        <asp:Label ID="Label4" runat="server" Text="🏫 Serving All M.B. Patel Science College Departments"></asp:Label>
    </div>

    <div class="container">
        <div class="footer-column">
            <asp:Image ID="imgFooterLogo" runat="server" ImageUrl="logo.webp" Width="150px" />
            <p>Your One-Stop Shop for College Stationery & Office Supplies.</p>
        </div>

        <div class="footer-column">
            <h3>INFORMATION</h3>
            <asp:BulletedList ID="blInformation" runat="server">
                <asp:ListItem Text="About Us" Value="#" />
                <asp:ListItem Text="Contact / Inquiry" Value="#" />
                <asp:ListItem Text="Order & Delivery Policy" Value="#" />
                <asp:ListItem Text="Quality & Customer Satisfaction" Value="#" />
            </asp:BulletedList>
        </div>

        <div class="footer-column">
            <h3>CUSTOMER SUPPORT</h3>
            <asp:BulletedList ID="blSupport" runat="server">
                <asp:ListItem Text="Order Tracking" Value="#" />
                <asp:ListItem Text="Privacy Policy" Value="#" />
                <asp:ListItem Text="Terms & Conditions" Value="#" />
            </asp:BulletedList>
        </div>

        <div class="footer-column">
            <h3>CONTACT US</h3>
            <p>Get Updates on New Arrivals & Discounts</p>
            <asp:TextBox ID="txtEmail" runat="server" Placeholder="Enter Your Email"></asp:TextBox>
            <asp:Button ID="btnSubscribe" runat="server" Text="➜" />

            <p>📍 <strong>Location:</strong> M.B. Patel Science College, Gujarat, India</p>
            <p>📧 <asp:HyperLink ID="HyperLink3" runat="server" NavigateUrl="mailto:support@cesstationary.com">support@cesstationary.com</asp:HyperLink></p>
            <p>📞 <asp:HyperLink ID="HyperLink4" runat="server" NavigateUrl="tel:+919876543210">+91-9876543210</asp:HyperLink></p>
        </div>
    </div>
</div>


    
       
         <script>
        document.addEventListener("DOMContentLoaded", function() {
            let items = document.querySelectorAll(".product-item");
            items.forEach((item, index) => {
                setTimeout(() => {
                    item.style.opacity = "1";
                    item.style.transform = "translateY(0)";
                }, index * 300);
            });
        });
    </script>
    </form>
</body>
</html>
