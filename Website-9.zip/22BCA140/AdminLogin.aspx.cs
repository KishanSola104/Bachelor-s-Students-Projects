﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Web;

public partial class AdminLogin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lblError.Visible = false;
    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        string connString = ConfigurationManager.ConnectionStrings["CESStationaryDB"].ConnectionString;
        
        using (SqlConnection conn = new SqlConnection(connString))
        {
            try
            {
                conn.Open();
                string query = "SELECT * FROM Admins WHERE Email = @Email AND Password = @Password";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Email", txtEmail.Text.Trim());
                    cmd.Parameters.AddWithValue("@Password", txtPassword.Text.Trim());

                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        Session["AdminEmail"] = txtEmail.Text.Trim();
                        Response.Redirect("AdminDashboard.aspx");
                    }
                    else
                    {
                        lblError.Text = "Invalid Email or Password!";
                        lblError.Visible = true;
                    }
                }
            }
            catch (Exception ex)
            {
                lblError.Text = "An error occurred: " + ex.Message;
                lblError.Visible = true;
            }
        }
    }
}