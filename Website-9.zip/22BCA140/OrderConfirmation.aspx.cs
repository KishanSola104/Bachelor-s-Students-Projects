﻿using System;
using System.Data.SqlClient;
using System.Web.UI;
using System.Configuration;

public partial class OrderConfirmation : Page
{
    string connString = ConfigurationManager.ConnectionStrings["CESStationaryDB"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserEmail"] == null)
        {
            Response.Redirect("login.aspx");
            return;
        }

        LoadOrderDetails();
    }

    private void LoadOrderDetails()
    {
        string userEmail = Session["UserEmail"].ToString();

        using (SqlConnection con = new SqlConnection(connString))
        {
            string query = "SELECT TOP 1 UserEmail, TotalAmount, PaymentDate, PaymentMethod , Address FROM Payments WHERE UserEmail = @UserEmail ORDER BY PaymentDate DESC";
            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                cmd.Parameters.AddWithValue("@UserEmail", userEmail);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    lblUserEmail.Text = dr["UserEmail"].ToString();
                    lblTotalAmount.Text = Convert.ToDecimal(dr["TotalAmount"]).ToString("C");
                    lblPaymentMethod.Text = dr["PaymentMethod"].ToString();
                    lblPaymentDate.Text = Convert.ToDateTime(dr["PaymentDate"]).ToString("dd MMM yyyy hh:mm tt");
                    lbladd.Text = dr["Address"].ToString();
                }
            }
        }
    }

    protected void btnBackToHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("UserDashboard.aspx");
    }
}
