﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="ManageProducts.aspx.cs" Inherits="ManageProducts" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>Manage Products - CES Stationary</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f8f8f8;
        }

        /* Header */
        .header {
            background-color: #0073e6;
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 20px;
        }

        /* Sidebar */
        .sidebar {
            width: 250px;
            height: 90vh;
            background-color: #004494;
            position: fixed;
            top: 0;
            left: 0;
            margin-top: 80px;
            color: white;
        }

        .sidebar a {
            display: block;
            color: white;
            padding: 15px;
            text-decoration: none;
            border-bottom: 1px solid #0073e6;
            font-size: 16px;
            transition: background 0.3s;
        }

        .sidebar a:hover {
            background-color: #0073e6;
        }

        /* Main Content */
        .content {
            margin-left: 260px;
            padding: 20px;
            min-height: 100vh;
        }

        .main-content {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            margin: auto;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        /* Form Styling */
        label {
            display: block;
            font-weight: bold;
            margin-top: 10px;
        }

        input[type="text"],
        input[type="number"],
        textarea,
        select {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
        }

        textarea {
            resize: vertical;
        }

        /* Image Upload */
        #imgProduct {
            display: block;
            margin-top: 10px;
            border: 1px solid #ddd;
            padding: 5px;
        }

        /* Buttons */
        .form-buttons {
            margin-top: 15px;
            text-align: center;
        }

        .btn {
            background-color: #0073e6;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin: 5px;
            transition: background 0.3s;
        }

        .btn:hover {
            background-color: #005bb5;
        }

        .btn-delete {
            background-color: #e60000;
        }

        .btn-delete:hover {
            background-color: #b50000;
        }

        .btn-clear {
            background-color: #777;
        }

        .btn-clear:hover {
            background-color: #555;
        }

        /* Footer */
        .footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px;
            position: relative;
            width: 100%;
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <!-- Header -->
        <div class="header">
            <h2>Admin Dashboard</h2>
            <asp:Button ID="btnLogout" runat="server" Text="Logout" CssClass="btn" OnClick="btnLogout_Click" />
        </div>
        
        <!-- Sidebar -->
        <div class="sidebar">
            <a href="AdminDashboard.aspx">Home</a>
            <a href="ManageProducts.aspx">Manage Products</a>
            <a href="Orders.aspx">Orders</a>
            <a href="Customers.aspx">Users</a>
        </div>
        
        <!-- Main Content -->
        <div class="content">
            <div class="main-content">
                <h2>Manage Products</h2>

                <!-- Select Product -->
                <label for="ddlProducts">Select Product:</label>
                <asp:DropDownList ID="ddlProducts" runat="server" AutoPostBack="true" OnSelectedIndexChanged="ddlProducts_SelectedIndexChanged">
                </asp:DropDownList>

                <!-- Product ID -->
                <label for="txtProductID">Product ID:</label>
                <asp:TextBox ID="txtProductID" runat="server" required></asp:TextBox>

                <!-- Product Name -->
                <label for="txtProductName">Product Name:</label>
                <asp:TextBox ID="txtProductName" runat="server" required></asp:TextBox>

                <!-- Price -->
                <label for="txtPrice">Price:</label>
                <asp:TextBox ID="txtPrice" runat="server" TextMode="Number" required></asp:TextBox>

                <!-- Stock -->
                <label for="txtStock">Stock:</label>
                <asp:TextBox ID="txtStock" runat="server" TextMode="Number" required></asp:TextBox>

                <!-- Image Upload -->
                <label for="fileUploadImage">Product Image:</label>
                <asp:FileUpload ID="fileUploadImage" runat="server" />
                <asp:Image ID="imgProduct" runat="server" Width="150px" Height="150px" />

                <!-- Description -->
                <label for="txtDescription">Description:</label>
                <asp:TextBox ID="txtDescription" runat="server" TextMode="MultiLine" Rows="4" required></asp:TextBox>

                <!-- Buttons -->
                <div class="form-buttons">
                    <asp:Button ID="btnAdd" runat="server" Text="Add Product" CssClass="btn" OnClick="btnAdd_Click" />
                    <asp:Button ID="btnUpdate" runat="server" Text="Update Product" CssClass="btn" OnClick="btnUpdate_Click" />
                    <asp:Button ID="btnDelete" runat="server" Text="Delete Product" CssClass="btn btn-delete" OnClick="btnDelete_Click" />
                    <asp:Button ID="btnClear" runat="server" Text="Clear Fields" CssClass="btn btn-clear" OnClick="btnClear_Click" />
                </div>
            </div>
        </div>

        <!-- Footer -->
        <div class="footer">
            <p>&copy; 2025 CES Stationary. All rights reserved.</p>
        </div>
    </form>
</body>
</html>
