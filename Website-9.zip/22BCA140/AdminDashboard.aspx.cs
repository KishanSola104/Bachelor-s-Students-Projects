﻿using System;
using System.Data.SqlClient;
using System.Configuration;

public partial class AdminDashboard : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadCounts();
        }
    }

    private void LoadCounts()
    {
        string connStr = ConfigurationManager.ConnectionStrings["CESStationaryDB"].ConnectionString;
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            conn.Open();

            // Get Total Products Count
            using (SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM Products", conn))
            {
                lblTotalProducts.Text = cmd.ExecuteScalar().ToString();
            }

            // Get Total Users Count
            using (SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM Users", conn))
            {
                lblTotalUsers.Text = cmd.ExecuteScalar().ToString();
            }

            // Get Total Orders Count
            using (SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM Payments", conn))
            {
                lblTotalOrders.Text = cmd.ExecuteScalar().ToString();
            }
        }
    }
    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminLogin.aspx");
    }
}
