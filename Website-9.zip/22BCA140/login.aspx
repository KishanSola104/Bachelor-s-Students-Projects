﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="login.aspx.cs" Inherits="login" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
     <title>Login</title>
     <style>
 /* Reset default styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Arial', sans-serif;
}

/* Full-page styling */
body {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    background: #f4f4f4; /* Light background for a soft, clean look */
}

/* Centered Login Box */
.container {
    width: 350px;
    background: #fff;
    padding: 30px;
    border-radius: 8px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    text-align: center;
}

/* Page Title */
h2 {
    margin-bottom: 20px;
    font-size: 22px;
    color: #333;
}

/* Form fields */
.form-group {
    text-align: left;
    margin-bottom: 15px;
}

label {
    font-size: 14px;
    font-weight: 600;
    color: #444;
}

/* Input styling */
input[type="text"],
input[type="email"],
input[type="password"] {
    width: 100%;
    padding: 10px;
    margin-top: 5px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 14px;
    transition: border-color 0.3s ease;
}

/* Focus effect */
input:focus {
    border-color: #007bff;
    outline: none;
}

/* Login Button */
.btn {
    width: 100%;
    padding: 10px;
    background: #007bff;
    border: none;
    color: white;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
    border-radius: 5px;
    margin-top: 15px;
    transition: 0.3s ease-in-out;
}

/* Button hover effect */
.btn:hover {
    background: #0056b3;
}

/* Error Message */
#lblMessage {
    margin-top: 10px;
    font-size: 14px;
    color: red;
    font-weight: bold;
}

/* Sign-up Link */
.link {
    display: block;
    margin-top: 15px;
    font-size: 14px;
    color: #007bff;
    text-decoration: none;
    font-weight: bold;
}

/* Link hover effect */
.link:hover {
    text-decoration: underline;
}

     </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="container">
    <h2>Login</h2>
    
    <div class="form-group">
        <asp:Label ID="lblEmail" runat="server" Text="Email:"></asp:Label>
        <asp:TextBox ID="txtEmail" runat="server"></asp:TextBox>
    </div>

    <div class="form-group">
        <asp:Label ID="lblPassword" runat="server" Text="Password:"></asp:Label>
        <asp:TextBox ID="txtPassword" runat="server" TextMode="Password"></asp:TextBox>
    </div>

    <asp:Button ID="btnLogin" CssClass="btn" runat="server" Text="Login" OnClick="btnLogin_Click" />

    <asp:Label ID="lblMessage" runat="server" ForeColor="Red"></asp:Label>

    <asp:HyperLink ID="lnkSignUp" CssClass="link" runat="server" NavigateUrl="SignUp.aspx">Don't have an account? Sign up here.</asp:HyperLink>
</div>

    </form>
</body>
</html>