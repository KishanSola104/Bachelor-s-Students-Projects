﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="index.aspx.cs" Inherits="index" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>CES Stationary</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f8f8;
        }
        .header {
            background-color: #0073e6;
            padding: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .site-title {
            font-size: 24px;
            font-weight: bold;
            text-align: center;
            flex: 1;
            color: white;
        }
        /* Dropdown Button */
        .dropdown {
            position: relative;
            display: inline-block;
            margin-right: 60px;
        }
        .dropbtn {
            background-color: #005bb5;
            color: white;
            padding: 10px 15px;
            font-size: 16px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }
        .dropbtn:hover {
            background-color: #004494;
        }
        /* Dropdown Content */
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: white;
            min-width: 60px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.2);
            border-radius: 5px;
            z-index: 1;
        }
        .dropdown-content a {
            color: black;
            padding: 10px 15px;
            display: block;
            text-decoration: none;
            border-radius: 5px;
        }
        .dropdown-content a:hover {
            background-color: #0073e6;
            color: white;
        }
        .dropdown:hover .dropdown-content {
            display: block;
        }
        /* Center Image */
        .container {
            text-align: center;
            margin: 30px auto;
        }
        .container img {
            width: 60%;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            height: 75vh;
        }
        /* Footer */
        .footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px;
            position: relative;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <!-- Header -->
        <div class="header">
            <div class="site-title">CES Stationary</div>
            <!-- Hover Dropdown -->
            <div class="dropdown">
                <button class="dropbtn">Login</button>
                <div class="dropdown-content">
                    <a href="AdminLogin.aspx">Admin</a>
                    <a href="login.aspx">Customers</a>
              
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="container">
            <img src="logo.webp" alt="CES Stationary" />
        </div>

        <!-- Footer -->
        <div class="footer">
            <p>Contact Us: 9876543210 | Email: support@cesstationary.com | Address: M.B. Patel Science College Campus</p>
        </div>
    </form>
</body>
</html>
