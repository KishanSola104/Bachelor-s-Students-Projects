﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

public partial class ManageProducts : Page
{
    string connStr = ConfigurationManager.ConnectionStrings["CESStationaryDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadProductsDropdown();
        }
    }

    private void LoadProductsDropdown()
    {
        try
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string query = "SELECT Product_ID, Product_Name FROM Products";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    conn.Open();
                    ddlProducts.DataSource = cmd.ExecuteReader();
                    ddlProducts.DataTextField = "Product_Name";
                    ddlProducts.DataValueField = "Product_ID";
                    ddlProducts.DataBind();
                }
            }
            ddlProducts.Items.Insert(0, new ListItem("-- Select a Product --", ""));
        }
        catch (Exception ex)
        {
            ShowAlert("Error loading products: " + ex.Message);
        }
    }

    protected void ddlProducts_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (!string.IsNullOrEmpty(ddlProducts.SelectedValue))
        {
            FetchProductDetails(ddlProducts.SelectedValue);
        }
    }

    private void FetchProductDetails(string productID)
    {
        try
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string query = "SELECT * FROM Products WHERE Product_ID = @ProductID";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@ProductID", productID);
                    conn.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            txtProductID.Text = reader["Product_ID"].ToString();
                            txtProductName.Text = reader["Product_Name"].ToString();
                            txtPrice.Text = reader["Price"].ToString();
                            txtStock.Text = reader["Stock"].ToString();
                            txtDescription.Text = reader["Description"].ToString();
                            imgProduct.ImageUrl = reader["Image"] != DBNull.Value ? reader["Image"].ToString() : "Images/default.png";
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            ShowAlert("Error fetching product details: " + ex.Message);
        }
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            string imagePath = UploadProductImage();
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string query = "INSERT INTO Products (Product_ID, Product_Name, Price, Stock, Description, Image) " +
                               "VALUES (@id, @Name, @Price, @Stock, @Desc, @Image)";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@id", txtProductID.Text);
                    cmd.Parameters.AddWithValue("@Name", txtProductName.Text);
                    cmd.Parameters.AddWithValue("@Price", txtPrice.Text);
                    cmd.Parameters.AddWithValue("@Stock", txtStock.Text);
                    cmd.Parameters.AddWithValue("@Desc", txtDescription.Text);
                    cmd.Parameters.AddWithValue("@Image", imagePath);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
            LoadProductsDropdown();
            ShowAlert("Product Added Successfully!");
        }
        catch (Exception ex)
        {
            ShowAlert("Error adding product: " + ex.Message);
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string query = "UPDATE Products SET Product_Name=@Name, Price=@Price, Stock=@Stock, Description=@Desc WHERE Product_ID=@id";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@id", txtProductID.Text);
                    cmd.Parameters.AddWithValue("@Name", txtProductName.Text);
                    cmd.Parameters.AddWithValue("@Price", txtPrice.Text);
                    cmd.Parameters.AddWithValue("@Stock", txtStock.Text);
                    cmd.Parameters.AddWithValue("@Desc", txtDescription.Text);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
            LoadProductsDropdown();
            ShowAlert("Product Updated Successfully!");
        }
        catch (Exception ex)
        {
            ShowAlert("Error updating product: " + ex.Message);
        }
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string query = "DELETE FROM Products WHERE Product_ID=@id";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@id", txtProductID.Text);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
            LoadProductsDropdown();
            ShowAlert("Product Deleted Successfully!");
        }
        catch (Exception ex)
        {
            ShowAlert("Error deleting product: " + ex.Message);
        }
    }

    private string UploadProductImage()
    {
        string imagePath = "Images/default.png";
        try
        {
            if (fileUploadImage.HasFile)
            {
                string folderPath = Server.MapPath("~/Images/");
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }
                string fileName = Path.GetFileName(fileUploadImage.FileName);
                string filePath = folderPath + fileName;
                fileUploadImage.SaveAs(filePath);
                imagePath = "Images/" + fileName;
            }
        }
        catch (Exception ex)
        {
            ShowAlert("Error uploading image: " + ex.Message);
        }
        return imagePath;
    }

    private void ShowAlert(string message)
    {
        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('" + message + "');", true);
    }

    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Redirect("AdminLogin.aspx");
    }

    protected void btnClear_Click(object sender, EventArgs e)
    {
        txtProductID.Text = "";
        txtProductName.Text = "";
        txtPrice.Text = "";
        txtStock.Text = "";
        txtDescription.Text = "";
        imgProduct.ImageUrl = "Images/default.png";
    }

}
