﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="ManageProducts.aspx.cs" Inherits="ManageProducts" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
<title>Manage Products  - Auto Mobiles Decor </title>
    <!-- Font Awesome Link -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet" />
 <style>
        /* General Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        /* Admin Header Styling */
        .admin-header {
            background-color: orange;
            color: white;
            font-size: large;
            font-weight: bold;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 100; /* Keeps the header above the sidebar */
            position: fixed;
            width: 100%;
            top: 0;
        }

        .admin-info {
            display: flex;
            align-items: center;
        }

        .admin-profile-img {
            border-radius: 50%;
            border: 2px solid #fff;
            object-fit: cover;
            margin-left: 10px;
        }

        .logout-btn {
            margin-left: 15px;
            background-color: #f44336;
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
        }

        .logout-btn:hover {
            background-color: #d32f2f;
        }

        /* Main Content */
        .main-content {
            margin-left: 200px; /* Adjusted for sidebar width */
            padding: 20px;
            transition: margin-left 0.3s;
            margin-top: 60px; /* To account for header height */
        }

        /* Footer Styling */
        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px;
            position: fixed;
            width: 100%;
            bottom: 0;
        }

        /* Sidebar Styling */
        .sidebar {
            width: 180px; /* Reduced width */
            background: #222;
            color: white;
            padding: 15px;
            position: fixed;
            height: 100%;
            transition: 0.3s ease-in-out;
        }

        .sidebar a {
            display: flex;
            align-items: center;
            color: white;
            padding: 12px;
            font-size: 14px;
            text-decoration: none;
            transition: background 0.3s ease-in-out;
        }

        .sidebar a i {
            margin-right: 10px;
            font-size: 16px;
        }

        .sidebar a:hover {
            background: #333;
            border-radius: 5px;
        }

        /* Settings Dropdown */
        .settings {
            margin-top: 10px;
        }

        .settings a {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .dropdown {
            display: none;
            background: #333;
            padding: 5px;
            border-radius: 5px;
            flex-direction: column;
        }

        .dropdown a {
            padding: 8px 15px;
            font-size: 13px;
            display: flex;
            align-items: center;
            gap: 10px;
            transition: 0.3s;
        }

        .dropdown a:hover {
            background: #444;
        }

        .settings .fa-chevron-down {
            transition: transform 0.3s ease;
        }

        .settings.open .fa-chevron-down {
            transform: rotate(180deg);
        }
    </style>

    <style>
   /* Form Styling */
.main-content {
    padding-bottom: 80px; /* Prevents footer overlap */
}

.main-content form {
    background: #fff;
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.15);
    max-width: 600px;
    margin: auto;
    margin-bottom: 20px; /* Extra spacing before footer */
}

/* Labels */
label {
    display: block;
    margin-top: 12px;
    font-weight: bold;
    font-size: 14px;
    color: #333;
}

/* Input Fields */
input, select, textarea {
    width: 100%;
    padding: 10px;
    margin-top: 5px;
    border: 1px solid #ccc;
    border-radius: 6px;
    font-size: 14px;
}

/* Textarea Styling */
textarea {
    height: 100px;
    resize: vertical;
}

/* Buttons */
.form-buttons {
    margin-top: 20px;
    display: flex;
    gap: 10px;
    justify-content: flex-end;
}

.btn {
    padding: 10px 15px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-weight: bold;
    transition: background 0.3s ease-in-out;
    font-size: 14px;
}

.btn:hover {
    opacity: 0.85;
}

.btn-submit {
    background: #28a745;
    color: white;
}

.btn-delete {
    background: #dc3545;
    color: white;
}

.btn-clear {
    background: #6c757d;
    color: white;
}

/* Responsive Fix */
@media (max-width: 768px) {
    .main-content form {
        max-width: 90%;
        padding: 15px;
    }

    .form-buttons {
        flex-direction: column;
        align-items: center;
    }

    .btn {
        width: 100%;
        margin-bottom: 10px;
    }
}


    </style>
</head>
<body>

    <form id="adminDashboardForm" runat="server">
        <!-- Header Section -->
        <header class="admin-header">
            <div class="logo">Auto Mobile Decor</div>
            <div class="admin-info">
                <span>Welcome, <asp:Label ID="lblAdminName" runat="server" Text="Admin"></asp:Label></span>
                <asp:Image ID="imgAdminProfile" runat="server" CssClass="admin-profile-img" Width="40px" Height="40px" />
                <asp:Button ID="btnLogout" runat="server" Text="Logout" CssClass="logout-btn"/>
            </div>
        </header>

        <!-- Sidebar Section -->
        <div class="sidebar">
            <a href="AdminDashboard.aspx"><i class="fas fa-home"></i>Dashboard</a>
           <a href="ManageProducts.aspx"><i class="fas fa-box"></i> Products</a>

            <a href="orders.aspx"><i class="fas fa-shopping-cart"></i> Orders</a>
            <a href="customers.aspx"><i class="fas fa-users"></i> Customers</a>

            <div class="settings">
                <a href="#" id="settings-btn"><i class="fas fa-cogs"></i> Settings <i class="fas fa-chevron-down"></i></a>
                <div class="dropdown" id="settings-dropdown">
                    <a href="AdminAccount.aspx"><i class="fas fa-user"></i> My Account</a>
                    <a href="AdminResetPassword.aspx"><i class="fas fa-key"></i> Reset Password</a>
                
                    <a href="AdminLogin.aspx"><i class="fas fa-sign-out-alt"></i> Log Out</a>
                </div>
            </div>
        </div>

       <div class="main-content">
    <h2>Manage Products</h2>
    
    <form id="manageProductsForm" >
        
        <!-- Select Product -->
        <label for="ddlProducts">Select Product:</label>
        <asp:DropDownList ID="ddlProducts" runat="server" AutoPostBack="true" OnSelectedIndexChanged="ddlProducts_SelectedIndexChanged">
        </asp:DropDownList>

        <!-- Product ID -->
        <label for="txtProductID">Product ID:</label>
        <asp:TextBox ID="txtProductID" runat="server"  required></asp:TextBox>

        <!-- Product Name -->
        <label for="txtProductName">Product Name:</label>
        <asp:TextBox ID="txtProductName" runat="server" required></asp:TextBox>

        <!-- Price -->
        <label for="txtPrice">Price</label>
        <asp:TextBox ID="txtPrice" runat="server" TextMode="Number" required></asp:TextBox>

        <!-- Stock -->
        <label for="txtStock">Stock:</label>
        <asp:TextBox ID="txtStock" runat="server" TextMode="Number" required></asp:TextBox>

        <!-- Image Upload -->
        <label for="fuImage">Product Image:</label>
        <asp:FileUpload ID="fileUploadImage" runat="server" />
        <asp:Image ID="imgProduct" runat="server" Width="150px" Height="150px" />


        
     

        <!-- Description -->
        <label for="txtDescription">Description:</label>
        <asp:TextBox ID="txtDescription" runat="server" TextMode="MultiLine" Rows="4" required></asp:TextBox>

        <!-- Category Selection -->
        <label for="ddlCategory">Category:</label>
        <asp:DropDownList ID="ddlCategory" runat="server">
            <asp:ListItem Text="Two Wheeler" Value="Two Wheeler"></asp:ListItem>
            <asp:ListItem Text="Three Wheeler" Value="Three Wheeler"></asp:ListItem>
            <asp:ListItem Text="Four Wheeler" Value="Four Wheeler"></asp:ListItem>
          
        </asp:DropDownList>

        <!-- Buttons -->
        <div class="form-buttons">
            <asp:Button ID="btnAdd"  runat="server" Text="Add Product" CssClass="btn" OnClick="btnAdd_Click" />
            <asp:Button ID="btnUpdate"  runat="server" Text="Update Product" CssClass="btn" OnClick="btnUpdate_Click" />
            <asp:Button ID="btnDelete"  runat="server" Text="Delete Product" CssClass="btn btn-delete" OnClick="btnDelete_Click" />
            <asp:Button ID="btnClear"  runat="server" Text="Clear Fields" CssClass="btn btn-clear" OnClick="btnClear_Click" />
        </div>

    </form>
</div>


        <!-- Footer Section -->
        <footer>
            <p>© 2025 Auto Mobiles Decor. All Rights Reserved.</p>
        </footer>

    </form>

    <!-- JavaScript for Settings Dropdown -->
    <script>
        document.getElementById('settings-btn').addEventListener('click', function (event) {
            event.preventDefault();
            var dropdown = document.getElementById('settings-dropdown');
            var settings = document.querySelector('.settings');

            dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
            settings.classList.toggle('open');
        });
    </script>
</body>
</html>
