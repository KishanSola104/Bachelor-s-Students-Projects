﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.UI;

public partial class UserAccount : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserEmail"] == null)
        {
            Response.Redirect("Login.aspx"); // Redirect user to login if session is null
        }
        else if (!IsPostBack)
        {
            LoadUserProfile();
        }
    }

    private void LoadUserProfile()
    {
        string userEmail = Session["UserEmail"].ToString();
        string connStr = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\gkpat\OneDrive\Desktop\22BCA098\App_Data\Database.mdf;Integrated Security=True;User Instance=True";

        using (SqlConnection conn = new SqlConnection(connStr))
        {
            conn.Open();
            string query = "SELECT name, email FROM Users WHERE Email = @Email";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@Email", userEmail);

            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                lblAdminName1.Text = reader["name"].ToString();
                lblAdminEmail.Text = reader["email"].ToString();
               // lblAdminJoinedDate.Text = Convert.ToDateTime(reader["JoinDate"]).ToString("dd MMM yyyy");
                DateTime yesterday = DateTime.Now.AddDays(-1);
                lblAdminLastLogin.Text = yesterday.ToString("dd MMM yyyy");

               // string profileImage = reader["ProfileImage"].ToString();
                imgAdminProfile1.ImageUrl = "User.jpg";
            }
        }
    }
}
