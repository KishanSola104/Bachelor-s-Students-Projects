﻿using System;
using System.Data.SqlClient;
using System.Web.UI;

public partial class OrderConfirmation : Page
{
    string connectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\gkpat\OneDrive\Desktop\22BCA098\App_Data\Database.mdf;Integrated Security=True;User Instance=True";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserEmail"] == null)
        {
            Response.Redirect("login.aspx");
            return;
        }

        LoadOrderDetails();
    }

    private void LoadOrderDetails()
    {
        string userEmail = Session["UserEmail"].ToString();

        using (SqlConnection con = new SqlConnection(connectionString))
        {
            string query = "SELECT TOP 1 UserEmail, TotalAmount, PaymentDate, PaymentMethod FROM Payments WHERE UserEmail = @UserEmail ORDER BY PaymentDate DESC";
            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                cmd.Parameters.AddWithValue("@UserEmail", userEmail);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    lblUserEmail.Text = dr["UserEmail"].ToString();
                    lblTotalAmount.Text = Convert.ToDecimal(dr["TotalAmount"]).ToString("C");
                    lblPaymentMethod.Text = dr["PaymentMethod"].ToString();
                    lblPaymentDate.Text = Convert.ToDateTime(dr["PaymentDate"]).ToString("dd MMM yyyy hh:mm tt");
                }
            }
        }
    }

    protected void btnBackToHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("UserDashboard.aspx");
    }
}
