﻿using System;
using System.Configuration;
using System.Data.SqlClient;

public partial class SignUp : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }


    protected void btnSignUp_Click1(object sender, EventArgs e)
    {
        // Database connection string from Web.config
        string connStr = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\gkpat\OneDrive\Desktop\22BCA098\App_Data\Database.mdf;Integrated Security=True;User Instance=True";

        using (SqlConnection conn = new SqlConnection(connStr))
        {
            try
            {
                conn.Open();
                string query = "INSERT INTO Users (email, name, dob, password, city, address, mobile, pincode) " +
                               "VALUES (@Email, @Name, @DOB, @Password, @City, @Address, @Mobile, @Pincode)";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    // Adding parameters to prevent SQL Injection
                    cmd.Parameters.AddWithValue("@Email", txtEmail.Text.Trim());
                    cmd.Parameters.AddWithValue("@Name", txtName.Text.Trim());
                    cmd.Parameters.AddWithValue("@DOB", txtDOB.Text);
                    cmd.Parameters.AddWithValue("@Password", txtPassword.Text.Trim());
                    cmd.Parameters.AddWithValue("@City", ddlCity.SelectedValue);
                    cmd.Parameters.AddWithValue("@Address", txtAddress.Text.Trim());
                    cmd.Parameters.AddWithValue("@Mobile", txtMobile.Text.Trim());
                    cmd.Parameters.AddWithValue("@Pincode", txtPincode.Text.Trim());

                    int rowsAffected = cmd.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        // Store the email in a session variable
                        Session["UserEmail"] = txtEmail.Text.Trim();

                        // Alert message and redirect to UserSecurity.aspx
                        Response.Write("<script>alert('Account Created Successfully! \\n Redirecting to the Security Page...'); window.location='UserSecurity.aspx';</script>");
                    }
                    else
                    {
                        Response.Write("<script>alert('Sign-up failed. Please try again.');</script>");
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('Error: " + ex.Message + "');</script>");
            }
        }
    }
}
