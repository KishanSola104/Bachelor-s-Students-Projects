﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="UserAccount.aspx.cs" Inherits="UserAccount" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
   <title>Auto Mobile Decor</title>
 <!-- Font Awesome Link -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet" />


    <style>
        /* General Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        /* Admin Header Styling */
        .admin-header {
            background-color: orange;
            color: white;
            font-size: large;
            font-weight: bold;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 100; /* Keeps the header above the sidebar */
            position: fixed;
            width: 100%;
            top: 0;
        }

        .admin-info {
            display: flex;
            align-items: center;
        }

        .admin-profile-img {
            border-radius: 50%;
            border: 2px solid #fff;
            object-fit: cover;
            margin-left: 10px;
        }

        .logout-btn {
            margin-left: 15px;
            background-color: #f44336;
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
        }

        .logout-btn:hover {
            background-color: #d32f2f;
        }

        /* Main Content */
        .main-content {
            margin-left: 200px; /* Adjusted for sidebar width */
            padding: 20px;
            transition: margin-left 0.3s;
            margin-top: 60px; /* To account for header height */
        }

        /* Footer Styling */
        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px;
            position: fixed;
            width: 100%;
            bottom: 0;
        }

     
        
   /* Quick Actions Styling */
.quick-actions {
    display: flex;
    justify-content: center;
    gap: 15px;
    margin-bottom: 15px;
}

.action-btn {
    background: #ff9800;
    color: white;
    text-decoration: none;
    padding: 10px 15px;
    border-radius: 5px;
    transition: background 0.3s;
}

.action-btn:hover {
    background: #e68900;
}

.action-btn.logout {
    background: #f44336;
}

.action-btn.logout:hover {
    background: #d32f2f;
}

/* Divider */
.divider {
    border: none;
    height: 2px;
    background: gray;
    margin: 20px 0;
}

/* Improved Profile Section */
.profile-container {
    text-align: center;
    margin: auto;
    max-width: 450px;
    padding: 20px;
}

.profile-card {
    background: linear-gradient(135deg, #ff9800, #ff5722);
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
    text-align: center;
    color: white;
}

.profile-image {
    border-radius: 50%;
    border: 4px solid #fff;
    object-fit: cover;
}

.profile-card h3 {
    margin-top: 10px;
    font-size: 22px;
}

.profile-card p {
    font-size: 16px;
    margin: 5px 0;
}

.profile-details {
    margin-top: 15px;
    padding: 10px;
    background: rgba(255, 255, 255, 0.2);
    border-radius: 8px;
}


    </style>
</head>
<body>

    <form id="adminDashboardForm" runat="server">
       
      
<!-- Main Content Section -->
<div class="main-content">
    <!-- Quick Actions Section -->
    <div class="quick-actions">
        <a href="UserAccount.aspx" class="action-btn">My Account</a>
        <a href="UserResetPassword.aspx" class="action-btn">Reset Password</a>
        <a href="login.aspx" class="action-btn logout">Log Out</a>
    </div>

    <hr class="divider"> <!-- Separator Line -->

    <!-- Admin Profile Section -->
    <div class="profile-container">
        <h2>Admin Profile</h2>
        <div class="profile-card">
            <asp:Image ID="imgAdminProfile1" runat="server" CssClass="profile-image" Width="120px" Height="120px" />
            <h3><asp:Label ID="lblAdminName1" runat="server" Text="Admin"></asp:Label></h3>
            <p>Email: <asp:Label ID="lblAdminEmail" runat="server" Text="admin@example.com"></asp:Label></p>
            <div class="profile-details">
                <p><strong>Role:</strong>Customer</p>
                <p><strong>Joined:</strong> <asp:Label ID="lblAdminJoinedDate" runat="server" Text="01 Jan 2022"></asp:Label></p>
                <p><strong>Last Login:</strong> <asp:Label ID="lblAdminLastLogin" runat="server"></asp:Label></p>
            </div>
        </div>
    </div>
</div>


        <!-- Footer Section -->
        <footer>
            <p>© 2025 AutoMobiles Decor. All Rights Reserved.</p>
        </footer>

    </form>

   
</body>
</html>
