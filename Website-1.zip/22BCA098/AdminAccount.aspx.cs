﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;

public partial class AdminAccount : Page
{
    // Define the AdminDetails class here
    public class AdminDetails
    {
        public string AdminName { get; set; }
        public string ImageUrl { get; set; }
    }

    // Page_Load event
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DateTime yesterday = DateTime.Now.AddDays(-1);
            lblAdminLastLogin.Text = yesterday.ToString("dd MMM yyyy");

            if (Session["AdminEmail"] == null)
            {
                Response.Redirect("AdminLogin.aspx"); // Redirect if session is empty
                return; // Stop execution
            }

            string adminEmail = (Session["AdminEmail"] != null) ? Session["AdminEmail"].ToString() : string.Empty;
            AdminDetails adminDetails = GetAdminDetails(adminEmail); // Get admin details (name & image)

            lblAdminName.Text = !string.IsNullOrEmpty(adminDetails.AdminName) ? adminDetails.AdminName : "Admin"; // Set admin name
            if (!string.IsNullOrEmpty(adminDetails.ImageUrl))
            {
                imgAdminProfile.ImageUrl = adminDetails.ImageUrl; // Set admin image URL
            }
            else
            {
                imgAdminProfile.ImageUrl = "~/images/default-profile.png"; // Fallback image
            }


            string adminEmail1 = Session["AdminEmail"].ToString();
            AdminDetails adminDetails1 = GetAdminDetails(adminEmail1);

            lblAdminName1.Text = !string.IsNullOrEmpty(adminDetails.AdminName) ? adminDetails.AdminName : "Admin";
            lblAdminEmail.Text = adminEmail1; // Display the correct admin email
            if (!string.IsNullOrEmpty(adminDetails.ImageUrl))
            {
                imgAdminProfile1.ImageUrl = adminDetails.ImageUrl; // Set admin image URL
            }
            else
            {
                imgAdminProfile1.ImageUrl = "~/images/default-profile.png"; // Fallback image
            }


        }
    }

    // Method to get admin details from the database
    private AdminDetails GetAdminDetails(string email)
    {
        AdminDetails adminDetails = new AdminDetails
        {
            AdminName = "Admin", // Default value
            ImageUrl = "" // Default value for image URL
        };

        string connStr = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\gkpat\OneDrive\Desktop\22BCA098\App_Data\Database.mdf;Integrated Security=True;User Instance=True";

        try
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string query = "SELECT name, image FROM admins WHERE email = @Email";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Email", email);
                    conn.Open();

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            adminDetails.AdminName = reader["name"].ToString();
                            adminDetails.ImageUrl = reader["image"] != DBNull.Value ? reader["image"].ToString() : "";
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            // Log the error (optional)
            System.Diagnostics.Debug.WriteLine("Database Error: " + ex.Message);
        }

        return adminDetails; // Return the AdminDetails object
    }

    // Logout button click handler
    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Redirect("AdminLogin.aspx"); // Redirect to login after logout
    }
}
