﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.UI;

public partial class AdminLogin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label1.Text = "";
    }
    protected void btnAdminLogin_Click(object sender, EventArgs e)
    {
        if (string.IsNullOrEmpty(txtAdminEmail.Text) || string.IsNullOrEmpty(txtAdminPassword.Text))
        {
            Label1.Text = "Please enter both fields.";
            Label1.ForeColor = System.Drawing.Color.Red;
            Label1.Visible = true;
        }
        else
        {
            string adminEmail = txtAdminEmail.Text.Trim();
            string adminPassword = txtAdminPassword.Text.Trim();

            // Connection string from Web.config
            string connStr = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\gkpat\OneDrive\Desktop\22BCA098\App_Data\Database.mdf;Integrated Security=True;User Instance=True";


            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string query = "SELECT COUNT(1) FROM admins WHERE email = @Email AND password = @Password";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Email", adminEmail);
                cmd.Parameters.AddWithValue("@Password", adminPassword); // Store hashed passwords in production!

                conn.Open();
                int count = Convert.ToInt32(cmd.ExecuteScalar());
                conn.Close();

                if (count == 1)
                {
                    // Valid admin, redirect to dashboard
                    Session["AdminEmail"] = adminEmail; // Store session for authenticated user
                    Response.Redirect("AdminDashboard.aspx");
                }
                else
                {
                    // Invalid credentials
                    Label1.Text = "Invalid email or password!";
                    Label1.ForeColor = System.Drawing.Color.Red;
                }
            }
        }
    }
}