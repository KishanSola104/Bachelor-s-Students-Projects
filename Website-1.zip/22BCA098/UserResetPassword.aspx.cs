﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Security;
using System.Web.UI;

public partial class UserResetPassword : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserEmail"] == null)
        {
            Response.Redirect("Login.aspx"); // Redirect to login if session is null
        }
    }

    protected void btnResetPassword_Click(object sender, EventArgs e)
    {
        string userEmail = Session["UserEmail"].ToString();
        string oldPassword = txtOldPassword.Text.Trim();
        string newPassword = txtNewPassword.Text.Trim();
        string confirmPassword = txtConfirmPassword.Text.Trim();

        if (newPassword != confirmPassword)
        {
            ShowAlert("New password and confirm password do not match.");
            return;
        }

        string connStr = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\gkpat\OneDrive\Desktop\22BCA098\App_Data\Database.mdf;Integrated Security=True;User Instance=True";

        using (SqlConnection conn = new SqlConnection(connStr))
        {
            conn.Open();

            // Check if the old password is correct
            string query = "SELECT password FROM Users WHERE email = @email";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@Email", userEmail);

            object result = cmd.ExecuteScalar();

            if (result == null || result.ToString() != oldPassword)
            {
                ShowAlert("Current password is incorrect.");
                return;
            }

            // Update the new password
            string updateQuery = "UPDATE Users SET password = @NewPassword WHERE email = @email";
            SqlCommand updateCmd = new SqlCommand(updateQuery, conn);
            updateCmd.Parameters.AddWithValue("@NewPassword", newPassword);
            updateCmd.Parameters.AddWithValue("@Email", userEmail);

            int rowsAffected = updateCmd.ExecuteNonQuery();

            if (rowsAffected > 0)
            {
                ShowAlert("Password reset successfully.");
                Response.Redirect("UserDashboard.aspx"); // Redirect to dashboard
            }
            else
            {
                ShowAlert("Error updating password. Please try again.");
            }
        }
    }

    private void ShowAlert(string message)
    {
        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('" + message + "');", true);
    }
}
