﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="Checkout.aspx.cs" Inherits="Checkout" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
 <title>Checkout</title>
    <style>
    body {
    font-family: Arial, sans-serif;
    background-color: #f8f9fa;
}

.checkout-container {
    width: 70%;
    margin: auto;
    background: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
}

h2, h3 {
    text-align: center;
    color: #333;
}

.user-details, .cart-summary, .payment-method {
    margin-bottom: 20px;
}

.detail-label {
    font-size: 16px;
    display: block;
}

.cart-table {
    width: 100%;
    border-collapse: collapse;
}

.cart-table th, .cart-table td {
    padding: 10px;
    border-bottom: 1px solid #ddd;
    text-align: center;
}

.payment-dropdown {
    width: 100%;
    padding: 10px;
}

.btn-pay, .btn-cancel {
    width: 48%;
    padding: 10px;
    border: none;
    border-radius: 5px;
    font-size: 16px;
    cursor: pointer;
}

.btn-pay {
    background-color: #28a745;
    color: white;
}

.btn-cancel {
    background-color: #dc3545;
    color: white;
}

    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="checkout-container">
            <h2>Checkout</h2>

            <div class="user-details">
                <h3>Billing Details</h3>
                <asp:Label ID="lblName" runat="server" CssClass="detail-label"></asp:Label><br />
                <asp:Label ID="lblEmail" runat="server" CssClass="detail-label"></asp:Label><br />
                <asp:Label ID="lblPhone" runat="server" CssClass="detail-label"></asp:Label><br />
                <asp:Label ID="lblAddress" runat="server" CssClass="detail-label"></asp:Label><br />
            </div>

            <div class="cart-summary">
                <h3>Order Summary</h3>
                <asp:GridView ID="gvCart" runat="server" AutoGenerateColumns="False" CssClass="cart-table">
                    <Columns>
                        <asp:BoundField DataField="ProductName" HeaderText="Product" />
                        <asp:BoundField DataField="ProductPrice" HeaderText="Price" DataFormatString="{0:C}" />
                        <asp:BoundField DataField="Quantity" HeaderText="Qty" />
                        <asp:BoundField DataField="TotalPrice" HeaderText="Total" DataFormatString="{0:C}" />
                    </Columns>
                </asp:GridView>
                <h3>Total Amount: <asp:Label ID="lblTotalPrice" runat="server" CssClass="total-price"></asp:Label></h3>
            </div>

            <div class="payment-method">
                <h3>Payment Options</h3>
                <asp:DropDownList ID="ddlPaymentMethod" runat="server" CssClass="payment-dropdown">
                    <asp:ListItem Text="Select Payment Method" Value="" />
                    <asp:ListItem Text="Credit/Debit Card" Value="Card" />
                    <asp:ListItem Text="UPI (Google Pay, PhonePe, Paytm)" Value="UPI" />
                    <asp:ListItem Text="Net Banking" Value="NetBanking" />
                    <asp:ListItem Text="Cash on Delivery (COD)" Value="COD" />
                </asp:DropDownList>
            </div>

            <div class="checkout-buttons">
                <asp:Button ID="btnPayNow" runat="server" Text="Pay Now" CssClass="btn-pay" OnClick="btnPayNow_Click" />
                <asp:Button ID="btnCancel" runat="server" Text="Cancel" CssClass="btn-cancel" OnClick="btnCancel_Click" />
            </div>
        </div>
    </form>
</body>
</html>