﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;

public partial class BillSlip : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["CustomerEmail"] == null)
            {
                Response.Redirect("CustomerLogin.aspx");
            }
            LoadBillDetails();
        }
    }

    private void LoadBillDetails()
    {
        string transactionID = Request.QueryString["TransactionID"];
        if (string.IsNullOrEmpty(transactionID))
        {
            lblTransactionID.Text = "Invalid Transaction!";
            return;
        }

        string connStr = ConfigurationManager.ConnectionStrings["CESHotelDB"].ConnectionString;
        using (SqlConnection con = new SqlConnection(connStr))
        {
            string query = "SELECT CustomerEmail, RoomID, Amount, PaymentMethod, PaymentDate FROM Payments WHERE TransactionID = @TransactionID";
            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                cmd.Parameters.AddWithValue("@TransactionID", transactionID);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    lblTransactionID.Text = "Transaction ID: " + transactionID;
                    lblCustomerEmail.Text = "Customer Email: " + dr["CustomerEmail"].ToString();
                    lblAmount.Text = "Amount: " + dr["Amount"].ToString();
                    lblPaymentMethod.Text = "Payment Method: " + dr["PaymentMethod"].ToString();
                    lblPaymentDate.Text = "Payment Date: " + dr["PaymentDate"].ToString();

                    string roomID = dr["RoomID"].ToString();
                    UpdateRoomStatus(roomID);

                    GetRoomDetails(roomID);
                }
                con.Close();
            }
        }
    }

    private void GetRoomDetails(string roomID)
    {
        string connStr = ConfigurationManager.ConnectionStrings["CESHotelDB"].ConnectionString;
        using (SqlConnection con = new SqlConnection(connStr))
        {
            string query = "SELECT RoomType FROM Rooms WHERE RoomID = @RoomID";
            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                cmd.Parameters.AddWithValue("@RoomID", roomID);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    lblRoomDetails.Text = "Room Type: " + dr["RoomType"].ToString();
                }
                con.Close();
            }
        }
    }

    private void UpdateRoomStatus(string roomID)
    {
        string connStr = ConfigurationManager.ConnectionStrings["CESHotelDB"].ConnectionString;
        using (SqlConnection con = new SqlConnection(connStr))
        {
            string query = "UPDATE Rooms SET Status = 'Booked' WHERE RoomID = @RoomID";
            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                cmd.Parameters.AddWithValue("@RoomID", roomID);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }
    }

    protected void btnDownload_Click(object sender, EventArgs e)
    {
        string transactionID = Request.QueryString["TransactionID"];
        string billContent = "Transaction ID: " + transactionID + "\n"
                           + lblCustomerEmail.Text + "\n"
                           + lblRoomDetails.Text + "\n"
                           + lblAmount.Text + "\n"
                           + lblPaymentMethod.Text + "\n"
                           + lblPaymentDate.Text;

        string fileName = "Bill_" + transactionID + ".txt";
        string filePath = Server.MapPath("~/Bills/") + fileName;

        if (!Directory.Exists(Server.MapPath("~/Bills/")))
        {
            Directory.CreateDirectory(Server.MapPath("~/Bills/"));
        }

        File.WriteAllText(filePath, billContent);

        Response.ContentType = "text/plain";
        Response.AppendHeader("Content-Disposition", "attachment; filename=" + fileName);
        Response.WriteFile(filePath);
        Response.End();
    }
}
