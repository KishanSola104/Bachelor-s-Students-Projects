﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

public partial class ConfirmBooking : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                if (Session["CustomerEmail"] == null)
                {
                    Response.Redirect("CustomerLogin.aspx");
                }
                LoadRoomDetails();
            }
        }
        catch (Exception ex)
        {
            lblError.Text = "An error occurred while loading the page: " + ex.Message;
        }
    }

    private void LoadRoomDetails()
    {
        try
        {
            string roomID = Request.QueryString["RoomID"];
            if (string.IsNullOrEmpty(roomID))
            {
                lblError.Text = "Invalid Room Selection!";
                return;
            }

            string connStr = ConfigurationManager.ConnectionStrings["CESHotelDB"].ConnectionString;
            using (SqlConnection con = new SqlConnection(connStr))
            {
                string query = "SELECT RoomType, PricePerNight, Status FROM Rooms WHERE RoomID = @RoomID";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@RoomID", roomID);
                    con.Open();
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {
                        lblRoomType.Text = dr["RoomType"].ToString();
                        lblPrice.Text = dr["PricePerNight"].ToString();
                        lblStatus.Text = dr["Status"].ToString();
                    }
                    else
                    {
                        lblError.Text = "Room not found!";
                    }
                    con.Close();
                }
            }
        }
        catch (Exception ex)
        {
            lblError.Text = "Error fetching room details: " + ex.Message;
        }
    }

    protected void btnConfirm_Click(object sender, EventArgs e)
    {
        try
        {
            string roomID = Request.QueryString["RoomID"];
            if (string.IsNullOrEmpty(roomID))
            {
                lblError.Text = "Invalid Room Selection!";
                return;
            }

            string customerEmail = "";
            if (Session["CustomerEmail"] != null)
            {
                customerEmail = Session["CustomerEmail"].ToString();
            }
            else
            {
                lblError.Text = "Session expired. Please log in again.";
                return;
            }

            if (string.IsNullOrWhiteSpace(txtCheckIn.Text) || string.IsNullOrWhiteSpace(txtCheckOut.Text))
            {
                lblError.Text = "Please select both Check-in and Check-out dates.";
                return;
            }

            DateTime checkIn, checkOut;
            if (!DateTime.TryParse(txtCheckIn.Text, out checkIn) || !DateTime.TryParse(txtCheckOut.Text, out checkOut))
            {
                lblError.Text = "Invalid date format. Please enter valid dates.";
                return;
            }

            if (checkIn >= checkOut)
            {
                lblError.Text = "Check-out date must be after Check-in date.";
                return;
            }

            string connStr = ConfigurationManager.ConnectionStrings["CESHotelDB"].ConnectionString;
            using (SqlConnection con = new SqlConnection(connStr))
            {
                string query = "INSERT INTO Bookings (CustomerEmail, RoomID, CheckInDate, CheckOutDate, Status) VALUES (@Email, @RoomID, @CheckIn, @CheckOut, 'Pending')";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@Email", customerEmail);
                    cmd.Parameters.AddWithValue("@RoomID", roomID);
                    cmd.Parameters.AddWithValue("@CheckIn", checkIn);
                    cmd.Parameters.AddWithValue("@CheckOut", checkOut);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
            Response.Redirect("Payment.aspx?RoomID=" + roomID);
        }
        catch (SqlException sqlEx)
        {
            lblError.Text = "Database error: " + sqlEx.Message;
        }
        catch (Exception ex)
        {
            lblError.Text = "An unexpected error occurred: " + ex.Message;
        }
    }
}
