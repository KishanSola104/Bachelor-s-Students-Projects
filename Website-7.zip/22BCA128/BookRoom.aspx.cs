﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

public partial class BookRoom : System.Web.UI.Page
{
    string connectionString = ConfigurationManager.ConnectionStrings["CESHotelDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        // Ensure session is active
        if (Session["CustomerEmail"] == null || string.IsNullOrEmpty(Session["CustomerEmail"].ToString()))
        {
            Response.Redirect("CustomerLogin.aspx");
        }

        if (!IsPostBack)
        {
            LoadRooms();
        }
    }

    private void LoadRooms()
    {
        try
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT RoomID, RoomType,ISAC, PricePerNight, Status, Description FROM Rooms WHERE Status = 'Available'";

                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);

                // Ensure ImagePath column exists
                dt.Columns.Add("ImagePath", typeof(string));

                // Assign images cyclically
                string[] roomImages = { "room1.jpg", "room2.jpg", "room3.jpg", "room4.jpg", "room5.jpg" };

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    dt.Rows[i]["ImagePath"] = "Images/" + roomImages[i % roomImages.Length]; // Assign image path
                }

                rptRooms.DataSource = dt;
                rptRooms.DataBind();
            }
        }
        catch (Exception ex)
        {
            lblMessage.Text = "Error loading rooms: " + ex.Message;
        }
    }

    protected void btnBook_Click(object sender, EventArgs e)
    {
        // Ensure session is still valid before processing
        if (Session["CustomerEmail"] == null || string.IsNullOrEmpty(Session["CustomerEmail"].ToString()))
        {
            lblMessage.Text = "Session expired. Please log in again.";
            Response.Redirect("CustomerLogin.aspx");
            return;
        }

        Button btn = (Button)sender;
        string roomID = btn.CommandArgument;
        string customerEmail = Session["CustomerEmail"].ToString();

        // Store selected RoomID in session before redirecting
        Session["SelectedRoomID"] = roomID;

        // Redirect to Confirm Booking page
        Response.Redirect("ConfirmBooking.aspx?RoomID=" + roomID);
    }
}
