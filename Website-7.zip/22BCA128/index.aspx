﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="index.aspx.cs" Inherits="index" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  
    <title>CES Hotel</title>
    <style>
        body { margin: 0; font-family: Arial, sans-serif; }
        
        /* Header */
        .header { background-color: #2C3E50; color: white; padding: 20px; text-align: center; position: relative; }
        
        /* Login Button & Dropdown */
        .login-container { position: absolute; right: 20px; top: 15px; }
        .login-btn { background-color: white; border: none; padding: 8px 15px; cursor: pointer; }
        .login-dropdown { display: none; position: absolute; right: 0; background: white; box-shadow: 0px 4px 6px rgba(0,0,0,0.2); }
        .login-dropdown a { display: block; padding: 10px; text-decoration: none; color: black; }
        .login-dropdown a:hover { background-color: #ddd; }

        /* Main Content - Image with Welcome Text */
        .main-content { position: relative; width: 100%; height: 600px; }
        .main-content img { width: 100%; height: 100%; object-fit: cover; }
        .welcome-text {
            position: absolute; top: 50%; left: 50%;
            transform: translate(-50%, -50%);
            color: white; font-size: 36px; font-weight: bold;
            background: rgba(0, 0, 0, 0.6); padding: 20px; border-radius: 10px;
        }

        /* Footer */
        .footer { background-color: #2C3E50; color: white; text-align: center; padding: 15px; }
    </style>

    <script>
        function toggleDropdown() {
            var dropdown = document.getElementById("loginDropdown");
            dropdown.style.display = (dropdown.style.display === "block") ? "none" : "block";
        }
    </script>
</head>
<body>
    <form id="Form1" runat="server">
        <!-- Header -->
        <div class="header">
            <h1>CES Hotel</h1>
            <div class="login-container">
                <button class="login-btn" type="button" onclick="toggleDropdown()">Login</button>
                <div id="loginDropdown" class="login-dropdown">
                    <a href="AdminLogin.aspx">Admin</a>
                    <a href="CustomerLogin.aspx">Customer</a>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <img src="img1.jpg" alt="CES Hotel">
            <div class="welcome-text">Welcome to CES Hotel – Luxury & Comfort Awaits You</div>
        </div>

        <!-- Footer -->
        <div class="footer">
            <p>Address: CES Hotel, Main Street, City Name</p>
            <p>Contact: +123 456 789 | Email: contact@ceshotel.com</p>
        </div>
    </form>
</body>
</html>