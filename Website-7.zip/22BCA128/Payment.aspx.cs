﻿using System;
using System.Configuration;
using System.Data.SqlClient;

public partial class Payment : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["CustomerEmail"] == null)
            {
                Response.Redirect("CustomerLogin.aspx");
            }

            if (!IsPostBack)
            {
                LoadPaymentDetails();
            }
        }
        catch (Exception ex)
        {
            lblMessage.Text = "Error: " + ex.Message;
        }
    }

    private void LoadPaymentDetails()
    {
        try
        {
            string roomID = Request.QueryString["RoomID"];
            if (string.IsNullOrEmpty(roomID))
            {
                throw new Exception("Room ID is missing.");
            }

            string connStr = ConfigurationManager.ConnectionStrings["CESHotelDB"].ConnectionString;
            using (SqlConnection con = new SqlConnection(connStr))
            {
                string query = "SELECT RoomType, PricePerNight FROM Rooms WHERE RoomID = @RoomID";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@RoomID", roomID);
                    con.Open();
                    SqlDataReader dr = cmd.ExecuteReader();

                    if (dr.Read())
                    {
                        lblRoomDetails.Text = "Room Type: " + dr["RoomType"].ToString();
                        lblAmount.Text = "Amount: " + dr["PricePerNight"].ToString();
                        hfAmount.Value = dr["PricePerNight"].ToString();
                    }
                    else
                    {
                        throw new Exception("Room details not found.");
                    }
                }
            }
        }
        catch (SqlException sqlEx)
        {
            lblMessage.Text = "Database error: " + sqlEx.Message;
        }
        catch (Exception ex)
        {
            lblMessage.Text = "Error: " + ex.Message;
        }
    }

    protected void btnPay_Click(object sender, EventArgs e)
    {
        try
        {
            if (Session["CustomerEmail"] == null)
            {
                Response.Redirect("CustomerLogin.aspx");
                return;
            }

            string roomID = Request.QueryString["RoomID"];
            if (string.IsNullOrEmpty(roomID))
            {
                throw new Exception("Room ID is missing.");
            }

            string customerEmail = Session["CustomerEmail"].ToString();
            string paymentMethod = ddlPaymentMethod.SelectedValue;
            if (string.IsNullOrEmpty(paymentMethod))
            {
                throw new Exception("Please select a payment method.");
            }

            decimal amount;
            if (!decimal.TryParse(hfAmount.Value, out amount) || amount <= 0)
            {
                throw new Exception("Invalid payment amount.");
            }

            string transactionID = Guid.NewGuid().ToString();
            string connStr = ConfigurationManager.ConnectionStrings["CESHotelDB"].ConnectionString;

            using (SqlConnection con = new SqlConnection(connStr))
            {
                string query = "INSERT INTO Payments (PaymentID, CustomerEmail, RoomID, Amount, PaymentDate, PaymentMethod, TransactionID) " +
                               "VALUES (@PaymentID, @Email, @RoomID, @Amount, GETDATE(), @Method, @TransactionID)";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@PaymentID", Guid.NewGuid().ToString());
                    cmd.Parameters.AddWithValue("@Email", customerEmail);
                    cmd.Parameters.AddWithValue("@RoomID", roomID);
                    cmd.Parameters.AddWithValue("@Amount", amount);
                    cmd.Parameters.AddWithValue("@Method", paymentMethod);
                    cmd.Parameters.AddWithValue("@TransactionID", transactionID);

                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }

            Response.Redirect("BillSlip.aspx?TransactionID=" + transactionID);
        }
        catch (SqlException sqlEx)
        {
            lblMessage.Text = "Database error: " + sqlEx.Message;
        }
        catch (Exception ex)
        {
            lblMessage.Text = "Error: " + ex.Message;
        }
    }

}
