﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Configuration;


public partial class AdminDashboard : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadDashboardCounts();
        }
    }



    private void LoadDashboardCounts()
    {
        string connStr = ConfigurationManager.ConnectionStrings["CESHotelDB"].ConnectionString;
        using (SqlConnection con = new SqlConnection(connStr))
        {
            try
            {
                con.Open();

                // Get Total Bookings
                SqlCommand cmdBookings = new SqlCommand("SELECT COUNT(*) FROM Bookings", con);
                int totalBookings = (int)cmdBookings.ExecuteScalar();
                totalBookingsLabel.Text = totalBookings.ToString();

                // Get Total Customers
                SqlCommand cmdCustomers = new SqlCommand("SELECT COUNT(*) FROM Customers", con);
                int totalCustomers = (int)cmdCustomers.ExecuteScalar();
                totalCustomersLabel.Text = totalCustomers.ToString();

                // Get Available Rooms
                SqlCommand cmdAvailableRooms = new SqlCommand("SELECT COUNT(*) FROM Rooms WHERE Status = 'Available'", con);
                int availableRooms = (int)cmdAvailableRooms.ExecuteScalar();
                availableRoomsLabel.Text = availableRooms.ToString();

                // Get Occupied Rooms
                SqlCommand cmdOccupiedRooms = new SqlCommand("SELECT COUNT(*) FROM Rooms WHERE Status = 'Booked'", con);
                int occupiedRooms = (int)cmdOccupiedRooms.ExecuteScalar();
                occupiedRoomsLabel.Text = occupiedRooms.ToString();
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('Error loading dashboard data: " + ex.Message + "');</script>");
            }
            finally
            {
                con.Close();
            }
        }
    }
}