﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="AdminDashboard.aspx.cs" Inherits="AdminDashboard" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Admin Dashboard - CES Hotel</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 0; background-color: #f4f4f4; }
        .header { background: #333; color: white; padding: 18px; text-align: center; font-size: 24px; position: relative; }
        .logout-btn { position: absolute; right: 20px; top: 15px; padding: 8px 16px; background: red; color: white; text-decoration: none; border-radius: 5px; }
        .container { max-width: 1200px; margin: 20px auto; padding: 20px; background: white; border-radius: 10px; height:650px; }
        .card { display: inline-block; width: 23%; padding: 20px; background: #007bff; color: white; margin: 10px; text-align: center; border-radius: 5px; }
        .actions a { display: block; text-align: center; padding: 15px; background: #28a745; color: white; margin: 10px; text-decoration: none; border-radius: 5px; }
        .footer { background: #333; color: white; text-align: center; padding: 10px; margin-top: 20px; }
    </style>
</head>
<body>
    <div class="header">
        CES Hotel - Admin Dashboard
        <a href="AdminLogin.aspx" class="logout-btn">Logout</a>
    </div>

       <div class="container">
        <h2>Dashboard Overview</h2>
     <div class="card">Total Bookings: <asp:Label ID="totalBookingsLabel" runat="server" Text="0"></asp:Label></div>
<div class="card">Total Customers: <asp:Label ID="totalCustomersLabel" runat="server" Text="0"></asp:Label></div>
<div class="card">Available Rooms: <asp:Label ID="availableRoomsLabel" runat="server" Text="0"></asp:Label></div>
<div class="card">Occupied Rooms: <asp:Label ID="occupiedRoomsLabel" runat="server" Text="0"></asp:Label></div>

        
        <h2>Quick Actions</h2>
        <div class="actions">
            <a href="ManageRooms.aspx">Manage Rooms</a>
            <a href="ManageBookings.aspx">Manage Bookings</a>
            <a href="ManageCustomers.aspx">Manage Customers</a>
            <a href="ManageEmployees.aspx">Manage Employees</a>
          
        </div>
    </div>
    
    <div class="footer">
        CES Hotel, Sardar Gunj , Anand - Contact: +123 456 7890
    </div>
</body>
</html>
