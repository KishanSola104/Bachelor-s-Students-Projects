﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="SignUp.aspx.cs" Inherits="SignUp" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
 <title>Customer Sign Up</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(to right, #ff416c, #ff4b2b);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .signup-container {
            width: 400px;
            background: #ffffff;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.2);
            text-align: center;
        }

        h2 {
            margin-bottom: 15px;
            color: #333;
            font-size: 22px;
        }

        .input-field, .dropdown {
            width: 100%;
            padding: 12px;
            margin: 8px 0;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 16px;
            outline: none;
        }

        .btn-signup {
            width: 100%;
            background: linear-gradient(to right, #ff416c, #ff4b2b);
            color: white;
            padding: 12px;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 10px;
            transition: 0.3s;
        }

        .btn-signup:hover {
            background: linear-gradient(to right, #ff4b2b, #ff416c);
        }

        .error-message {
            color: red;
            font-size: 14px;
            margin-top: 8px;
        }

        .login-link {
            display: block;
            margin-top: 15px;
            color: #ff416c;
            text-decoration: none;
            font-weight: bold;
        }

        .login-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="signup-container">
            <h2>Customer Sign Up</h2>
            <asp:Label ID="lblMessage" runat="server" CssClass="error-message"></asp:Label>

            <asp:TextBox ID="txtFullName" runat="server" CssClass="input-field" Placeholder="Full Name"></asp:TextBox>
            <asp:TextBox ID="txtEmail" runat="server" CssClass="input-field" Placeholder="Email"></asp:TextBox>
            <asp:TextBox ID="txtMobile" runat="server" CssClass="input-field" Placeholder="Mobile No"></asp:TextBox>
             <asp:TextBox ID="txtCity" runat="server" CssClass="input-field" Placeholder="Enter City"></asp:TextBox>
            <asp:DropDownList ID="ddlGen" runat="server" CssClass="dropdown">
                <asp:ListItem Text="Male" Value="Male" />
                <asp:ListItem Text="Female" Value="Female" />
            </asp:DropDownList>

            <asp:TextBox ID="txtAddress" runat="server" CssClass="input-field" TextMode="MultiLine" Rows="3" Placeholder="Full Address"></asp:TextBox>

            <asp:TextBox ID="txtPassword" runat="server" CssClass="input-field" TextMode="Password" Placeholder="Password"></asp:TextBox>
            <asp:TextBox ID="txtConfirmPassword" runat="server" CssClass="input-field" TextMode="Password" Placeholder="Confirm Password"></asp:TextBox>

            <asp:Button ID="btnSignUp" runat="server" Text="Sign Up" OnClick="btnSignUp_Click" CssClass="btn-signup" />
            <asp:HyperLink ID="lnkLogin" runat="server" NavigateUrl="CustomerLogin.aspx" CssClass="login-link">Already have an account? Login</asp:HyperLink>
        </div>
    </form>
</body>
</html>