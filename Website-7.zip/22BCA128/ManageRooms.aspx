﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="ManageRooms.aspx.cs" Inherits="ManageRooms" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>Manage Rooms - CES Hotel</title>
    <style>
    body {
    font-family: Arial, sans-serif;
    background-color: #f8f9fa;
    margin: 0;
    padding: 0;
}

.container {
    max-width: 900px;
    margin: 30px auto;
    padding: 25px;
    background: white;
    border-radius: 10px;
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
}

.header {
    background: #343a40;
    color: white;
    text-align: center;
    padding: 20px;
    font-size: 26px;
    font-weight: bold;
    border-radius: 10px 10px 0 0;
}

h2 {
    color: #333;
    margin-bottom: 15px;
    text-align: center;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
    background: white;
}

th, td {
    padding: 12px;
    border: 1px solid #ddd;
    text-align: center;
}

th {
    background: #007bff;
    color: white;
    font-size: 16px;
}

td {
    font-size: 14px;
    background: #f9f9f9;
}

tr:hover {
    background: #f1f1f1;
}

.btn {
    padding: 10px 14px;
    color: white;
    border: none;
    cursor: pointer;
    border-radius: 5px;
    font-size: 14px;
    transition: 0.3s ease;
}

.btn-add {
    background: #28a745;
}

.btn-add:hover {
    background: #218838;
}

.btn-edit {
    background: #ffc107;
}

.btn-edit:hover {
    background: #e0a800;
}

.btn-delete {
    background: #dc3545;
}

.btn-delete:hover {
    background: #c82333;
}

input[type="text"], select {
    width: 100%;
    padding: 10px;
    margin: 10px 0;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 14px;
    background: #f8f8f8;
    transition: 0.3s;
}

input[type="text"]:focus, select:focus {
    border-color: #007bff;
    background: white;
    outline: none;
}

#lblMessage {
    display: block;
    font-size: 14px;
    text-align: center;
    margin-bottom: 10px;
}

    </style>
</head>
<body>
<form runat="server">
    <div class="header">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Manage Rooms&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
                                                          <asp:LinkButton ID="LinkButton1" runat="server" onclick="LinkButton1_Click">Home</asp:LinkButton></div>
    <div class="container">
        <h2>Add New Room</h2>
        <asp:Label ID="lblMessage" runat="server" ForeColor="Red"></asp:Label><br>
        <asp:TextBox ID="txtRoomID" runat="server" Placeholder="Room ID"></asp:TextBox>
        <asp:DropDownList ID="ddlRoomType" runat="server">
            <asp:ListItem>Single</asp:ListItem>
            <asp:ListItem>Double</asp:ListItem>
            <asp:ListItem>Suite</asp:ListItem>
        </asp:DropDownList>

         <asp:DropDownList ID="ddlAC" runat="server">
            <asp:ListItem>AC</asp:ListItem>
            <asp:ListItem>Non-AC</asp:ListItem>
        </asp:DropDownList>
        <asp:TextBox ID="txtPrice" runat="server" Placeholder="Price Per Night"></asp:TextBox>
        <asp:TextBox ID="txtDescription" runat="server" Placeholder="Description" ></asp:TextBox>

        <asp:DropDownList ID="ddlStatus" runat="server">
            <asp:ListItem>Available</asp:ListItem>
            <asp:ListItem>Occupied</asp:ListItem>
            <asp:ListItem>Maintenance</asp:ListItem>
        </asp:DropDownList>
        <asp:Button ID="btnAdd" runat="server" Text="Add Room" CssClass="btn btn-add" OnClick="btnAdd_Click" />
        
        <h2>Room List</h2>
        <asp:GridView ID="gvRooms" runat="server" AutoGenerateColumns="False" OnRowCommand="gvRooms_RowCommand">
            <Columns>
                <asp:BoundField DataField="RoomID" HeaderText="Room ID" />
                <asp:BoundField DataField="RoomType" HeaderText="Room Type" />
                <asp:BoundField DataField="PricePerNight" HeaderText="Price Per Night" />
                <asp:BoundField DataField="Status" HeaderText="Status" />
                <asp:BoundField DataField="ISAC" HeaderText="AC Or Not" />
                <asp:TemplateField HeaderText="Actions">
                    <ItemTemplate>
                        <asp:Button ID="Button1" CommandName="EditRoom" CommandArgument='<%# Eval("RoomID") %>' Text="Edit" CssClass="btn btn-edit" runat="server" />
                        <asp:Button ID="Button2" CommandName="DeleteRoom" CommandArgument='<%# Eval("RoomID") %>' Text="Delete" CssClass="btn btn-delete" runat="server" />
                    </ItemTemplate>
                </asp:TemplateField>
            </Columns>
        </asp:GridView>
    </div>
    </form>
</body>
</html>
