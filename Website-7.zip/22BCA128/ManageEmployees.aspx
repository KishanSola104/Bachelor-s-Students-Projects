﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="ManageEmployees.aspx.cs" Inherits="ManageEmployees" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
   <title>Manage Employees - CES Hotel</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; }
        .container { max-width: 900px; margin: 20px auto; padding: 20px; background: white; border-radius: 10px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); }
        .header { background: #333; color: white; text-align: center; padding: 15px; font-size: 24px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 10px; border: 1px solid #ddd; text-align: center; }
        th { background: #007bff; color: white; }
        .btn { padding: 8px 12px; color: white; border: none; cursor: pointer; border-radius: 5px; }
        .btn-edit { background: orange; }
        .btn-delete { background: red; }
        .btn-add { background: green; }
        .input-field { width: 100%; padding: 8px; margin-top: 5px; border: 1px solid #ddd; border-radius: 5px; }
    </style>
</head>
<body>
    <form id="Form1" runat="server">
        <div class="header">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Manage Employees&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <asp:LinkButton ID="LinkButton1" runat="server" onclick="LinkButton1_Click">Home</asp:LinkButton>
        </div>
        <div class="container">
            <h2>Add New Employee</h2>
            <asp:Label ID="lblMessage" runat="server" ForeColor="Red"></asp:Label><br>
            <asp:TextBox ID="txtEmployeeID" runat="server" Placeholder="Employee ID" CssClass="input-field"></asp:TextBox>
            <asp:TextBox ID="txtEmployeeName" runat="server" Placeholder="Employee Name" CssClass="input-field"></asp:TextBox>
            <asp:TextBox ID="txtPosition" runat="server" Placeholder="Position" CssClass="input-field"></asp:TextBox>
            <asp:TextBox ID="txtSalary" runat="server" Placeholder="Salary" CssClass="input-field"></asp:TextBox>
            
            <asp:DropDownList ID="ddlStatus" runat="server" CssClass="input-field">
                <asp:ListItem>Active</asp:ListItem>
                <asp:ListItem>Inactive</asp:ListItem>
            </asp:DropDownList>
            
            <asp:Button ID="btnAdd" runat="server" Text="Add Employee" CssClass="btn btn-add" OnClick="btnAdd_Click" />
            
            <h2>Employee List</h2>
            <asp:GridView ID="gvEmployees" runat="server" AutoGenerateColumns="False" OnRowCommand="gvEmployees_RowCommand">
                <Columns>
                    <asp:BoundField DataField="EmployeeID" HeaderText="Employee ID" />
                    <asp:BoundField DataField="EmployeeName" HeaderText="Name" />
                    <asp:BoundField DataField="Position" HeaderText="Position" />
                    <asp:BoundField DataField="Salary" HeaderText="Salary" />
                    <asp:BoundField DataField="Status" HeaderText="Status" />
                    <asp:TemplateField HeaderText="Actions">
                        <ItemTemplate>
                            <asp:Button ID="btnEdit" CommandName="EditEmployee" CommandArgument='<%# Eval("EmployeeID") %>' Text="Edit" CssClass="btn btn-edit" runat="server" />
                            <asp:Button ID="btnDelete" CommandName="DeleteEmployee" CommandArgument='<%# Eval("EmployeeID") %>' Text="Delete" CssClass="btn btn-delete" runat="server" />
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>
            </asp:GridView>
        </div>
    </form>
</body>
</html>