﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="BillSlip.aspx.cs" Inherits="BillSlip" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
     <title>Bill Slip</title>
  <style>
       body {
    font-family: Arial, sans-serif;
    background-color: #f8f9fa;
    margin: 0;
    padding: 0;
}

/* Header Section */
.header {
    background-color: #007bff;
    color: white;
    padding: 15px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.header .welcome {
    font-size: 18px;
    font-weight: bold;
}

.nav {
    display: flex;
    gap: 20px;
}

.nav a {
    color: white;
    text-decoration: none;
    font-size: 16px;
    padding: 8px 15px;
    border-radius: 5px;
    transition: 0.3s;
}

.nav a:hover {
    background-color: #0056b3;
}

/* Main Content - Bill Slip Section */
.main-content {
    width: 100%;
    height: 85vh;
   
    display: flex;
    justify-content: center;
    align-items: center;
    text-align: center;
    color: white;
    flex-direction: column;
    padding: 20px;
}

.main-content h2 {
    font-size: 36px;
    font-weight: bold;
    background: rgba(0, 0, 0, 0.6);
    padding: 10px 20px;
    border-radius: 8px;
}

.info-text {
    font-size: 18px;
    max-width: 800px;
    background: rgba(0, 0, 0, 0.6);
    padding: 15px;
    border-radius: 8px;
    line-height: 1.6;
    margin-top: 10px;
}

/* Bill Details */
.bill-details {
    background: rgba(255, 255, 255, 0.9);
    color: black;
    padding: 20px;
    border-radius: 10px;
    text-align: left;
    max-width: 500px;
    width: 100%;
    margin-top: 20px;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.2);
}

.bill-details label {
    font-weight: bold;
    display: block;
    margin-top: 10px;
}

.bill-details .value {
    font-size: 16px;
    margin-bottom: 10px;
    display: block;
}

/* Button Styling */
.btn-download {
    background-color: #28a745;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    transition: 0.3s;
    margin-top: 15px;
}

.btn-download:hover {
    background-color: #218838;
}

/* Footer Section */
.footer {
    background-color: #343a40;
    color: white;
    text-align: center;
    padding: 10px;
    position: relative;
    bottom: 0;
    width: 100%;
}

/* Bill Slip Container */
.container {
    background: rgba(255, 255, 255, 0.9);
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.3);
    text-align: center;
    max-width: 400px;
    width: 90%;
    height:80vh;
    padding-left:35%
}

/* Bill Slip Heading */
.container h2 {
    font-size: 24px;
    color: #333;
    margin-bottom: 15px;
}

/* Bill Slip Labels */
.container label {
    font-weight: bold;
    display: block;
    margin-top: 8px;
    color: #555;
}

/* Button Styling */
.container button, .container input[type="submit"] {
    background-color: #28a745;
    color: white;
    padding: 10px 15px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    transition: 0.3s;
    margin-top: 10px;
}

.container button:hover, .container input[type="submit"]:hover {
    background-color: #218838;
}



    </style>
</head>
<body>
    <form id="form1" runat="server">
        <!-- Header -->
        <div class="header">
            <div class="welcome">Welcome, <asp:Label ID="lblCustomerName" runat="server" Text="Guest"></asp:Label></div>
            <div class="nav">
                <a href="CustomerDashboard.aspx">Home</a>
                <a href="BookRoom.aspx">Book Room</a>
                
                <a href="Services.aspx">Services</a>
                <a href="CustomerLogin.aspx">Log Out</a>
            </div>
        </div>

        <!-- Full-Screen Background Image -->
        <div class="container">
             <h2>Bill Slip</h2>
        <asp:Label ID="lblTransactionID" runat="server" Text="Transaction ID: "></asp:Label><br />
        <asp:Label ID="lblCustomerEmail" runat="server" Text="Customer Email: "></asp:Label><br />
        <asp:Label ID="lblRoomDetails" runat="server" Text="Room Details: "></asp:Label><br />
        <asp:Label ID="lblAmount" runat="server" Text="Amount: "></asp:Label><br />
        <asp:Label ID="lblPaymentMethod" runat="server" Text="Payment Method: "></asp:Label><br />
        <asp:Label ID="lblPaymentDate" runat="server" Text="Payment Date: "></asp:Label><br />
        <br />
        <asp:Button ID="btnDownload" runat="server" Text="Download Bill" OnClick="btnDownload_Click" />
     
        </div>

        <!-- Footer -->
        <div class="footer">
            &copy; 2025 CES Hotel. All Rights Reserved.
        </div>
    </form>
</body>
</html>