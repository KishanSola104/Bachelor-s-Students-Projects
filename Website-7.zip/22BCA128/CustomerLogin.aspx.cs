﻿
using System;
using System.Data.SqlClient;
using System.Configuration;

public partial class CustomerLogin : System.Web.UI.Page
{
    string connStr = ConfigurationManager.ConnectionStrings["CESHotelDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            string query = "SELECT COUNT(*) FROM Customers WHERE Email=@Email AND Password=@Password";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@Email", txtEmail.Text.Trim());
            cmd.Parameters.AddWithValue("@Password", txtPassword.Text.Trim());
            conn.Open();
            int count = Convert.ToInt32(cmd.ExecuteScalar());
            if (count > 0)
            {
                Session["CustomerEmail"] = txtEmail.Text.Trim();
                Response.Redirect("CustomerDashboard.aspx");
            }
            else
            {
                lblMessage.Text = "Invalid email or password!";
            }
        }
    }
}
