﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="CustomerDashboard.aspx.cs" Inherits="CustomerDashboard" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
 <title>Customer Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }

        /* Header Section */
        .header {
            background-color: #007bff;
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header .welcome {
            font-size: 18px;
            font-weight: bold;
        }

        .nav {
            display: flex;
            gap: 20px;
        }

        .nav a {
            color: white;
            text-decoration: none;
            font-size: 16px;
            padding: 8px 15px;
            border-radius: 5px;
            transition: 0.3s;
        }

        .nav a:hover {
            background-color: #0056b3;
        }

        /* Main Content - Fullscreen Background Image */
        .main-content {
            width: 100%;
            height: 85vh; /* Takes up almost full viewport height */
            background: url('Images/Hotel2.jpeg') no-repeat center center/cover;
            display: flex;
            justify-content: center;
            align-items: center;
            text-align: center;
            color: white;
            flex-direction: column;
            padding: 20px;
        }

        .main-content h2 {
            font-size: 36px;
            font-weight: bold;
            background: rgba(0, 0, 0, 0.6);
            padding: 10px 20px;
            border-radius: 8px;
        }

        .info-text {
            font-size: 18px;
            max-width: 800px;
            background: rgba(0, 0, 0, 0.6);
            padding: 15px;
            border-radius: 8px;
            line-height: 1.6;
            margin-top: 10px;
        }

        /* Footer Section */
        .footer {
            background-color: #343a40;
            color: white;
            text-align: center;
            padding: 10px;
            position: relative;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <!-- Header -->
        <div class="header">
            <div class="welcome">Welcome, <asp:Label ID="lblCustomerName" runat="server" Text="Guest"></asp:Label></div>
            <div class="nav">
                <a href="CustomerDashboard.aspx">Home</a>
                <a href="BookRoom.aspx">Book Room</a>
                
                <a href="Services.aspx">Services</a>
                <a href="CustomerLogin.aspx">Log Out</a>
            </div>
        </div>

        <!-- Full-Screen Background Image -->
        <div class="main-content">
            <h2>Welcome to CES Hotel</h2>
            <p class="info-text">
                Experience ultimate luxury and comfort at CES Hotel. We provide top-class 
                services, modern rooms, and delicious dining experiences to make your stay unforgettable.
            </p>
        </div>

        <!-- Footer -->
        <div class="footer">
            &copy; 2025 CES Hotel. All Rights Reserved.
        </div>
    </form>
</body>
</html>