﻿using System;
using System.Data.SqlClient;
using System.Configuration;

public partial class CustomerDashboard : System.Web.UI.Page
{
    string connStr = ConfigurationManager.ConnectionStrings["CESHotelDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["CustomerEmail"] == null)
        {
            Response.Redirect("CustomerLogin.aspx");
        }
        else
        {
            LoadCustomerName();
        }
    }

    private void LoadCustomerName()
    {
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            string query = "SELECT FullName FROM Customers WHERE Email = @Email";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@Email", Session["CustomerEmail"].ToString());

            conn.Open();
            object result = cmd.ExecuteScalar();
            if (result != null)
            {
                lblCustomerName.Text = result.ToString();
            }
            else
            {
                lblCustomerName.Text = "Guest";
            }
        }
    }
}
