﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class ManageEmployees : System.Web.UI.Page
{
    // Connection string from Web.config
    string connStr = ConfigurationManager.ConnectionStrings["CESHotelDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadEmployees();
        }
    }

    // Load Employee Data into GridView
    private void LoadEmployees()
    {
        try
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Employees", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                gvEmployees.DataSource = dt;
                gvEmployees.DataBind();
            }
        }
        catch (Exception ex)
        {
            lblMessage.Text = "Error: " + ex.Message;
        }
    }

    // Add New Employee
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                string query = "INSERT INTO Employees (EmployeeID , EmployeeName, Position, Salary, Status) VALUES (@ID , @Name, @Position, @Salary, @Status)";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@ID",txtEmployeeID.Text.Trim());
                    cmd.Parameters.AddWithValue("@Name", txtEmployeeName.Text.Trim());
                    cmd.Parameters.AddWithValue("@Position", txtPosition.Text.Trim());
                    cmd.Parameters.AddWithValue("@Salary", Convert.ToDecimal(txtSalary.Text.Trim()));
                    cmd.Parameters.AddWithValue("@Status", ddlStatus.SelectedValue);
                    cmd.ExecuteNonQuery();
                }
            }
            lblMessage.Text = "Employee added successfully!";
            ClearFields();
            LoadEmployees();
        }
        catch (Exception ex)
        {
            lblMessage.Text = "Error: " + ex.Message;
        }
    }

    // Handle Edit and Delete Button Clicks
    protected void gvEmployees_RowCommand(object sender, System.Web.UI.WebControls.GridViewCommandEventArgs e)
    {
        int employeeID = Convert.ToInt32(e.CommandArgument);
        if (e.CommandName == "EditEmployee")
        {
            LoadEmployeeForEdit(employeeID);
        }
        else if (e.CommandName == "DeleteEmployee")
        {
            DeleteEmployee(employeeID);
        }
    }

    // Load Employee Data for Editing
    private void LoadEmployeeForEdit(int employeeID)
    {
        try
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                string query = "SELECT * FROM Employees WHERE EmployeeID = @EmployeeID";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@EmployeeID", employeeID);
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {
                        txtEmployeeID.Text = dr["EmployeeID"].ToString();
                        txtEmployeeName.Text = dr["EmployeeName"].ToString();
                        txtPosition.Text = dr["Position"].ToString();
                        txtSalary.Text = dr["Salary"].ToString();
                        ddlStatus.SelectedValue = dr["Status"].ToString();
                    }
                }
            }
        }
        catch (Exception ex)
        {
            lblMessage.Text = "Error: " + ex.Message;
        }
    }

    // Delete Employee
    private void DeleteEmployee(int employeeID)
    {
        try
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                string query = "DELETE FROM Employees WHERE EmployeeID = @EmployeeID";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@EmployeeID", employeeID);
                    cmd.ExecuteNonQuery();
                }
            }
            lblMessage.Text = "Employee deleted successfully!";
            LoadEmployees();
        }
        catch (Exception ex)
        {
            lblMessage.Text = "Error: " + ex.Message;
        }
    }

    // Clear Input Fields
    private void ClearFields()
    {
        txtEmployeeID.Text = "";
        txtEmployeeName.Text = "";
        txtPosition.Text = "";
        txtSalary.Text = "";
        ddlStatus.SelectedIndex = 0;
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminDashboard.aspx");
    }
}
