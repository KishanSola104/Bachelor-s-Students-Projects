﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="BookRoom.aspx.cs" Inherits="BookRoom" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
 <title>Book a Room</title>

    <style>
        
        /* General Styles */
body {
    font-family: Arial, sans-serif;
    background-color: #f8f9fa;
    margin: 0;
    padding: 0;
}

/* Header Section */
.header {
    background-color: #007bff;
    color: white;
    padding: 15px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.header .welcome {
    font-size: 18px;
    font-weight: bold;
}

.nav {
    display: flex;
    gap: 20px;
}

.nav a {
    color: white;
    text-decoration: none;
    font-size: 16px;
    padding: 8px 15px;
    border-radius: 5px;
    transition: 0.3s;
}

.nav a:hover {
    background-color: #0056b3;
}

/* Main Content - Background Image */
.main-content {
    width: 100%;
    height: 85vh;
    background: url('Images/Hotel2.jpeg') no-repeat center center/cover;
    display: flex;
    justify-content: center;
    align-items: center;
    text-align: center;
    color: white;
    flex-direction: column;
    padding: 20px;
}

.main-content h2 {
    font-size: 36px;
    font-weight: bold;
    background: rgba(0, 0, 0, 0.6);
    padding: 10px 20px;
    border-radius: 8px;
}

.info-text {
    font-size: 18px;
    max-width: 800px;
    background: rgba(0, 0, 0, 0.6);
    padding: 15px;
    border-radius: 8px;
    line-height: 1.6;
    margin-top: 10px;
}

/* Container for Rooms */
.container {
    width: 80%;
    margin: auto;
    height:80vh;
    text-align: center;
}

h2 {
    color: #333;
    margin: 20px 0;
}

/* Room Cards */
.room-container {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 20px;
    margin-top: 20px;
}

.room-card {
    width: 300px;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 15px;
    background: white;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    text-align: center;
}

.room-card img {
    width: 100%;
    height: 200px;
    border-radius: 5px;
    object-fit: cover;
}

.room-card h3 {
    margin: 10px 0;
    color: #333;
}

.room-card p {
    color: #666;
    font-size: 14px;
}

/* Room Price */
.room-card .price {
    font-weight: bold;
    color: #28a745;
}

/* Book Now Button */
.room-card button {
    width: 100%;
    padding: 10px;
    margin-top: 10px;
    background: #007bff;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background 0.3s;
}

.room-card button:hover {
    background: #0056b3;
}

/* Footer Section */
.footer {
    background-color: #343a40;
    color: white;
    text-align: center;
    padding: 10px;
    position: relative;
    bottom: 0;
    width: 100%;
}

    </style>
</head>
<body>
    <form id="form1" runat="server">
        <!-- Header -->
        <div class="header">
            <div class="welcome">Welcome, <asp:Label ID="lblCustomerName" runat="server" Text="Guest"></asp:Label></div>
            <div class="nav">
                <a href="CustomerDashboard.aspx">Home</a>
                <a href="BookRoom.aspx">Book Room</a>
                
                <a href="Services.aspx">Services</a>
                <a href="CustomerLogin.aspx">Log Out</a>
            </div>
        </div>

       
           <div class="container">
            <h2>Available Rooms</h2>
            <asp:Label ID="lblMessage" runat="server" ForeColor="Red"></asp:Label>
            <div class="room-container">
            <asp:Repeater ID="rptRooms" runat="server">
    <ItemTemplate>
        <div class="room-card">
            <img src='<%# Eval("ImagePath") %>' alt="Room Image" class="room-image" />
            <h3><%# Eval("RoomType") %></h3>
            <p>Price Per Night: <%# Eval("PricePerNight") %></p>
             <p><b><%# Eval("ISAC") %></b></p>
            <p>Status: <%# Eval("Status") %></p>
            <p><%# Eval("Description") %></p>
            <asp:Button ID="btnBook" runat="server" Text="Book Now" CssClass="btn-book"
                CommandArgument='<%# Eval("RoomID") %>' OnClick="btnBook_Click" />
        </div>
    </ItemTemplate>
</asp:Repeater>

            </div>
        


        </div>

        <!-- Footer -->
        <div class="footer">
            &copy; 2025 CES Hotel. All Rights Reserved.
        </div>
    </form>
</body>
</html>