﻿using System;
using System.Configuration;
using System.Data.SqlClient;

public partial class SignUp : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lblMessage.Text = "";
    }

    protected void btnSignUp_Click(object sender, EventArgs e)
    {
        try
        {
            // Validate input fields
            if (string.IsNullOrWhiteSpace(txtFullName.Text) ||
                string.IsNullOrWhiteSpace(txtEmail.Text) ||
                string.IsNullOrWhiteSpace(txtMobile.Text) ||
                string.IsNullOrWhiteSpace(txtCity.Text) ||
                string.IsNullOrWhiteSpace(txtAddress.Text) ||
                string.IsNullOrWhiteSpace(txtPassword.Text) ||
                string.IsNullOrWhiteSpace(txtConfirmPassword.Text))
            {
                lblMessage.Text = "All fields are required.";
                return;
            }

            // Check if passwords match
            if (txtPassword.Text != txtConfirmPassword.Text)
            {
                lblMessage.Text = "Passwords do not match!";
                return;
            }

            // Database connection string from Web.config
            string connStr = ConfigurationManager.ConnectionStrings["CESHotelDB"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();

                // Check if email already exists
                string checkEmailQuery = "SELECT COUNT(*) FROM Customers WHERE Email = @Email";
                using (SqlCommand cmd = new SqlCommand(checkEmailQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                    int count = (int)cmd.ExecuteScalar();
                    if (count > 0)
                    {
                        lblMessage.Text = "Email already registered. Please use a different email.";
                        return;
                    }
                }

                // Insert customer data
                string insertQuery = "INSERT INTO Customers (FullName, Email, Mobile, City, Gender, Address, Password) " +
                                     "VALUES (@FullName, @Email, @Mobile, @City, @Gender, @Address, @Password)";
                using (SqlCommand cmd = new SqlCommand(insertQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@FullName", txtFullName.Text);
                    cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                    cmd.Parameters.AddWithValue("@Mobile", txtMobile.Text);
                    cmd.Parameters.AddWithValue("@City", txtCity.Text);
                    cmd.Parameters.AddWithValue("@Gender", ddlGen.SelectedValue);
                    cmd.Parameters.AddWithValue("@Address", txtAddress.Text);
                    cmd.Parameters.AddWithValue("@Password", txtPassword.Text); // Use hashing for security

                    int result = cmd.ExecuteNonQuery();
                    if (result > 0)
                    {
                        lblMessage.Text = "Registration successful! Redirecting to login...";
                        Response.Redirect("CustomerLogin.aspx");
                    }
                    else
                    {
                        lblMessage.Text = "Registration failed. Please try again.";
                    }
                }
            }
        }
        catch (SqlException sqlEx)
        {
            lblMessage.Text = "A database error occurred. Please try again later.";
            // Log sqlEx.Message for debugging
        }
        catch (Exception ex)
        {
            lblMessage.Text = "An unexpected error occurred. Please contact support.";
            // Log ex.Message for debugging
        }
    }
}
