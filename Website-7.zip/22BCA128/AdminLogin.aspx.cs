﻿using System;
using System.Data.SqlClient;
using System.Configuration;

public partial class AdminLogin : System.Web.UI.Page
{
    string connStr = ConfigurationManager.ConnectionStrings["CESHotelDB"].ConnectionString;

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        string username = txtUsername.Text.Trim();
        string password = txtPassword.Text.Trim();

        using (SqlConnection conn = new SqlConnection(connStr))
        {
            string query = "SELECT COUNT(*) FROM Admins WHERE Username = @Username AND Password = @Password";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@Username", username);
            cmd.Parameters.AddWithValue("@Password", password);

            conn.Open();
            int count = (int)cmd.ExecuteScalar();

            if (count > 0)
            {
                Session["AdminUsername"] = username;
                Response.Redirect("AdminDashboard.aspx"); // Redirect to Admin Dashboard
            }
            else
            {
                Response.Write("<script>alert('Invalid username or password!');</script>");
            }
        }
    }
}
