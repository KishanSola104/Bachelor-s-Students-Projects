﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="Services.aspx.cs" Inherits="Services" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Customer Dashboard</title>
    <style>
       /* General Styles */
body {
    font-family: Arial, sans-serif;
    background-color: #f8f9fa;
    margin: 0;
    padding: 0;
}

/* Header Section */
.header {
    background-color: #007bff;
    color: white;
    padding: 15px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.header .welcome {
    font-size: 18px;
    font-weight: bold;
}

.nav {
    display: flex;
    gap: 20px;
}

.nav a {
    color: white;
    text-decoration: none;
    font-size: 16px;
    padding: 8px 15px;
    border-radius: 5px;
    transition: 0.3s;
}

.nav a:hover {
    background-color: #0056b3;
}

/* Main Content */
.container {
    width: 80%;
    margin: auto;
    padding: 50px 0;
    text-align: center;
}

/* Service Sections */
.service {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin: 30px 0;
    padding: 20px;
    background: white;
    border-radius: 8px;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
}

.service img {
    width: 50%;
    height: 300px;
    object-fit: cover;
    border-radius: 8px;
}

.service-text {
    width: 45%;
    text-align: left;
}

.service-text h3 {
    font-size: 24px;
    color: #007bff;
    margin-bottom: 10px;
}

.service-text p {
    font-size: 16px;
    color: #555;
    line-height: 1.6;
}

/* Alternating Layout */
.service:nth-child(even) {
    flex-direction: row-reverse;
}

/* Footer */
.footer {
    background-color: #343a40;
    color: white;
    text-align: center;
    padding: 15px;
    margin-top: 50px;
}

    </style>
</head>
<body>
    <form id="form1" runat="server">
        <!-- Header -->
        <div class="header">
            <div class="welcome">Welcome, <asp:Label ID="lblCustomerName" runat="server" Text="Guest"></asp:Label></div>
            <div class="nav">
                <a href="CustomerDashboard.aspx">Home</a>
                <a href="BookRoom.aspx">Book Room</a>
                
                <a href="Services.aspx">Services</a>
                <a href="CustomerLogin.aspx">Log Out</a>
            </div>
        </div>

       <div class="container">
        <div class="service">
            <div class="service-text">
                <h3>Luxurious Rooms</h3>
                <p>Experience a comfortable and elegant stay in our well-furnished rooms equipped with modern amenities and breathtaking views.</p>
            </div>
            <img src="Images/sec1.jpg" alt="Luxury Room">
        </div>

        <div class="service">
            <img src="Images/sec2.jpg" alt="Gourmet Food">
            <div class="service-text">
                <h3>Gourmet Dining</h3>
                <p>Enjoy a fine dining experience with a wide variety of delicious dishes prepared by our expert chefs, catering to every taste.</p>
            </div>
        </div>

        <div class="service">
            <div class="service-text">
                <h3>Relaxing Spa & Wellness</h3>
                <p>Rejuvenate your senses with our luxurious spa treatments, fitness center, and wellness programs designed for relaxation.</p>
            </div>
            <img src="Images/sec3.webp" alt="Spa & Wellness">
        </div>

        <div class="service">
            <img src="Images/sec4.jpg" alt="Swimming Pool">
            <div class="service-text">
                <h3>Infinity Pool</h3>
                <p>Dive into our stunning infinity pool and enjoy a refreshing swim while admiring the panoramic views of the city.</p>
            </div>
        </div>

        <div class="service">
            <div class="service-text">
                <h3>24/7 Room Service</h3>
                <p>Need something at midnight? Our round-the-clock room service is always available to ensure your stay is convenient and enjoyable.</p>
            </div>
            <img src="Images/sec5.jpg" alt="Room Service">
        </div>
    </div>

        <!-- Footer -->
        <div class="footer">
            &copy; 2025 CES Hotel. All Rights Reserved.
        </div>
    </form>
</body>
</html>