﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="ConfirmBooking.aspx.cs" Inherits="ConfirmBooking" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>Confirm Booking</title>
     <style>
     /* General Styles */
body {
    font-family: Arial, sans-serif;
    background-color: #f8f9fa;
    margin: 0;
    padding: 0;
}

/* Header Section */
.header {
    background-color: #007bff;
    color: white;
    padding: 15px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.header .welcome {
    font-size: 18px;
    font-weight: bold;
}

.nav {
    display: flex;
    gap: 20px;
}

.nav a {
    color: white;
    text-decoration: none;
    font-size: 16px;
    padding: 8px 15px;
    border-radius: 5px;
    transition: 0.3s;
}

.nav a:hover {
    background-color: #0056b3;
}

/* Main Content */
.main-content {
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    text-align: center;
    height: 85vh;
}

.container {
    background: white;
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    max-width: 600px;
    width: 90%;
}

h2 {
    color: #007bff;
    font-size: 28px;
    margin-bottom: 15px;
}

p {
    font-size: 16px;
    margin: 8px 0;
}

/* Input Fields */
input[type="date"] {
    padding: 8px;
    width: 100%;
    margin-top: 5px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

/* Button Styling */
.btn {
    background-color: #007bff;
    color: white;
    border: none;
    padding: 10px 15px;
    font-size: 16px;
    border-radius: 5px;
    cursor: pointer;
    transition: 0.3s;
    margin-top: 15px;
}

.btn:hover {
    background-color: #0056b3;
}

/* Error Label */
#lblError {
    color: red;
    font-weight: bold;
    margin-top: 10px;
}

/* Footer */
.footer {
    background-color: #343a40;
    color: white;
    text-align: center;
    padding: 10px;
    width: 100%;
    position: relative;
    bottom: 0;
}

    </style>
</head>
<body>
    <form id="form1" runat="server">
        <!-- Header -->
        <div class="header">
            <div class="welcome">Welcome, <asp:Label ID="lblCustomerName" runat="server" Text="Guest"></asp:Label></div>
            <div class="nav">
                <a href="CustomerDashboard.aspx">Home</a>
                <a href="BookRoom.aspx">Book Room</a>
                
                <a href="Services.aspx">Services</a>
                <a href="CustomerLogin.aspx">Log Out</a>
            </div>
        </div>

        <!-- Full-Screen Background Image -->
        <div class="main-content">
         <div class="container">
            <h2>Confirm Your Booking</h2>
            <asp:Label ID="lblError" runat="server" ForeColor="Red"></asp:Label>
            <p><strong>Room Type:</strong> <asp:Label ID="lblRoomType" runat="server"></asp:Label></p>
            <p><strong>Price Per Night:</strong> $<asp:Label ID="lblPrice" runat="server"></asp:Label></p>
            <p><strong>Status:</strong> <asp:Label ID="lblStatus" runat="server"></asp:Label></p>
            <p><strong>Check-in Date:</strong> <asp:TextBox ID="txtCheckIn" runat="server" TextMode="Date" required></asp:TextBox></p>
            <p><strong>Check-out Date:</strong> <asp:TextBox ID="txtCheckOut" runat="server" TextMode="Date" required></asp:TextBox></p>
            <p>
                <asp:Button ID="btnConfirm" runat="server" CssClass="btn" Text="Confirm & Proceed to Payment" OnClick="btnConfirm_Click" />
            </p>
        </div>
         </div>

        <!-- Footer -->
        <div class="footer">
            &copy; 2025 CES Hotel. All Rights Reserved.
        </div>
    </form>
</body>
</html>