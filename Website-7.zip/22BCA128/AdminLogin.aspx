﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="AdminLogin.aspx.cs" Inherits="AdminLogin" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>Admin Login - CES Hotel</title>
    <style>
        body { margin: 0; font-family: Arial, sans-serif; background-color: #ECF0F1; }

        /* Centered Login Form */
        .login-container {
            width: 350px; background: white; padding: 20px; 
            position: absolute; top: 50%; left: 50%; 
            transform: translate(-50%, -50%);
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2); border-radius: 10px;
        }
        
        h2 { text-align: center; color: #2C3E50; }
        .input-group { margin-bottom: 15px; }
        label { font-weight: bold; }
        input[type="text"], input[type="password"] {
            width: 100%; padding: 10px; margin-top: 5px; 
            border: 1px solid #BDC3C7; border-radius: 5px;
        }
        .btn-login {
            width: 100%; background: #2C3E50; color: white; 
            padding: 10px; border: none; border-radius: 5px; 
            cursor: pointer; font-size: 16px;
        }
        .btn-login:hover { background: #34495E; }

        /* Back to Home */
        .back-home {
            text-align: center; margin-top: 10px;
        }
        .back-home a {
            text-decoration: none; color: #2980B9; font-weight: bold;
        }
        .back-home a:hover { color: #1A5276; }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="login-container">
            <h2>Admin Login</h2>
            <div class="input-group">
                <label>Username:</label>
                <asp:TextBox ID="txtUsername" runat="server"></asp:TextBox>
            </div>
            <div class="input-group">
                <label>Password:</label>
                <asp:TextBox ID="txtPassword" runat="server" TextMode="Password"></asp:TextBox>
            </div>
            <asp:Button ID="btnLogin" runat="server" Text="Login" CssClass="btn-login" OnClick="btnLogin_Click" />
            <div class="back-home">
                <a href="Index.aspx"> Back to Home</a>
            </div>
        </div>
    </form>
</body>
</html>