﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="Payment.aspx.cs" Inherits="Payment" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <style>
      /* General Styles */
body {
    font-family: Arial, sans-serif;
    background-color: #f8f9fa;
    margin: 0;
    padding: 0;
}

/* Header Section */
.header {
    background-color: #007bff;
    color: white;
    padding: 15px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.header .welcome {
    font-size: 18px;
    font-weight: bold;
}

.nav {
    display: flex;
    gap: 20px;
}

.nav a {
    color: white;
    text-decoration: none;
    font-size: 16px;
    padding: 8px 15px;
    border-radius: 5px;
    transition: 0.3s;
}

.nav a:hover {
    background-color: #0056b3;
}

/* Main Content */
.main-content {
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    text-align: center;
    height: 85vh;
}

.container {
    background: white;
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    max-width: 600px;
    width: 90%;
}

h2 {
    color: #007bff;
    font-size: 28px;
    margin-bottom: 15px;
}

/* Payment Details Section */
.payment-details {
    text-align: left;
    margin-bottom: 20px;
}

.payment-details p {
    font-size: 16px;
    margin: 8px 0;
}

/* Dropdown Styling */
select {
    width: 100%;
    padding: 8px;
    font-size: 16px;
    border: 1px solid #ccc;
    border-radius: 5px;
    margin-top: 5px;
}

/* Button Styling */
.btn {
    background-color: #007bff;
    color: white;
    border: none;
    padding: 10px 15px;
    font-size: 16px;
    border-radius: 5px;
    cursor: pointer;
    transition: 0.3s;
    margin-top: 15px;
}

.btn:hover {
    background-color: #0056b3;
}

/* Error Label */
#lblMessage {
    color: red;
    font-weight: bold;
    margin-top: 10px;
}

/* Footer */
.footer {
    background-color: #343a40;
    color: white;
    text-align: center;
    padding: 10px;
    width: 100%;
    position: relative;
    bottom: 0;
}

    </style>
</head>
<body>
    <form id="form1" runat="server">
        <!-- Header -->
        <div class="header">
            <div class="welcome">Welcome, <asp:Label ID="lblCustomerName" runat="server" Text="Guest"></asp:Label></div>
            <div class="nav">
                <a href="CustomerDashboard.aspx">Home</a>
                <a href="BookRoom.aspx">Book Room</a>
                
                <a href="Services.aspx">Services</a>
                <a href="CustomerLogin.aspx">Log Out</a>
            </div>
        </div>

        <!-- Full-Screen Background Image -->
        <div class="main-content">
           <h2>Payment Details</h2>
        <asp:Label ID="lblRoomDetails" runat="server" Text="Room Details"></asp:Label><br />
        <asp:Label ID="lblAmount" runat="server" Text="Amount: "></asp:Label><br />
        <asp:HiddenField ID="hfAmount" runat="server" />
        <asp:DropDownList ID="ddlPaymentMethod" runat="server">
            <asp:ListItem Text="Credit Card" Value="Credit Card"></asp:ListItem>
            <asp:ListItem Text="Debit Card" Value="Debit Card"></asp:ListItem>
            <asp:ListItem Text="UPI" Value="UPI"></asp:ListItem>
        </asp:DropDownList><br />
        <asp:Button ID="btnPay" runat="server" Text="Pay Now" OnClick="btnPay_Click" />
        <asp:Label ID="lblMessage" runat="server" ForeColor="Red"></asp:Label>
        </div>

        <!-- Footer -->
        <div class="footer">
            &copy; 2025 CES Hotel. All Rights Reserved.
        </div>
    </form>
</body>
</html>
