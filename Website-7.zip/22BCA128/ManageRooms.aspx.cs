﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ManageRooms : System.Web.UI.Page
{
    string connStr = ConfigurationManager.ConnectionStrings["CESHotelDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadRooms();
        }
    }

    // Load all rooms into GridView
    private void LoadRooms()
    {
        try
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string query = "SELECT * FROM Rooms";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    gvRooms.DataSource = dt;
                    gvRooms.DataBind();
                }
            }
        }
        catch (Exception ex)
        {
            lblMessage.Text = "Error loading rooms: " + ex.Message;
        }
    }

    // Add a new room
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(txtRoomID.Text) || string.IsNullOrWhiteSpace(txtPrice.Text) || string.IsNullOrWhiteSpace(txtDescription.Text))
            {
                lblMessage.Text = "All fields are required!";
                return;
            }

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string query = "INSERT INTO Rooms (RoomID, RoomType, ISAC , PricePerNight, Status, Description) VALUES (@RoomID, @RoomType,@ISAC,  @PricePerNight, @Status, @Description)";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@RoomID", txtRoomID.Text.Trim());
                    cmd.Parameters.AddWithValue("@RoomType", ddlRoomType.SelectedValue);
                    cmd.Parameters.AddWithValue("@ISAC",ddlAC.SelectedValue);
                    cmd.Parameters.AddWithValue("@PricePerNight", Convert.ToDecimal(txtPrice.Text.Trim()));
                    cmd.Parameters.AddWithValue("@Status", ddlStatus.SelectedValue);
                    cmd.Parameters.AddWithValue("@Description", txtDescription.Text.Trim());

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }

            lblMessage.Text = "Room added successfully!";
            ClearFields();
            LoadRooms();
        }
        catch (Exception ex)
        {
            lblMessage.Text = "Error adding room: " + ex.Message;
        }
    }

    // Handle Edit & Delete actions in GridView
    protected void gvRooms_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (e.CommandName == "EditRoom")
            {
                string roomID = e.CommandArgument.ToString();
                LoadRoomDetails(roomID);
            }
            else if (e.CommandName == "DeleteRoom")
            {
                string roomID = e.CommandArgument.ToString();
                DeleteRoom(roomID);
            }
        }
        catch (Exception ex)
        {
            lblMessage.Text = "Error processing command: " + ex.Message;
        }
    }

    // Load selected room details into input fields for editing
    private void LoadRoomDetails(string roomID)
    {
        try
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string query = "SELECT * FROM Rooms WHERE RoomID = @RoomID";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@RoomID", roomID);
                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        txtRoomID.Text = reader["RoomID"].ToString();
                        ddlRoomType.SelectedValue = reader["RoomType"].ToString();
                        ddlAC.SelectedValue=reader["ISAC"].ToString();
                        txtPrice.Text = reader["PricePerNight"].ToString();
                        ddlStatus.SelectedValue = reader["Status"].ToString();
                        txtDescription.Text = reader["Description"].ToString();

                        txtRoomID.Enabled = false; // Prevent changing RoomID
                    }
                }
            }
        }
        catch (Exception ex)
        {
            lblMessage.Text = "Error loading room details: " + ex.Message;
        }
    }

    // Delete room
    private void DeleteRoom(string roomID)
    {
        try
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string query = "DELETE FROM Rooms WHERE RoomID = @RoomID";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@RoomID", roomID);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }

            lblMessage.Text = "Room deleted successfully!";
            LoadRooms();
        }
        catch (Exception ex)
        {
            lblMessage.Text = "Error deleting room: " + ex.Message;
        }
    }

    // Clear input fields
    private void ClearFields()
    {
        txtRoomID.Text = "";
        ddlRoomType.SelectedIndex = 0;
        txtPrice.Text = "";
        ddlStatus.SelectedIndex = 0;
        ddlAC.SelectedIndex = 0;
        txtDescription.Text = "";
        txtRoomID.Enabled = true;
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminDashboard.aspx");
    }
}
