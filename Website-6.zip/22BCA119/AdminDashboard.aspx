﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="AdminDashboard.aspx.cs" Inherits="AdminDashboard" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>Admin Dashboard - DNICA College</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 0; background: #f4f4f4; }
        .header { background: #003366; color: white; padding: 15px; display: flex; justify-content: space-between; align-items: center; }
        .header h2 { margin: 0; }
        .nav { background: #0055a4; padding: 10px; }
        .nav a { color: white; margin: 0 15px; text-decoration: none; font-weight: bold; }
        .nav a:hover { text-decoration: underline; }
        .dashboard { padding: 20px; text-align: center; }
        .card { display: inline-block; background: white; padding: 20px; margin: 10px; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2); width: 200px; }
        .footer { background: #003366; color: white; text-align: center; padding: 10px; position: absolute; bottom: 0; width: 100%; }
    </style>
</head>
<body>
<form runat="server">
    <div class="header">
        <h2>Admin Dashboard - DNICA College</h2>
        <asp:Label ID="lblAdminName" runat="server" ForeColor="White"></asp:Label>
        <asp:Button ID="btnLogout" runat="server" Text="Logout" OnClick="btnLogout_Click" />
    </div>
    <div class="nav">
        <a href="ManageStaff.aspx">Manage Staff</a>
        <a href="ManageStudents.aspx">Manage Students</a>
    </div>
    <div class="dashboard">
        <div class="card">
            <h3>Total Staff</h3>
            <asp:Label ID="lblTotalStaff" runat="server"></asp:Label>
        </div>
        <div class="card">
            <h3>Total Students</h3>
            <asp:Label ID="lblTotalStudents" runat="server"></asp:Label>
        </div>
       
    </div>
    <div class="footer">
        <p>Contact: +91 9876543210 | Email: info@dnica.edu | Address: DNICA College, City, Country</p>
    </div>
    </form>
</body>
</html>
