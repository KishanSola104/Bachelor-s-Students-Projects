﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.UI;

public partial class StudentDashboard : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["StudentID"] == null)
        {
            Response.Redirect("StudentLogin.aspx");  // Redirect to login if session is null
        }
        else
        {
            string studentID = Session["StudentID"].ToString();
            FetchStudentName(studentID);
        }
    }

    private void FetchStudentName(string studentID)
    {
        string connectionString = ConfigurationManager.ConnectionStrings["CollegeAttendanceDB"].ConnectionString;

        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            string query = "SELECT FullName FROM Students WHERE StudentID = @StudentID";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@StudentID", studentID);
                conn.Open();
                object result = cmd.ExecuteScalar();
                conn.Close();

                if (result != null)
                {
                    lblStudentName.Text = result.ToString();  // Display Student Name
                }
            }
        }
    }
}
