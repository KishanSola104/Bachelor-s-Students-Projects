﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="ViewMonthlyAttendance.aspx.cs" Inherits="ViewMonthlyAttendance" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
   <title>Monthly Attendance Report</title>
  <style>
        /* General Page Styling */
body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

/* Header */
.header {
    background-color: #007BFF;
    color: white;
    padding: 15px;
    text-align: center;
    font-size: 20px;
}

/* Navigation Bar */
.nav {
    display: flex;
    justify-content: center;
    background: #0056b3;
    padding: 10px;
}

.nav a {
    color: white;
    padding: 10px 20px;
    text-decoration: none;
    font-weight: bold;
}

.nav a:hover {
    background: #003f7f;
    border-radius: 5px;
}

/* Container */
.container {
    text-align: center;
    margin: 20px auto;
    width: 80%;
    background: white;
    padding: 20px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}

/* Headings */
h2, h3 {
    color: #333;
}

/* Labels */
label {
    font-size: 16px;
    font-weight: bold;
    color: #333;
    display: block;
    margin: 10px 0 5px;
}

/* Form Controls */
input[type="month"],
select {
    padding: 10px;
    width: 250px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 16px;
    text-align: center;
}

/* Buttons */
.btn, input[type="submit"], input[type="button"] {
    display: inline-block;
    padding: 10px 20px;
    background: #007BFF;
    color: white;
    text-decoration: none;
    border-radius: 5px;
    font-size: 16px;
    margin-top: 10px;
    border: none;
    cursor: pointer;
}

.btn:hover, input[type="submit"]:hover, input[type="button"]:hover {
    background: #0056b3;
}

/* GridView Styling */
.grid-container {
    width: 100%;
    margin-top: 20px;
}

.grid-container table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

.grid-container th,
.grid-container td {
    padding: 10px;
    border: 1px solid #ddd;
    text-align: center;
}

.grid-container th {
    background: #007BFF;
    color: white;
}

.grid-container tr:nth-child(even) {
    background: #f2f2f2;
}

.grid-container tr:hover {
    background: #ddd;
}

/* Message Labels */
.message {
    color: red;
    font-size: 16px;
    margin-top: 10px;
}

/* Divider */
hr {
    margin: 30px 0;
    border: 1px solid #ddd;
}

    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="header">
            Welcome, <asp:Label ID="lblStaffName" runat="server" Text="Staff"></asp:Label>
        </div>

        <div class="nav">
            <a href="StaffDashboard.aspx">Home</a>
            <a href="MarkAttendance.aspx">Mark Attendance</a>
            <a href="ViewAttendance.aspx">View Attendance</a>
             <a href="ManageStudentsAttendance.aspx">Manage Students Attendance</a>
             <a href="ViewStudentsAttendance.aspx">View Students Attendance</a>
                <a href="ViewMonthlyAttendance.aspx">View Monthly Attendance</a>
            <a href="StaffProfile.aspx">Profile</a>
            <a href="StaffLogin.aspx">Log Out</a>
        </div>

        <div class="container">
             <h2>Monthly Attendance Report</h2>

        <!-- Student Monthly Attendance -->
        <h3>View Individual Student Attendance</h3>
        <label>Select Student:</label>
        <asp:DropDownList ID="ddlStudent" runat="server"></asp:DropDownList>

        <label>Select Month:</label>
        <asp:TextBox ID="txtMonthStudent" runat="server" TextMode="Month"></asp:TextBox>

        <asp:Button ID="btnViewStudentAttendance" runat="server" Text="View Student Attendance"
            OnClick="btnViewStudentAttendance_Click" />

        <asp:Label ID="lblStudentMessage" runat="server" ForeColor="Red"></asp:Label>

        <asp:GridView ID="gvStudentAttendance" runat="server" AutoGenerateColumns="true"></asp:GridView>

        <hr />

        <!-- Educational Year Monthly Attendance -->
        <h3>View Educational Year Attendance</h3>
        <label>Select Educational Year:</label>
        <asp:DropDownList ID="ddlEduYear" runat="server"></asp:DropDownList>

        <label>Select Month:</label>
        <asp:TextBox ID="txtMonthEduYear" runat="server" TextMode="Month"></asp:TextBox>

        <asp:Button ID="btnViewEduYearAttendance" runat="server" Text="View Educational Year Attendance"
            OnClick="btnViewEduYearAttendance_Click" />

        <asp:Label ID="lblEduYearMessage" runat="server" ForeColor="Red"></asp:Label>

        <asp:GridView ID="gvEduYearAttendance" runat="server" AutoGenerateColumns="true"></asp:GridView>
        </div>
    </form>
</body>
</html>