﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI.WebControls;

public partial class ViewMonthlyAttendance : System.Web.UI.Page
{
    private readonly string connectionString = ConfigurationManager.ConnectionStrings["CollegeAttendanceDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadStudents();
            LoadEducationalYears();
        }
    }

    private void LoadStudents()
    {
        try
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT DISTINCT StudentID FROM Students";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    ddlStudent.DataSource = reader;
                
                    ddlStudent.DataValueField = "StudentID";
                    ddlStudent.DataBind();
                    ddlStudent.Items.Insert(0, new ListItem("-- Select Student --", ""));
                }
            }
        }
        catch (Exception ex)
        {
            lblStudentMessage.Text = "Error loading students: " + ex.Message;
        }
    }

    private void LoadEducationalYears()
    {
        try
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT DISTINCT EducationalYear FROM Students";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    ddlEduYear.DataSource = reader;
                    ddlEduYear.DataTextField = "EducationalYear";
                    ddlEduYear.DataValueField = "EducationalYear";
                    ddlEduYear.DataBind();
                    ddlEduYear.Items.Insert(0, new ListItem("-- Select Educational Year --", ""));
                }
            }
        }
        catch (Exception ex)
        {
            lblEduYearMessage.Text = "Error loading educational years: " + ex.Message;
        }
    }

    protected void btnViewStudentAttendance_Click(object sender, EventArgs e)
    {
        if (ddlStudent.SelectedValue == "" || string.IsNullOrEmpty(txtMonthStudent.Text))
        {
            lblStudentMessage.Text = "Please select a student and month.";
            return;
        }

        string studentID = ddlStudent.SelectedValue;
        string month = txtMonthStudent.Text + "-01"; // Convert input to YYYY-MM-01 format

        using (SqlConnection con = new SqlConnection(connectionString))
        {
            string query = "SELECT StudentID,  Date, Status FROM Attendance " +
                           "WHERE StudentID = @StudentID AND DATEPART(YEAR, Date) = YEAR(@Month) " +
                           "AND DATEPART(MONTH, Date) = MONTH(@Month)";

            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                cmd.Parameters.AddWithValue("@StudentID", studentID);
                cmd.Parameters.AddWithValue("@Month", month);

                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                gvStudentAttendance.DataSource = dt;
                gvStudentAttendance.DataBind();
                lblStudentMessage.Text = dt.Rows.Count > 0 ? "" : "No records found.";
            }
        }
    }

    protected void btnViewEduYearAttendance_Click(object sender, EventArgs e)
    {
        if (ddlEduYear.SelectedValue == "" || string.IsNullOrEmpty(txtMonthEduYear.Text))
        {
            lblEduYearMessage.Text = "Please select an educational year and month.";
            return;
        }

        string educationalYear = ddlEduYear.SelectedValue;
        string month = txtMonthEduYear.Text + "-01"; // Convert input to YYYY-MM-01 format

        using (SqlConnection con = new SqlConnection(connectionString))
        {
            string query = "SELECT StudentID,  Date, Status FROM Attendance " +
                           "WHERE EducationalYear = @EducationalYear AND DATEPART(YEAR, Date) = YEAR(@Month) " +
                           "AND DATEPART(MONTH, Date) = MONTH(@Month)";

            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                cmd.Parameters.AddWithValue("@EducationalYear", educationalYear);
                cmd.Parameters.AddWithValue("@Month", month);

                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                gvEduYearAttendance.DataSource = dt;
                gvEduYearAttendance.DataBind();
                lblEduYearMessage.Text = dt.Rows.Count > 0 ? "" : "No records found.";
            }
        }
    }
}
