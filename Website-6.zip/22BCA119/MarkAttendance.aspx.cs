﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class MarkAttendance : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["StaffEmail"] == null)
        {
            Response.Redirect("StaffLogin.aspx");
        }
        else
        {
            lblDate.Text = DateTime.Now.ToString("yyyy-MM-dd");
        }
    }


    protected void btnMarkAttendance_Click(object sender, EventArgs e)
    {
        string staffEmail = Session["StaffEmail"].ToString();
        string connectionString = ConfigurationManager.ConnectionStrings["CollegeAttendanceDB"].ConnectionString;

        using (SqlConnection con = new SqlConnection(connectionString))
        {
            // Get StaffID from Staff table
            string getStaffIdQuery = "SELECT StaffID FROM Staff WHERE Email = @Email";
            SqlCommand cmdGetStaffId = new SqlCommand(getStaffIdQuery, con);
            cmdGetStaffId.Parameters.AddWithValue("@Email", staffEmail);

            con.Open();
            object staffIdObj = cmdGetStaffId.ExecuteScalar();
            con.Close();

            if (staffIdObj != null)
            {
                int staffId = Convert.ToInt32(staffIdObj);
                DateTime today = DateTime.Today;

                // Check if attendance is already marked for today
                string checkAttendanceQuery = "SELECT COUNT(*) FROM StaffAttendance WHERE StaffID = @StaffID AND Date = @Date";
                SqlCommand cmdCheckAttendance = new SqlCommand(checkAttendanceQuery, con);
                cmdCheckAttendance.Parameters.AddWithValue("@StaffID", staffId);
                cmdCheckAttendance.Parameters.AddWithValue("@Date", today);

                con.Open();
                int count = Convert.ToInt32(cmdCheckAttendance.ExecuteScalar());
                con.Close();

                if (count == 0)
                {
                    // Get new AttendanceID (MAX + 1)
                    string getMaxIDQuery = "SELECT ISNULL(MAX(AttendanceID), 0) + 1 FROM StaffAttendance";
                    SqlCommand cmdGetMaxID = new SqlCommand(getMaxIDQuery, con);

                    con.Open();
                    int newAttendanceID = Convert.ToInt32(cmdGetMaxID.ExecuteScalar());
                    con.Close();

                    // Insert new attendance record
                    string insertQuery = "INSERT INTO StaffAttendance (AttendanceID, StaffID, Date, Status) VALUES (@AttendanceID, @StaffID, @Date, 'Present')";
                    SqlCommand cmdInsert = new SqlCommand(insertQuery, con);
                    cmdInsert.Parameters.AddWithValue("@AttendanceID", newAttendanceID);
                    cmdInsert.Parameters.AddWithValue("@StaffID", staffId);
                    cmdInsert.Parameters.AddWithValue("@Date", today);

                    con.Open();
                    cmdInsert.ExecuteNonQuery();
                    con.Close();

                    lblMessage.Text = "Attendance marked successfully.";
                    lblMessage.ForeColor = System.Drawing.Color.Green;
                }
                else
                {
                    lblMessage.Text = "Attendance already marked for today.";
                    lblMessage.ForeColor = System.Drawing.Color.Red;
                }
            }
            else
            {
                lblMessage.Text = "Staff record not found.";
                lblMessage.ForeColor = System.Drawing.Color.Red;
            }
        }
    }

}
