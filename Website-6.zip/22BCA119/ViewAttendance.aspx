﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="ViewAttendance.aspx.cs" Inherits="ViewAttendance" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>Staff Dashboard View Attend</title>
    <style>
         body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 0;
    }

    .header {
        background-color: #007BFF;
        color: white;
        padding: 15px;
        text-align: center;
        font-size: 22px;
        font-weight: bold;
    }

    .nav {
        display: flex;
        justify-content: center;
        background: #0056b3;
        padding: 12px;
        flex-wrap: wrap;
    }

    .nav a {
        color: white;
        padding: 12px 18px;
        text-decoration: none;
        font-weight: bold;
        transition: 0.3s;
    }

    .nav a:hover {
        background: #003f7f;
        border-radius: 5px;
    }

    .container {
        max-width: 800px;
        margin: 30px auto;
        background: white;
        padding: 25px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        border-radius: 8px;
        text-align: center;
    }

    h2 {
        color: #333;
        margin-bottom: 20px;
    }

    label {
        font-size: 16px;
        font-weight: bold;
        margin-right: 5px;
    }

    input[type="date"] {
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-size: 14px;
        width: 150px;
        margin-right: 10px;
    }

    .btn {
        display: inline-block;
        padding: 10px 20px;
        background: #007BFF;
        color: white;
        text-decoration: none;
        border-radius: 5px;
        font-size: 16px;
        margin-top: 10px;
        cursor: pointer;
        border: none;
    }

    .btn:hover {
        background: #0056b3;
    }

    .grid-container {
        margin-top: 20px;
        overflow-x: auto;
    }

    .grid-container table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 10px;
    }

    .grid-container th, .grid-container td {
        border: 1px solid #ddd;
        padding: 10px;
        text-align: center;
    }

    .grid-container th {
        background-color: #007BFF;
        color: white;
    }

    .grid-container tr:nth-child(even) {
        background-color: #f9f9f9;
    }

    .grid-container tr:hover {
        background-color: #f1f1f1;
    }

    .message {
        margin-top: 10px;
        font-weight: bold;
        color: red;
    }

    @media (max-width: 768px) {
        .container {
            width: 95%;
            padding: 15px;
        }

        .nav {
            flex-direction: column;
            align-items: center;
        }

        .nav a {
            width: 100%;
            text-align: center;
            padding: 10px;
        }

        input[type="date"] {
            width: 100%;
            margin: 5px 0;
        }

        .btn {
            width: 100%;
        }
    }

    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="header">
            Welcome, <asp:Label ID="lblStaffName" runat="server" Text="Staff"></asp:Label>
        </div>

        <div class="nav">
            <a href="StaffDashboard.aspx">Home</a>
            <a href="MarkAttendance.aspx">Mark Attendance</a>
            <a href="ViewAttendance.aspx">View Attendance</a>
             <a href="ManageStudentsAttendance.aspx">Manage Students Attendance</a>
             <a href="ViewStudentsAttendance.aspx">View Students Attendance</a>
                <a href="ViewMonthlyAttendance.aspx">View Monthly Attendance</a>
            <a href="StaffProfile.aspx">Profile</a>
            <a href="StaffLogin.aspx">Log Out</a>
        </div>

        <div class="container">
          <h2>My Attendance</h2>

        <label>From:</label>
        <asp:TextBox ID="txtFromDate" runat="server" TextMode="Date"></asp:TextBox>

        <label>To:</label>
        <asp:TextBox ID="txtToDate" runat="server" TextMode="Date"></asp:TextBox>

        <asp:Button ID="btnFilter" runat="server" Text="Filter" CssClass="btn" OnClick="btnFilter_Click" />
        <br /><br />

        <asp:GridView ID="gvAttendance" runat="server" AutoGenerateColumns="False" BorderWidth="1px">
            <Columns>
                <asp:BoundField DataField="Date" HeaderText="Date" DataFormatString="{0:yyyy-MM-dd}" />
                <asp:BoundField DataField="Status" HeaderText="Status" />
            </Columns>
        </asp:GridView>

        <br />
        <asp:Label ID="lblMessage" runat="server" ForeColor="Red"></asp:Label>
        </div>

    </form>
</body>
</html>