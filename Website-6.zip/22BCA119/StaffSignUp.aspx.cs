﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.UI;

public partial class StaffSignUp : Page
{
    private readonly string connectionString = ConfigurationManager.ConnectionStrings["CollegeAttendanceDB"].ConnectionString;

    protected void btnSignUp_Click(object sender, EventArgs e)
    {
        string staffID = txtStaffID.Text.Trim();
        string email = txtEmail.Text.Trim();
        string password = txtPassword.Text.Trim();

        if (string.IsNullOrEmpty(staffID) || string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
        {
            lblMessage.Text = "All fields are required!";
            return;
        }

        using (SqlConnection con = new SqlConnection(connectionString))
        {
            con.Open();

            // Check if Staff ID exists in the Staff table
            string checkQuery = "SELECT COUNT(*) FROM Staff WHERE StaffID = @StaffID";
            using (SqlCommand checkCmd = new SqlCommand(checkQuery, con))
            {
                checkCmd.Parameters.AddWithValue("@StaffID", staffID);
                int count = Convert.ToInt32(checkCmd.ExecuteScalar());

                if (count == 0)
                {
                    lblMessage.Text = "Staff ID not found. Please enter a valid Staff ID.";
                    return;
                }
            }

            // Insert into StaffLogin table
            string insertQuery = "INSERT INTO StaffLogin (StaffID, Email, Password) VALUES (@StaffID, @Email, @Password)";
            using (SqlCommand insertCmd = new SqlCommand(insertQuery, con))
            {
                insertCmd.Parameters.AddWithValue("@StaffID", staffID);
                insertCmd.Parameters.AddWithValue("@Email", email);
                insertCmd.Parameters.AddWithValue("@Password", password);

                insertCmd.ExecuteNonQuery();
                lblMessage.ForeColor = System.Drawing.Color.Green;
                lblMessage.Text = "Staff registration successful! Redirecting to login...";

                Response.Redirect("StaffLogin.aspx");
            }
        }
    }
}
