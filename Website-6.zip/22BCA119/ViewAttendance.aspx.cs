﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;

public partial class ViewAttendance : Page
{
    private readonly string connectionString = ConfigurationManager.ConnectionStrings["CollegeAttendanceDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadAttendanceData();
        }
    }

    private void LoadAttendanceData(string fromDate = "", string toDate = "")
    {
        string staffEmail = "";
        if (Session["StaffEmail"] != null)
        {
            staffEmail = Session["StaffEmail"].ToString();
        }

        if (string.IsNullOrEmpty(staffEmail))
        {
            lblMessage.Text = "Session expired. Please log in again.";
            return;
        }

        using (SqlConnection con = new SqlConnection(connectionString))
        {
            // Get StaffID from Staff table
            string getStaffIdQuery = "SELECT StaffID FROM Staff WHERE Email = @Email";
            SqlCommand cmdGetStaffId = new SqlCommand(getStaffIdQuery, con);
            cmdGetStaffId.Parameters.AddWithValue("@Email", staffEmail);

            con.Open();
            object staffIdObj = cmdGetStaffId.ExecuteScalar();
            con.Close();

            if (staffIdObj != null)
            {
                int staffId = Convert.ToInt32(staffIdObj);

                // Get attendance records for the staff member
                string query = "SELECT Date, Status FROM StaffAttendance WHERE StaffID = @StaffID";

                if (!string.IsNullOrEmpty(fromDate) && !string.IsNullOrEmpty(toDate))
                {
                    query += " AND Date BETWEEN @FromDate AND @ToDate";
                }

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@StaffID", staffId);

                if (!string.IsNullOrEmpty(fromDate) && !string.IsNullOrEmpty(toDate))
                {
                    cmd.Parameters.AddWithValue("@FromDate", fromDate);
                    cmd.Parameters.AddWithValue("@ToDate", toDate);
                }

                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                gvAttendance.DataSource = dt;
                gvAttendance.DataBind();

                if (dt.Rows.Count == 0)
                {
                    lblMessage.Text = "No attendance records found.";
                }
                else
                {
                    lblMessage.Text = "";
                }
            }
            else
            {
                lblMessage.Text = "Staff record not found.";
            }
        }
    }

    protected void btnFilter_Click(object sender, EventArgs e)
    {
        LoadAttendanceData(txtFromDate.Text, txtToDate.Text);
    }
}
