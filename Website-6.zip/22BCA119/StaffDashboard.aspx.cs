﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class StaffDashboard : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["StaffEmail"] == null)
        {
            Response.Redirect("StaffLogin.aspx");
        }
        else
        {
            LoadStaffName();
        }
    }

    private void LoadStaffName()
    {
        string staffEmail = Session["StaffEmail"].ToString();
        string connectionString = ConfigurationManager.ConnectionStrings["CollegeAttendanceDB"].ConnectionString;

        using (SqlConnection con = new SqlConnection(connectionString))
        {
            string query = "SELECT FullName FROM Staff WHERE Email = @Email";
            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                cmd.Parameters.AddWithValue("@Email", staffEmail);
                con.Open();
                object result = cmd.ExecuteScalar();
                if (result != null)
                {
                    lblStaffName.Text = result.ToString();
                }
            }
        }
    }
}
