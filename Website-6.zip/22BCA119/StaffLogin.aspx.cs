﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.UI;

public partial class StaffLogin : Page
{
    private readonly string connectionString = ConfigurationManager.ConnectionStrings["CollegeAttendanceDB"].ConnectionString;

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        try
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT COUNT(1) FROM StaffLogin WHERE Email=@Email AND Password=@Password";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                    cmd.Parameters.AddWithValue("@Password", txtPassword.Text);

                    con.Open();
                    int count = Convert.ToInt32(cmd.ExecuteScalar());

                    if (count == 1)
                    {
                        Session["StaffEmail"] = txtEmail.Text;
                        Response.Redirect("StaffDashboard.aspx");
                    }
                    else
                    {
                        lblMessage.Text = "Invalid Email or Password!";
                    }
                }
            }
        }
        catch (Exception ex)
        {
            lblMessage.Text = "Error: " + ex.Message;
        }
    }
}
