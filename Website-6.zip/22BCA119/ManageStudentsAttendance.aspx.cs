﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI.WebControls;

public partial class ManageStudentsAttendance : System.Web.UI.Page
{
    private readonly string connectionString = ConfigurationManager.ConnectionStrings["CollegeAttendanceDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadEducationalYears();
        }

        if (Session["StaffEmail"] == null)
        {
            Response.Redirect("StaffLogin.aspx");
        }
       
    }

    private void LoadEducationalYears()
    {
        try
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT DISTINCT EducationalYear FROM Students";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    ddlClass.DataSource = reader;
                    ddlClass.DataTextField = "EducationalYear";
                    ddlClass.DataValueField = "EducationalYear";
                    ddlClass.DataBind();
                    ddlClass.Items.Insert(0, new ListItem("-- Select Educational Year --", ""));
                }
            }
        }
        catch (Exception ex)
        {
            lblMessage.Text = "Error loading Educational Years: " + ex.Message;
        }
    }

    protected void btnLoadStudents_Click(object sender, EventArgs e)
    {
        try
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT StudentID, FullName FROM Students WHERE EducationalYear = @EducationalYear";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@EducationalYear", ddlClass.SelectedValue);
                    con.Open();
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    gvStudents.DataSource = dt;
                    gvStudents.DataBind();
                }
            }
        }
        catch (Exception ex)
        {
            lblMessage.Text = "Error loading students: " + ex.Message;
        }
    }

    protected void btnSubmitAttendance_Click(object sender, EventArgs e)
    {
        try
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                foreach (GridViewRow row in gvStudents.Rows)
                {
                    int studentID = Convert.ToInt32(row.Cells[0].Text);
                    string attendanceStatus = ((CheckBox)row.FindControl("chkPresent")).Checked ? "Present" : "Absent";

                    string insertQuery = "INSERT INTO Attendance (AttendanceID, StudentID, EducationalYear, Date, Status, MarkedBy) " +
                                         "VALUES (@AttendanceID, @StudentID, @EducationalYear, @Date, @Status, @MarkedBy)";

                    using (SqlCommand cmd = new SqlCommand(insertQuery, con))
                    {
                        int newAttendanceID = GenerateManualAttendanceID(con);
                        cmd.Parameters.AddWithValue("@AttendanceID", newAttendanceID);
                        cmd.Parameters.AddWithValue("@StudentID", studentID);
                        cmd.Parameters.AddWithValue("@EducationalYear", ddlClass.SelectedValue);
                        cmd.Parameters.AddWithValue("@Date", txtDate.Text);
                        cmd.Parameters.AddWithValue("@Status", attendanceStatus);
                        cmd.Parameters.AddWithValue("@MarkedBy", Session["StaffEmail"].ToString());

                        cmd.ExecuteNonQuery();
                    }
                }
            }
            lblMessage.Text = "Attendance submitted successfully!";
            lblMessage.ForeColor = System.Drawing.Color.Green;
        }
        catch (Exception ex)
        {
            lblMessage.Text = "Error submitting attendance: " + ex.Message;
        }
    }

    private int GenerateManualAttendanceID(SqlConnection con)
    {
        string query = "SELECT ISNULL(MAX(AttendanceID), 0) + 1 FROM Attendance";
        using (SqlCommand cmd = new SqlCommand(query, con))
        {
            return Convert.ToInt32(cmd.ExecuteScalar());
        }
    }

    protected void ddlClass_SelectedIndexChanged(object sender, EventArgs e)
    {
    }
}