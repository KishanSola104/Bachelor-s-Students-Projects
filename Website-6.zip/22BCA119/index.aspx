﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="index.aspx.cs" Inherits="index" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>DNICA College - Attendance Management</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 0; }
        .header { background: #003366; color: white; padding: 15px; display: flex; justify-content: space-between; align-items: center; }
        .header h1 { margin: 0 auto; }
        .dropdown { position: relative; display: inline-block; margin-right:50px; }
        .dropdown-content { display: none; position: absolute; background: white; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2); min-width: 60px; }
        .dropdown-content a { color: black; padding: 10px; display: block; text-decoration: none; }
        .dropdown-content a:hover { background: #ddd; }
        .dropdown:hover .dropdown-content { display: block; }
        .overlay-text { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); background: rgba(0, 0, 0, 0.6); color: white; padding: 20px; font-size: 24px; text-align: center; border-radius: 10px; }
        .content img { width: 100%; height: 500px; object-fit: cover; height:83vh; }
        .footer { background: #003366; color: white; text-align: center; padding: 10px; position: relative; bottom: 0; width: 100%; }
    </style>
</head>
<body>
    <div class="header">
        <h1>DNICA College</h1>
        <div class="dropdown">
            <button class="dropbtn">Login</button>
            <div class="dropdown-content">
                <a href="AdminLogin.aspx">Admin</a>
                <a href="StaffLogin.aspx">Staff</a>
                <a href="StudentLogin.aspx">Student</a>
            </div>
        </div>
    </div>
     <div class="content">
        <img src="Images/index.jpg" alt="College Banner" />
        <div class="overlay-text">Welcome to DNICA College Attendance Management System. Digitally managing student attendance with accuracy and efficiency.</div>
    </div>
    <div class="footer">
        <p>Contact: +91 9876543210 | Email: dnica@cesociety.in | Address: M.B.Patel Science College Campus, Behind D.N.High School, Near Sardar Gunj, Anand, Gujarat 38800</p>
    </div>
</body>
</html>
