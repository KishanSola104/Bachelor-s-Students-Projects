﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;

public partial class ManageStudents : Page
{
    private readonly string connectionString = ConfigurationManager.ConnectionStrings["CollegeAttendanceDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

        }
    }

    protected void btnAddNew_Click(object sender, EventArgs e)
    {
        try
        {

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Students (StudentID , FullName, DateOfJoining, HighestEducation,Position,EducationalYear ,  AllocatedDivision, DateOfBirth, Email, MobileNo, City, FullAddress) " +
                               "VALUES (@ID , @FullName, @DateOfJoining, @HighestEducation, @Position , @Year ,   @AllocatedDivision, @DateOfBirth, @Email, @MobileNo, @City, @FullAddress)";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@ID", txtID.Text);
                    cmd.Parameters.AddWithValue("@FullName", txtFullName.Text);
                    cmd.Parameters.AddWithValue("@DateOfJoining", txtDateOfJoining.Text);
                    cmd.Parameters.AddWithValue("@HighestEducation", txtHighestEducation.Text);
                    cmd.Parameters.AddWithValue("@Position", txtPosition.Text);
                    cmd.Parameters.AddWithValue("@Year", ddlYear.SelectedValue.Trim());
                    cmd.Parameters.AddWithValue("@AllocatedDivision", txtAllocatedDivision.Text);
                    cmd.Parameters.AddWithValue("@DateOfBirth", txtDateOfBirth.Text);
                    cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                    cmd.Parameters.AddWithValue("@MobileNo", txtMobileNo.Text);
                    cmd.Parameters.AddWithValue("@City", txtCity.Text);
                    cmd.Parameters.AddWithValue("@FullAddress", txtFullAddress.Text);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    Label1.Text = "Data For " + txtID.Text + " is Inserted ";
                    Label1.ForeColor = System.Drawing.Color.Green;
                }
            }
            GridView1.DataBind();
        }catch(SqlException ex)
        {
            Label1.Text= "Error is "+ex.Message;
        }
    }



    protected void Button1_Click(object sender, EventArgs e)
    {
        txtID.Text = "";
        txtFullAddress.Text = "";
        txtFullName.Text = "";
        txtDateOfBirth.Text = "";
        txtCity.Text = "";
        txtDateOfJoining.Text = "";
        txtHighestEducation.Text = "";
        txtMobileNo.Text = "";
        ddlYear.SelectedIndex = 0;
        txtPosition.Text = "";
        txtAllocatedDivision.Text = "";
        txtEmail.Text = "";
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminDashboard.aspx");
    }
}
