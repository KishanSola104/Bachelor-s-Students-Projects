﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="StaffProfile.aspx.cs" Inherits="StaffProfile" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
<title>Staff Profile</title>
      <style>
       body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

.header {
    background-color: #007BFF;
    color: white;
    padding: 15px;
    text-align: center;
    font-size: 20px;
}

.nav {
    display: flex;
    justify-content: center;
    background: #0056b3;
    padding: 10px;
}

.nav a {
    color: white;
    padding: 10px 20px;
    text-decoration: none;
    font-weight: bold;
}

.nav a:hover {
    background: #003f7f;
    border-radius: 5px;
}

.container {
    display: flex;
    justify-content: center;
    margin-top: 30px;
}

.profile-container {
    background: white;
    padding: 25px;
    width: 50%;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
    text-align: center;
}

.profile-container h2 {
    margin-bottom: 20px;
    color: #333;
}

.profile-container label {
    display: block;
    font-weight: bold;
    margin-top: 10px;
    text-align: left;
}

.profile-container input, 
.profile-container select, 
.profile-container textarea {
    width: 100%;
    padding: 8px;
    margin-top: 5px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 14px;
}

.profile-container textarea {
    height: 80px;
}

.btn {
    display: inline-block;
    padding: 10px 20px;
    background: #007BFF;
    color: white;
    text-decoration: none;
    border-radius: 5px;
    font-size: 16px;
    margin-top: 15px;
    border: none;
    cursor: pointer;
}

.btn:hover {
    background: #0056b3;
}

#lblMessage {
    display: block;
    margin-top: 15px;
    font-size: 14px;
}

    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="header">
            Welcome, <asp:Label ID="lblStaffName" runat="server" Text="Staff"></asp:Label>
        </div>

        <div class="nav">
            <a href="StaffDashboard.aspx">Home</a>
            <a href="MarkAttendance.aspx">Mark Attendance</a>
            <a href="ViewAttendance.aspx">View Attendance</a>
             <a href="ManageStudentsAttendance.aspx">Manage Students Attendance</a>
             <a href="ViewStudentsAttendance.aspx">View Students Attendance</a>
                <a href="ViewMonthlyAttendance.aspx">View Monthly Attendance</a>
            <a href="StaffProfile.aspx">Profile</a>
            <a href="StaffLogin.aspx">Log Out</a>
        </div>

        <div class="container">
           <div class="profile-container">
            <h2>Staff Profile</h2>
            
            <label>Staff ID:</label>
            <asp:TextBox ID="txtStaffID" runat="server" ReadOnly="true"></asp:TextBox>

            <label>Email:</label>
            <asp:TextBox ID="txtEmail" runat="server" ReadOnly="true"></asp:TextBox>

            <label>Full Name:</label>
            <asp:TextBox ID="txtFullName" runat="server"></asp:TextBox>

            <label>Mobile No:</label>
            <asp:TextBox ID="txtMobileNo" runat="server"></asp:TextBox>

            <label>City:</label>
            <asp:DropDownList ID="ddlCity" runat="server">
                <asp:ListItem Text="Anand" Value="Anand"></asp:ListItem>
                <asp:ListItem Text="Vidhya Nagar" Value="Vidhya Nagar"></asp:ListItem>
                <asp:ListItem Text="Ahmedabad" Value="Ahmedabad"></asp:ListItem>
                <asp:ListItem Text="Surat" Value="Surat"></asp:ListItem>
            </asp:DropDownList>

            <label>Full Address:</label>
            <asp:TextBox ID="txtFullAddress" runat="server" TextMode="MultiLine"></asp:TextBox>

            <asp:Button ID="btnSave" runat="server" Text="Save Changes" CssClass="btn" OnClick="btnSave_Click" />
            
            <br />
            <asp:Label ID="lblMessage" runat="server" ForeColor="Red"></asp:Label>
        </div>
        </div>
    </form>
</body>
</html>