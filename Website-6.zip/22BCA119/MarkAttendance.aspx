﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="MarkAttendance.aspx.cs" Inherits="MarkAttendance" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Mark Attendance</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .header {
            background-color: #007BFF;
            color: white;
            padding: 15px;
            text-align: center;
            font-size: 20px;
        }

        .nav {
            display: flex;
            justify-content: center;
            background: #0056b3;
            padding: 10px;
        }

        .nav a {
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            font-weight: bold;
        }

        .nav a:hover {
            background: #003f7f;
            border-radius: 5px;
        }

        .container {
            text-align: center;
            margin-top: 20px;
        }

        .dashboard-box {
            background: white;
            padding: 20px;
            margin: 20px auto;
            width: 50%;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        .btn {
            display: inline-block;
            padding: 10px 20px;
            background: #007BFF;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
            margin-top: 10px;
        }

        .btn:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="header">
            Welcome, <asp:Label ID="lblStaffName" runat="server" Text="Staff"></asp:Label>
        </div>

        <div class="nav">
            <a href="StaffDashboard.aspx">Home</a>
            <a href="MarkAttendance.aspx">Mark Attendance</a>
            <a href="ViewAttendance.aspx">View Attendance</a>
             <a href="ManageStudentsAttendance.aspx">Manage Students Attendance</a>
             <a href="ViewStudentsAttendance.aspx">View Students Attendance</a>
                <a href="ViewMonthlyAttendance.aspx">View Monthly Attendance</a>
            <a href="StaffProfile.aspx">Profile</a>
            <a href="StaffLogin.aspx">Log Out</a>
        </div>

        <div class="container">
            <h2>Mark Attendance</h2>
            <p>Date: <asp:Label ID="lblDate" runat="server"></asp:Label></p>
            <asp:Button ID="btnMarkAttendance" runat="server" CssClass="btn" Text="Mark Attendance" OnClick="btnMarkAttendance_Click" />
            <p class="message">
                <asp:Label ID="lblMessage" runat="server" ForeColor="Red"></asp:Label>
            </p>
        </div>
    </form>
</body>
</html>