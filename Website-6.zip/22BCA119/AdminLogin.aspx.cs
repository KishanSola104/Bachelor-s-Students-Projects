﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.UI;

public partial class AdminLogin : Page
{
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        string email = txtEmail.Text.Trim();
        string password = txtPassword.Text.Trim();

        if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
        {
            lblMessage.Text = "Please enter both Email and Password.";
            return;
        }

        string connStr = ConfigurationManager.ConnectionStrings["CollegeAttendanceDB"].ConnectionString;
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            try
            {
                conn.Open();
                string query = "SELECT COUNT(*) FROM Admins WHERE Email = @Email AND Password = @Password";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Email", email);
                    cmd.Parameters.AddWithValue("@Password", password);

                    int count = Convert.ToInt32(cmd.ExecuteScalar());
                    if (count > 0)
                    {
                        Session["AdminEmail"] = email;
                        Response.Redirect("AdminDashboard.aspx");
                    }
                    else
                    {
                        lblMessage.Text = "Invalid Email or Password.";
                    }
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = "An error occurred: " + ex.Message;
            }
        }
    }
}