﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;

public partial class ViewMonthlyAttendance1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["StudentID"] == null)
        {
            Response.Redirect("StudentLogin.aspx");
        }
        else
        {
            string studentID = Session["StudentID"].ToString();
            FetchStudentName(studentID);
        }
    }

    private void FetchStudentName(string studentID)
    {
        string connectionString = ConfigurationManager.ConnectionStrings["CollegeAttendanceDB"].ConnectionString;

        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            string query = "SELECT FullName FROM Students WHERE StudentID = @StudentID";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@StudentID", studentID);
                conn.Open();
                object result = cmd.ExecuteScalar();
                conn.Close();

                if (result != null)
                {
                    lblStudentName.Text = result.ToString();
                }
            }
        }
    }

    protected void ddlMonth_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlMonth.SelectedValue != "")
        {
            string studentID = Session["StudentID"].ToString();
            string selectedMonth = ddlMonth.SelectedValue;
            string query = "SELECT COUNT(*) FROM Attendance WHERE StudentID = @StudentID AND MONTH(Date) = @Month AND Status = 'Present'";

            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["CollegeAttendanceDB"].ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@StudentID", studentID);
                    cmd.Parameters.AddWithValue("@Month", selectedMonth);
                    conn.Open();
                    int count = (int)cmd.ExecuteScalar();
                    conn.Close();
                    lblSummary.Text = "Total Present Days in Selected Month: " + count;
                }
            }
        }
        else
        {
            lblSummary.Text = "Please select a month.";
        }
    }
}
