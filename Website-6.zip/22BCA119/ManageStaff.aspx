﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="ManageStaff.aspx.cs" Inherits="ManageStaff" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
 <title>Manage Staff - DNICA College</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 0; background: #f4f4f4; }
        .header { background: #003366; color: white; padding: 15px; text-align: center; }
        .container { padding: 20px; }
        table { width: 100%; border-collapse: collapse; background: white; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
        th { background: #0055a4; color: white; }
        .footer { background: #003366; color: white; text-align: center; padding: 10px; position: relative; bottom: 0; width: 100%; }
        .btn { background: #0055a4; color: white; padding: 10px; border: none; cursor: pointer; }
    </style>
</head>
<body>
    <form id="Form1" runat="server">
        <div class="header">
            <h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Manage Staff - DNICA College&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <asp:Button ID="Button2" runat="server" Text="Home" CssClass="btn" onclick="Button2_Click" 
                     /></h2>
        </div>
        <div class="container">
            <h3>Add Staff</h3>
            <p>
                <asp:Label ID="Label1" runat="server"></asp:Label>
            </p>
            <p>
                <asp:Label ID="lblMessage" runat="server"></asp:Label>
            </p>
            <table>
             <tr>
                    <td>Staff ID:</td>
                    <td><asp:TextBox ID="txtID" runat="server"></asp:TextBox></td>
                </tr>
                <tr>
                    <td>Full Name:</td>
                    <td><asp:TextBox ID="txtFullName" runat="server"></asp:TextBox></td>
                </tr>
                <tr>
                    <td>Date Of Joining:</td>
                    <td><asp:TextBox ID="txtDateOfJoining" runat="server" TextMode="Date"></asp:TextBox></td>
                </tr>
                <tr>
                    <td>Highest Education:</td>
                    <td><asp:TextBox ID="txtHighestEducation" runat="server"></asp:TextBox></td>
                </tr>

                <tr>
                    <td>Position :</td>
                    <td><asp:TextBox ID="txtPosition" runat="server"></asp:TextBox></td>
                </tr>
                <tr>
                    <td>Salary:</td>
                    <td><asp:TextBox ID="txtSalary" runat="server"></asp:TextBox></td>
                </tr>
                <tr>
                    <td>Allocated Division:</td>
                    <td><asp:TextBox ID="txtAllocatedDivision" runat="server"></asp:TextBox></td>
                </tr>
                <tr>
                    <td>Date Of Birth:</td>
                    <td><asp:TextBox ID="txtDateOfBirth" runat="server" TextMode="Date"></asp:TextBox></td>
                </tr>
                <tr>
                    <td>Email:</td>
                    <td><asp:TextBox ID="txtEmail" runat="server"></asp:TextBox></td>
                </tr>
                <tr>
                    <td>Mobile No:</td>
                    <td><asp:TextBox ID="txtMobileNo" runat="server"></asp:TextBox></td>
                </tr>
                <tr>
                    <td>City:</td>
                    <td><asp:TextBox ID="txtCity" runat="server"></asp:TextBox></td>
                </tr>
                <tr>
                    <td>Full Address:</td>
                    <td><asp:TextBox ID="txtFullAddress" runat="server"></asp:TextBox></td>
                </tr>
                <tr>
                    <td colspan="2" style="text-align:center;"><asp:Button ID="btnAddNew" runat="server" Text="Add Staff" CssClass="btn" OnClick="btnAddNew_Click" />
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <asp:Button ID="Button1" runat="server" Text="Clear" CssClass="btn" 
                            onclick="Button1_Click"  /></td>
                </tr>
            </table>
            <br />
            <h3>Staff List</h3>
            <p>
                <asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False" 
                    DataKeyNames="StaffID" DataSourceID="SqlDataSource1">
                    <Columns>
                        <asp:CommandField ShowDeleteButton="True" ShowEditButton="True" />
                        <asp:BoundField DataField="StaffID" HeaderText="StaffID" ReadOnly="True" 
                            SortExpression="StaffID" />
                        <asp:BoundField DataField="FullName" HeaderText="FullName" 
                            SortExpression="FullName" />
                        <asp:BoundField DataField="DateOfJoining" HeaderText="DateOfJoining" 
                            SortExpression="DateOfJoining" />
                        <asp:BoundField DataField="HighestEducation" HeaderText="HighestEducation" 
                            SortExpression="HighestEducation" />
                        <asp:BoundField DataField="Position" HeaderText="Position" 
                            SortExpression="Position" />
                        <asp:BoundField DataField="Salary" HeaderText="Salary" 
                            SortExpression="Salary" />
                        <asp:BoundField DataField="AllocatedDivision" HeaderText="AllocatedDivision" 
                            SortExpression="AllocatedDivision" />
                        <asp:BoundField DataField="DateOfBirth" HeaderText="DateOfBirth" 
                            SortExpression="DateOfBirth" />
                        <asp:BoundField DataField="Email" HeaderText="Email" SortExpression="Email" />
                        <asp:BoundField DataField="MobileNo" HeaderText="MobileNo" 
                            SortExpression="MobileNo" />
                        <asp:BoundField DataField="City" HeaderText="City" SortExpression="City" />
                        <asp:BoundField DataField="FullAddress" HeaderText="FullAddress" 
                            SortExpression="FullAddress" />
                    </Columns>
                </asp:GridView>
                <asp:SqlDataSource ID="SqlDataSource1" runat="server" 
                    ConnectionString="<%$ ConnectionStrings:CollegeAttendanceDB %>" 
                    DeleteCommand="DELETE FROM [Staff] WHERE [StaffID] = @StaffID" 
                    InsertCommand="INSERT INTO [Staff] ([StaffID], [FullName], [DateOfJoining], [HighestEducation], [Position], [Salary], [AllocatedDivision], [DateOfBirth], [Email], [MobileNo], [City], [FullAddress]) VALUES (@StaffID, @FullName, @DateOfJoining, @HighestEducation, @Position, @Salary, @AllocatedDivision, @DateOfBirth, @Email, @MobileNo, @City, @FullAddress)" 
                    SelectCommand="SELECT * FROM [Staff]" 
                    UpdateCommand="UPDATE [Staff] SET [FullName] = @FullName, [DateOfJoining] = @DateOfJoining, [HighestEducation] = @HighestEducation, [Position] = @Position, [Salary] = @Salary, [AllocatedDivision] = @AllocatedDivision, [DateOfBirth] = @DateOfBirth, [Email] = @Email, [MobileNo] = @MobileNo, [City] = @City, [FullAddress] = @FullAddress WHERE [StaffID] = @StaffID">
                    <DeleteParameters>
                        <asp:Parameter Name="StaffID" Type="String" />
                    </DeleteParameters>
                    <InsertParameters>
                        <asp:Parameter Name="StaffID" Type="String" />
                        <asp:Parameter Name="FullName" Type="String" />
                        <asp:Parameter Name="DateOfJoining" Type="DateTime" />
                        <asp:Parameter Name="HighestEducation" Type="String" />
                        <asp:Parameter Name="Position" Type="String" />
                        <asp:Parameter Name="Salary" Type="Int32" />
                        <asp:Parameter Name="AllocatedDivision" Type="String" />
                        <asp:Parameter Name="DateOfBirth" Type="DateTime" />
                        <asp:Parameter Name="Email" Type="String" />
                        <asp:Parameter Name="MobileNo" Type="String" />
                        <asp:Parameter Name="City" Type="String" />
                        <asp:Parameter Name="FullAddress" Type="String" />
                    </InsertParameters>
                    <UpdateParameters>
                        <asp:Parameter Name="FullName" Type="String" />
                        <asp:Parameter Name="DateOfJoining" Type="DateTime" />
                        <asp:Parameter Name="HighestEducation" Type="String" />
                        <asp:Parameter Name="Position" Type="String" />
                        <asp:Parameter Name="Salary" Type="Int32" />
                        <asp:Parameter Name="AllocatedDivision" Type="String" />
                        <asp:Parameter Name="DateOfBirth" Type="DateTime" />
                        <asp:Parameter Name="Email" Type="String" />
                        <asp:Parameter Name="MobileNo" Type="String" />
                        <asp:Parameter Name="City" Type="String" />
                        <asp:Parameter Name="FullAddress" Type="String" />
                        <asp:Parameter Name="StaffID" Type="String" />
                    </UpdateParameters>
                </asp:SqlDataSource>
            </p>
        </div>
        <div class="footer">
            <p>Contact: +91 9876543210 | Email: info@dnica.edu | Address: M.B.Patel Science College Campus, Behind D.N.High School, Near Sardar Gunj, Anand, Gujarat 388001</p>
        </div>
    </form>
</body>
</html>
