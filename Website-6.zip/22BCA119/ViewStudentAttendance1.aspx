﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="ViewStudentAttendance1.aspx.cs" Inherits="ViewStudentAttendance1" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>View Student Attendance</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .header {
            background-color: #007BFF;
            color: white;
            padding: 15px;
            text-align: center;
            font-size: 20px;
        }

        .nav {
            display: flex;
            justify-content: center;
            background: #0056b3;
            padding: 10px;
        }

        .nav a {
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            font-weight: bold;
        }

        .nav a:hover {
            background: #003f7f;
            border-radius: 5px;
        }

        .container {
            text-align: center;
            margin: 20px auto;
            width: 80%;
            background: white;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }

        th {
            background: #007BFF;
            color: white;
        }

        .footer {
            background: #333;
            color: white;
            text-align: center;
            padding: 10px;
            position: absolute;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="header">
            View Attendance - <asp:Label ID="lblStudentName" runat="server"></asp:Label>
        </div>

        <div class="nav">
            <a href="StudentDashboard.aspx">Home</a>
            <a href="ViewStudentAttendance1.aspx">View Attendance</a>
            <a href="ViewMonthlyAttendance1.aspx">View Monthly Attendance</a>
            <a href="StudentLogin.aspx">Logout</a>
        </div>

        <div class="container">
            <h2>Your Attendance Records</h2>
            <asp:GridView ID="gvAttendance" runat="server" AutoGenerateColumns="False" CssClass="table">
                <Columns>
                    <asp:BoundField DataField="Date" HeaderText="Date" />
                    <asp:BoundField DataField="Status" HeaderText="Status (Present/Absent)" />
                </Columns>
            </asp:GridView>
        </div>

        <div class="footer">
            &copy; 2025 DNICA College. All Rights Reserved.
        </div>
    </form>
</body>
</html>