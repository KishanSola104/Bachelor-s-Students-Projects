﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;

public partial class ViewStudentAttendance1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["StudentID"] == null)
        {
            Response.Redirect("StudentLogin.aspx");
        }
        else
        {
            string studentID = Session["StudentID"].ToString();
            FetchStudentName(studentID);
            LoadAttendance(studentID);
        }
    }

    private void FetchStudentName(string studentID)
    {
        string connectionString = ConfigurationManager.ConnectionStrings["CollegeAttendanceDB"].ConnectionString;

        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            string query = "SELECT FullName FROM Students WHERE StudentID = @StudentID";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@StudentID", studentID);
                conn.Open();
                object result = cmd.ExecuteScalar();
                conn.Close();

                if (result != null)
                {
                    lblStudentName.Text = result.ToString();
                }
            }
        }
    }

    private void LoadAttendance(string studentID)
    {
        string connectionString = ConfigurationManager.ConnectionStrings["CollegeAttendanceDB"].ConnectionString;

        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            string query = "SELECT Date, Status FROM Attendance WHERE StudentID = @StudentID ORDER BY Date DESC";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@StudentID", studentID);
                conn.Open();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                gvAttendance.DataSource = dt;
                gvAttendance.DataBind();
                conn.Close();
            }
        }
    }
}
