﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;

public partial class StaffProfile : Page
{
    private readonly string connectionString = ConfigurationManager.ConnectionStrings["CollegeAttendanceDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadProfileData();
        }
    }

    private void LoadProfileData()
    {
        string staffEmail = "";
        if (Session["StaffEmail"] != null)
        {
            staffEmail = Session["StaffEmail"].ToString();
        }
        else
        {
            lblMessage.Text = "Session expired. Please log in again.";
            return;
        }

        using (SqlConnection con = new SqlConnection(connectionString))
        {
            string query = "SELECT * FROM Staff WHERE Email = @Email";
            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                cmd.Parameters.AddWithValue("@Email", staffEmail);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    txtStaffID.Text = reader["StaffID"].ToString();
                    txtEmail.Text = reader["Email"].ToString();
                    txtFullName.Text = reader["FullName"].ToString();
                    txtMobileNo.Text = reader["MobileNo"].ToString();
                    ddlCity.SelectedValue = reader["City"].ToString();
                    txtFullAddress.Text = reader["FullAddress"].ToString();
                }
                else
                {
                    lblMessage.Text = "Staff details not found.";
                }
            }
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "UPDATE Staff SET FullName=@FullName, MobileNo=@MobileNo, City=@City, FullAddress=@FullAddress WHERE StaffID=@StaffID";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@FullName", txtFullName.Text);
                    cmd.Parameters.AddWithValue("@MobileNo", txtMobileNo.Text);
                    cmd.Parameters.AddWithValue("@City", ddlCity.SelectedValue);
                    cmd.Parameters.AddWithValue("@FullAddress", txtFullAddress.Text);
                    cmd.Parameters.AddWithValue("@StaffID", txtStaffID.Text);

                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        lblMessage.Text = "Profile updated successfully!";
                        lblMessage.ForeColor = System.Drawing.Color.Green;
                    }
                    else
                    {
                        lblMessage.Text = "Update failed. Please try again.";
                    }
                }
            }
        }
        catch (Exception ex)
        {
            lblMessage.Text = "Error: " + ex.Message;
        }
    }
}
