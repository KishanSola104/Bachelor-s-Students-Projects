﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="ViewStudentsAttendance.aspx.cs" Inherits="ViewStudentsAttendance" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
   <title>View Students Attendance</title>
      <style>
     body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

.header {
    background-color: #007BFF;
    color: white;
    padding: 15px;
    text-align: center;
    font-size: 20px;
}

.nav {
    display: flex;
    justify-content: center;
    background: #0056b3;
    padding: 10px;
}

.nav a {
    color: white;
    padding: 10px 20px;
    text-decoration: none;
    font-weight: bold;
}

.nav a:hover {
    background: #003f7f;
    border-radius: 5px;
}

.container {
    text-align: center;
    margin-top: 20px;
}

h2 {
    color: #333;
}

label {
    font-size: 16px;
    font-weight: bold;
    color: #333;
    display: block;
    margin: 10px 0 5px;
}

input[type="date"],
select {
    padding: 10px;
    width: 250px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 16px;
}

.btn {
    display: inline-block;
    padding: 10px 20px;
    background: #007BFF;
    color: white;
    text-decoration: none;
    border-radius: 5px;
    font-size: 16px;
    margin-top: 10px;
    border: none;
    cursor: pointer;
}

.btn:hover {
    background: #0056b3;
}

.grid-container {
    width: 80%;
    margin: 20px auto;
    background: white;
    padding: 20px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}

.grid-container table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

.grid-container th,
.grid-container td {
    padding: 10px;
    border: 1px solid #ddd;
    text-align: center;
}

.grid-container th {
    background: #007BFF;
    color: white;
}

.grid-container tr:nth-child(even) {
    background: #f2f2f2;
}

.grid-container tr:hover {
    background: #ddd;
}

.message {
    color: red;
    font-size: 16px;
    margin-top: 10px;
}

    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="header">
            Welcome, <asp:Label ID="lblStaffName" runat="server" Text="Staff"></asp:Label>
        </div>

        <div class="nav">
            <a href="StaffDashboard.aspx">Home</a>
            <a href="MarkAttendance.aspx">Mark Attendance</a>
            <a href="ViewAttendance.aspx">View Attendance</a>
             <a href="ManageStudentsAttendance.aspx">Manage Students Attendance</a>
             <a href="ViewStudentsAttendance.aspx">View Students Attendance</a>
                <a href="ViewMonthlyAttendance.aspx">View Monthly Attendance</a>
            <a href="StaffProfile.aspx">Profile</a>
            <a href="StaffLogin.aspx">Log Out</a>
        </div>

        <div>
            <h2>View Students Attendance</h2>

            <label>Select Educational Year:</label>
            <asp:DropDownList ID="ddlClass" runat="server" AutoPostBack="false"></asp:DropDownList>

            <br /><br />

            <label>Select Date:</label>
            <asp:TextBox ID="txtDate" runat="server" TextMode="Date"></asp:TextBox>

            <br /><br />

            <asp:Button ID="btnViewAttendance" runat="server" Text="View Attendance" 
                OnClick="btnViewAttendance_Click" />

            <br /><br />
            <asp:Label ID="lblMessage" runat="server" ForeColor="Red"></asp:Label>

            <br /><br />

            <asp:GridView ID="gvAttendance" runat="server" AutoGenerateColumns="false" BorderWidth="1">
                <Columns>
                    <asp:BoundField DataField="StudentID" HeaderText="Student ID" />
                   
                    <asp:BoundField DataField="Date" HeaderText="Date" DataFormatString="{0:yyyy-MM-dd}" />
                    <asp:BoundField DataField="Status" HeaderText="Attendance Status" />
                    <asp:BoundField DataField="MarkedBy" HeaderText="Marked By" />
                </Columns>
            </asp:GridView>
        </div>
    </form>
</body>
</html>