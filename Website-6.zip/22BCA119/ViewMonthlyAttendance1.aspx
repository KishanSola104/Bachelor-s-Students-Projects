﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="ViewMonthlyAttendance1.aspx.cs" Inherits="ViewMonthlyAttendance1" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>View Monthly Attendance</title>
    <style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 0;
    }

    .header {
        background-color: #007BFF;
        color: white;
        padding: 15px;
        text-align: center;
        font-size: 22px;
        font-weight: bold;
    }

    .nav {
        display: flex;
        justify-content: center;
        background: #0056b3;
        padding: 10px;
    }

    .nav a {
        color: white;
        padding: 10px 20px;
        text-decoration: none;
        font-weight: bold;
    }

    .nav a:hover {
        background: #003f7f;
        border-radius: 5px;
    }

    .container {
        text-align: center;
        margin: 30px auto;
        background: white;
        padding: 20px;
        width: 50%;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        border-radius: 8px;
    }

    h2 {
        color: #333;
    }

    select {
        padding: 8px;
        width: 50%;
        font-size: 16px;
        border: 1px solid #ccc;
        border-radius: 5px;
        margin-top: 10px;
    }

    .summary-label {
        font-size: 18px;
        color: #007BFF;
        margin-top: 20px;
        display: block;
        font-weight: bold;
    }
</style>

</head>
<body>
    <form id="form1" runat="server">
        <div class="header">
            View Monthly Attendance - <asp:Label ID="lblStudentName" runat="server"></asp:Label>
        </div>

        <div class="nav">
            <a href="StudentDashboard.aspx">Home</a>
            <a href="ViewStudentAttendance1.aspx">View Attendance</a>
            <a href="ViewMonthlyAttendance1.aspx">View Monthly Attendance</a>
            <a href="StudentLogin.aspx">Logout</a>
        </div>

        <div class="container">
            <h2>Monthly Attendance Summary</h2>
            <asp:DropDownList ID="ddlMonth" runat="server" AutoPostBack="true" OnSelectedIndexChanged="ddlMonth_SelectedIndexChanged">
                <asp:ListItem Text="Select Month" Value=""></asp:ListItem>
                <asp:ListItem Text="January" Value="1"></asp:ListItem>
                <asp:ListItem Text="February" Value="2"></asp:ListItem>
                <asp:ListItem Text="March" Value="3"></asp:ListItem>
                <asp:ListItem Text="April" Value="4"></asp:ListItem>
                <asp:ListItem Text="May" Value="5"></asp:ListItem>
                <asp:ListItem Text="June" Value="6"></asp:ListItem>
                <asp:ListItem Text="July" Value="7"></asp:ListItem>
                <asp:ListItem Text="August" Value="8"></asp:ListItem>
                <asp:ListItem Text="September" Value="9"></asp:ListItem>
                <asp:ListItem Text="October" Value="10"></asp:ListItem>
                <asp:ListItem Text="November" Value="11"></asp:ListItem>
                <asp:ListItem Text="December" Value="12"></asp:ListItem>
            </asp:DropDownList>

            <asp:Label ID="lblSummary" runat="server" Font-Bold="true"></asp:Label>
        </div>
    </form>
</body>
</html>