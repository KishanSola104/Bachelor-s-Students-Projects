﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.UI;

public partial class StudentLogin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lblMessage.Text = "";  // Clear message on page load
    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        string studentID = txtStudentID.Text.Trim();
        string dob = txtDOB.Text.Trim();

        if (string.IsNullOrEmpty(studentID) || string.IsNullOrEmpty(dob))
        {
            lblMessage.Text = "Please enter Student ID and Date of Birth.";
            return;
        }

        string connectionString = ConfigurationManager.ConnectionStrings["CollegeAttendanceDB"].ConnectionString;

        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            string query = "SELECT COUNT(*) FROM Students WHERE StudentID = @StudentID AND DateOfBirth = @DOB";

            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@StudentID", studentID);
                cmd.Parameters.AddWithValue("@DOB", dob);

                conn.Open();
                int count = (int)cmd.ExecuteScalar();
                conn.Close();

                if (count > 0)
                {
                    Session["StudentID"] = studentID;  // Store student ID in session
                    Response.Redirect("StudentDashboard.aspx");  // Redirect to Student Dashboard
                }
                else
                {
                    lblMessage.Text = "Invalid Student ID or Date of Birth.";
                }
            }
        }
    }
}
