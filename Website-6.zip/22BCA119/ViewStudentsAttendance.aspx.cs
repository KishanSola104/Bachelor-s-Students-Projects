﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI.WebControls;

public partial class ViewStudentsAttendance : System.Web.UI.Page
{
    private readonly string connectionString = ConfigurationManager.ConnectionStrings["CollegeAttendanceDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadEducationalYears();
        }
    }

    private void LoadEducationalYears()
    {
        try
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT DISTINCT EducationalYear FROM Students";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    ddlClass.DataSource = reader;
                    ddlClass.DataTextField = "EducationalYear";
                    ddlClass.DataValueField = "EducationalYear";
                    ddlClass.DataBind();
                    ddlClass.Items.Insert(0, new ListItem("-- Select Educational Year --", ""));
                }
            }
        }
        catch (Exception ex)
        {
            lblMessage.Text = "Error loading educational years: " + ex.Message;
        }
    }

    protected void btnViewAttendance_Click(object sender, EventArgs e)
    {
        try
        {
            if (ddlClass.SelectedValue == "" || string.IsNullOrEmpty(txtDate.Text))
            {
                lblMessage.Text = "Please select both an Educational Year and a Date.";
                lblMessage.ForeColor = System.Drawing.Color.Red;
                return;
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT StudentID,  Date, Status, MarkedBy FROM Attendance " +
                               "WHERE EducationalYear = @EducationalYear AND Date = @Date";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@EducationalYear", ddlClass.SelectedValue);
                    cmd.Parameters.AddWithValue("@Date", txtDate.Text);

                    con.Open();
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        gvAttendance.DataSource = dt;
                        gvAttendance.DataBind();
                        lblMessage.Text = "";
                    }
                    else
                    {
                        gvAttendance.DataSource = null;
                        gvAttendance.DataBind();
                        lblMessage.Text = "No attendance records found for the selected date and year.";
                    }
                }
            }
        }
        catch (Exception ex)
        {
            lblMessage.Text = "Error fetching attendance records: " + ex.Message;
        }
    }
}
