﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="ManageStudentsAttendance.aspx.cs" Inherits="ManageStudentsAttendance" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
 <title>Manage Students Attendance</title>
     <style>
         body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 0;
    }

    .header {
        background-color: #007BFF;
        color: white;
        padding: 15px;
        text-align: center;
        font-size: 22px;
        font-weight: bold;
    }

    .nav {
        display: flex;
        justify-content: center;
        background: #0056b3;
        padding: 12px;
        flex-wrap: wrap;
    }

    .nav a {
        color: white;
        padding: 12px 18px;
        text-decoration: none;
        font-weight: bold;
        transition: 0.3s;
    }

    .nav a:hover {
        background: #003f7f;
        border-radius: 5px;
    }

    .container {
        max-width: 800px;
        margin: 30px auto;
        background: white;
        padding: 25px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        border-radius: 8px;
        text-align: center;
    }

    h2 {
        color: #333;
        margin-bottom: 20px;
    }

    label {
        font-size: 16px;
        font-weight: bold;
        margin-right: 5px;
    }

    input[type="date"], select {
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-size: 14px;
        width: 200px;
        margin-right: 10px;
    }

    .btn {
        display: inline-block;
        padding: 10px 20px;
        background: #007BFF;
        color: white;
        text-decoration: none;
        border-radius: 5px;
        font-size: 16px;
        margin-top: 10px;
        cursor: pointer;
        border: none;
    }

    .btn:hover {
        background: #0056b3;
    }

    .table {
        width: 100%;
        margin-top: 20px;
        border-collapse: collapse;
        background: white;
        box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
    }

    .table th, .table td {
        padding: 10px;
        border: 1px solid #ddd;
        text-align: center;
    }

    .table th {
        background-color: #007BFF;
        color: white;
    }

    .table tr:nth-child(even) {
        background-color: #f9f9f9;
    }

    .table tr:hover {
        background-color: #f1f1f1;
    }

    .present {
        background: #28a745;
    }

    .present:hover {
        background: #218838;
    }

    .message {
        margin-top: 10px;
        font-weight: bold;
        color: red;
    }

    @media (max-width: 768px) {
        .container {
            width: 95%;
            padding: 15px;
        }

        .nav {
            flex-direction: column;
            align-items: center;
        }

        .nav a {
            width: 100%;
            text-align: center;
            padding: 10px;
        }

        input[type="date"], select {
            width: 100%;
            margin: 5px 0;
        }

        .btn {
            width: 100%;
        }
    }

    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="header">
            Welcome, <asp:Label ID="lblStaffName" runat="server" Text="Staff"></asp:Label>
        </div>

        <div class="nav">
            <a href="StaffDashboard.aspx">Home</a>
            <a href="MarkAttendance.aspx">Mark Attendance</a>
            <a href="ViewAttendance.aspx">View Attendance</a>
             <a href="ManageStudentsAttendance.aspx">Manage Students Attendance</a>
             <a href="ViewStudentsAttendance.aspx">View Students Attendance</a>
                <a href="ViewMonthlyAttendance.aspx">View Monthly Attendance</a>
            <a href="StaffProfile.aspx">Profile</a>
            <a href="StaffLogin.aspx">Log Out</a>
        </div>

         <div class="container">
            <h2>Manage Students Attendance</h2>

            <label>Select Date:</label>
            <asp:TextBox ID="txtDate" runat="server" TextMode="Date"></asp:TextBox>

            <label>Select Educational Year:</label>
            <asp:DropDownList ID="ddlClass" runat="server" AutoPostBack="true" 
                OnSelectedIndexChanged="ddlClass_SelectedIndexChanged">
            </asp:DropDownList>

            <asp:Button ID="btnLoadStudents" runat="server" Text="Load Students" CssClass="btn" OnClick="btnLoadStudents_Click" />

            <asp:GridView ID="gvStudents" runat="server" AutoGenerateColumns="False" CssClass="table">
                <Columns>
                    <asp:BoundField DataField="StudentID" HeaderText="Student ID" />
                    <asp:BoundField DataField="FullName" HeaderText="Student Name" />
                    <asp:TemplateField HeaderText="Attendance">
                        <ItemTemplate>
                            <asp:CheckBox ID="chkPresent" runat="server" />
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>
            </asp:GridView>

            <asp:Button ID="btnSubmitAttendance" runat="server" Text="Submit Attendance" CssClass="btn present" OnClick="btnSubmitAttendance_Click" />

            <asp:Label ID="lblMessage" runat="server" ForeColor="Red"></asp:Label>
        </div>
    </form>
</body>
</html>