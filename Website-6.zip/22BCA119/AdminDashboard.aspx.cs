﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.UI;

public partial class AdminDashboard : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadCounts();
        }
    }

    private void LoadCounts()
    {
        // Get connection string from Web.config
        string connString = ConfigurationManager.ConnectionStrings["CollegeAttendanceDB"].ConnectionString;

        using (SqlConnection conn = new SqlConnection(connString))
        {
            try
            {
                conn.Open();

                // Query for Staff Count
                string staffQuery = "SELECT COUNT(*) FROM Staff";
                using (SqlCommand cmd = new SqlCommand(staffQuery, conn))
                {
                    int staffCount = (int)cmd.ExecuteScalar();
                    lblTotalStaff.Text = staffCount.ToString();
                }

                // Query for Students Count
                string studentQuery = "SELECT COUNT(*) FROM Students";
                using (SqlCommand cmd = new SqlCommand(studentQuery, conn))
                {
                    int studentCount = (int)cmd.ExecuteScalar();
                    lblTotalStudents.Text = studentCount.ToString();
                }
            }
            catch (Exception ex)
            {
                lblTotalStaff.Text = "Error";
                lblTotalStudents.Text = "Error";
                // Log the error if needed
            }
        }
    }
    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminLogin.aspx");
    }
}
