﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="StaffSignUp.aspx.cs" Inherits="StaffSignUp" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
   <title>Staff Sign Up</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
        }

        .container {
            width: 350px;
            background: white;
            padding: 20px;
            margin: 50px auto;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        h2 {
            color: #333;
        }

        label {
            font-weight: bold;
            display: block;
            margin-top: 10px;
            text-align: left;
        }

        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .btn {
            background-color: #007BFF;
            color: white;
            border: none;
            padding: 10px;
            width: 100%;
            margin-top: 15px;
            cursor: pointer;
            font-size: 16px;
            border-radius: 5px;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        .message {
            margin-top: 10px;
            font-weight: bold;
        }

        a {
            display: block;
            margin-top: 15px;
            color: #007BFF;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="container">
            <h2>Staff Registration</h2>
            
            <label>Staff ID:</label>
            <asp:TextBox ID="txtStaffID" runat="server"></asp:TextBox>

            <label>Email:</label>
            <asp:TextBox ID="txtEmail" runat="server"></asp:TextBox>

            <label>Password:</label>
            <asp:TextBox ID="txtPassword" runat="server" TextMode="Password"></asp:TextBox>

            <asp:Button ID="btnSignUp" runat="server" CssClass="btn" Text="Sign Up" OnClick="btnSignUp_Click" />

            <asp:Label ID="lblMessage" runat="server" CssClass="message" ForeColor="Red"></asp:Label>

            <a href="StaffLogin.aspx">Already have an account? Login here</a>
        </div>
    </form>
</body>
</html>
