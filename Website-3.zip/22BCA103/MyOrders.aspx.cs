﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

public partial class MyOrders : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserEmail"] == null)
        {
            Response.Redirect("Login.aspx"); // Redirect to login if not logged in
        }

        if (!IsPostBack)
        {
            LoadOrders();
        }
    }

    private void LoadOrders()
    {
        string userEmail = Session["UserEmail"].ToString();
        string connString = ConfigurationManager.ConnectionStrings["22BCA103"].ConnectionString;

        using (SqlConnection conn = new SqlConnection(connString))
        {
            string query = "SELECT UserEmail, TotalAmount, PaymentDate, PaymentMethod FROM Payments WHERE UserEmail = @UserEmail";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@UserEmail", userEmail);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            gvOrders.DataSource = dt;
            gvOrders.DataBind();
        }
    }

    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("UserDashboard.aspx"); // Redirect to Dashboard
    }
}
