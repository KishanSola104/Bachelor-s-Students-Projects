﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Configuration;

public partial class ManageProducts : Page
{
    // Admin details class
    public class AdminDetails
    {
        public string AdminName { get; set; }
        public string ImageUrl { get; set; }
    }

    string connStr = ConfigurationManager.ConnectionStrings["22BCA103"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["AdminEmail"] == null)
            {
                Response.Redirect("AdminLogin.aspx");
                return;
            }

            string adminEmail = Session["AdminEmail"].ToString();
            AdminDetails adminDetails = GetAdminDetails(adminEmail);

            lblAdminName.Text = !string.IsNullOrEmpty(adminDetails.AdminName) ? adminDetails.AdminName : "Admin";
            imgAdminProfile.ImageUrl = !string.IsNullOrEmpty(adminDetails.ImageUrl) ? adminDetails.ImageUrl : "~/images/default-profile.png";

            LoadProductsDropdown();
        }
    }

    // Fetch admin details from the database
    private AdminDetails GetAdminDetails(string email)
    {
        AdminDetails adminDetails = new AdminDetails { AdminName = "Admin", ImageUrl = "" };

        try
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string query = "SELECT name, image FROM admins WHERE email = @Email";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Email", email);
                    conn.Open();

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            adminDetails.AdminName = reader["name"].ToString();
                            adminDetails.ImageUrl = reader["image"] != DBNull.Value ? reader["image"].ToString() : "";
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine("Database Error: " + ex.Message);
        }

        return adminDetails;
    }

    // Load products in dropdown
    private void LoadProductsDropdown()
    {
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            string query = "SELECT Product_ID, Product_Name FROM Products";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                conn.Open();
                ddlProducts.DataSource = cmd.ExecuteReader();
                ddlProducts.DataTextField = "Product_Name";
                ddlProducts.DataValueField = "Product_ID";
                ddlProducts.DataBind();
            }
        }
        ddlProducts.Items.Insert(0, new ListItem("-- Select a Product --", ""));
    }

    protected void ddlProducts_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (!string.IsNullOrEmpty(ddlProducts.SelectedValue))
        {
            FetchProductDetails(ddlProducts.SelectedValue);
        }
    }

    // Fetch selected product details
    private void FetchProductDetails(string productID)
    {
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            string query = "SELECT * FROM Products WHERE Product_ID = @ProductID";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@ProductID", productID);
                conn.Open();

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        txtProductID.Text = reader["Product_ID"].ToString();
                        txtProductName.Text = reader["Product_Name"].ToString();
                        txtPrice.Text = reader["Price"].ToString();
                        txtStock.Text = reader["Stock"].ToString();
                        //  txtShelfLife.Text = reader["ShelfLife"].ToString();
                        txtDescription.Text = reader["Description"].ToString();
                        //txtIngredients.Text = reader["Ingredients"].ToString();
                        ddlCategory.SelectedValue = reader["Category"].ToString();
                        imgProduct.ImageUrl = reader["Image"] != DBNull.Value ? reader["Image"].ToString() : "Images/default.png";
                    }
                }
            }
        }
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        string imagePath = UploadProductImage();

        using (SqlConnection conn = new SqlConnection(connStr))
        {
            string query = "INSERT INTO Products (Product_ID, Product_Name, Price, Stock, Description, Category, Image ) " +
                           "VALUES (@id, @Name, @Price, @Stock,  @Desc, @Category, @Image )";

            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@id", txtProductID.Text);
                cmd.Parameters.AddWithValue("@Name", txtProductName.Text);
                cmd.Parameters.AddWithValue("@Price", txtPrice.Text);
                cmd.Parameters.AddWithValue("@Stock", txtStock.Text);
                // cmd.Parameters.AddWithValue("@ShelfLife", txtShelfLife.Text);
                cmd.Parameters.AddWithValue("@Desc", txtDescription.Text);
                // cmd.Parameters.AddWithValue("@Ingredients", txtIngredients.Text);
                cmd.Parameters.AddWithValue("@Category", ddlCategory.SelectedValue);
                cmd.Parameters.AddWithValue("@Image", imagePath);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        LoadProductsDropdown();
        ShowAlert("Product Added Successfully!");
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            string query = "UPDATE Products SET Product_Name=@Name, Price=@Price, Stock=@Stock, Description=@Desc, Category=@Category WHERE Product_ID=@id";

            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@id", txtProductID.Text);
                cmd.Parameters.AddWithValue("@Name", txtProductName.Text);
                cmd.Parameters.AddWithValue("@Price", txtPrice.Text);
                cmd.Parameters.AddWithValue("@Stock", txtStock.Text);
                // cmd.Parameters.AddWithValue("@ShelfLife", txtShelfLife.Text);
                cmd.Parameters.AddWithValue("@Desc", txtDescription.Text);
                //  cmd.Parameters.AddWithValue("@Ingredients", txtIngredients.Text);
                cmd.Parameters.AddWithValue("@Category", ddlCategory.SelectedValue);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        LoadProductsDropdown();
        ShowAlert("Product Updated Successfully!");
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            string query = "DELETE FROM Products WHERE Product_ID=@id";

            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@id", txtProductID.Text);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        LoadProductsDropdown();
        ShowAlert("Product Deleted Successfully!");
    }

    protected void btnClear_Click(object sender, EventArgs e)
    {
        txtProductID.Text = "";
        txtProductName.Text = "";
        txtPrice.Text = "";
        txtStock.Text = "";
        //   txtShelfLife.Text = "";
        txtDescription.Text = "";
        // txtIngredients.Text = "";
        ddlCategory.SelectedIndex = 0;
        imgProduct.ImageUrl = "Images/default.png";
    }

    private string UploadProductImage()
    {
        string imagePath = "Images/default.png";

        if (fileUploadImage.HasFile)
        {
            string folderPath = Server.MapPath("~/Images/");
            if (!Directory.Exists(folderPath))
            {
                Directory.CreateDirectory(folderPath);
            }

            string fileName = Path.GetFileName(fileUploadImage.FileName);
            string filePath = folderPath + fileName;
            fileUploadImage.SaveAs(filePath);
            imagePath = "Images/" + fileName;
        }

        return imagePath;
    }

    private void ShowAlert(string message)
    {
        ClientScript.RegisterStartupScript(this.GetType(), "alert", string.Format("alert('{0}');", message), true);
    }


    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Redirect("AdminLogin.aspx");
    }
}
