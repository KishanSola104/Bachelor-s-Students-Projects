﻿using System;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;

public partial class Details : Page
{
    string connString = ConfigurationManager.ConnectionStrings["22BCA103"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request.QueryString["ID"] != null)
            {
                int productId;
                if (int.TryParse(Request.QueryString["ID"], out productId))
                {
                    LoadProductDetails(productId);
                    btnAddToCart.CommandArgument = productId.ToString(); // Store Product ID in button
                }
                else
                {
                    Response.Write("<script>alert('Invalid Product ID.');</script>");
                    Response.Redirect("UserDashboard.aspx");
                }
            }
            else
            {
                Response.Redirect("UserDashboard.aspx");
            }
        }
    }

    private void LoadProductDetails(int productId)
    {
        using (SqlConnection con = new SqlConnection(connString))
        {
            string query = "SELECT Product_Name, Image, Price, Description, Category FROM Products WHERE Product_ID = @ProductID";
            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                cmd.Parameters.AddWithValue("@ProductID", productId);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    lblProductName.Text = dr["Product_Name"].ToString();
                    imgProduct.ImageUrl = dr["Image"].ToString();
                    lblPrice.Text = "₹" + Convert.ToDecimal(dr["Price"]).ToString("N2");
                    lblDescription.Text = dr["Description"].ToString();
                    lblCategory.Text = dr["Category"].ToString();
                }
                else
                {
                    Response.Write("<script>alert('Product not found.');</script>");
                    Response.Redirect("UserDashboard.aspx");
                }
            }
        }
    }

    protected void btnAddToCart_Click(object sender, EventArgs e)
    {
        if (Session["UserEmail"] == null)
        {
            Response.Redirect("login.aspx");
            return;
        }

        // Get User Email from Session
        string userEmail = Session["UserEmail"].ToString();

        // Get Product ID from the Button Command Argument
        Button btn = (Button)sender;
        int productId;
        if (!int.TryParse(btn.CommandArgument, out productId))
        {
            Response.Write("<script>alert('Invalid Product ID');</script>");
            return;
        }

        // Get Product Price from the Label and Convert it to Decimal
        decimal productPrice;
        if (!decimal.TryParse(lblPrice.Text.Replace("₹", "").Trim(), out productPrice))
        {
            Response.Write("<script>alert('Invalid Product Price');</script>");
            return;
        }

        // Get Product Name and Image
        string productName = lblProductName.Text;
        string productImage = imgProduct.ImageUrl;

        using (SqlConnection con = new SqlConnection(connString))
        {
            try
            {
                con.Open();

                // Check if the product is already in the cart
                string checkQuery = "SELECT COUNT(*) FROM Cart WHERE UserEmail = @UserEmail AND ProductID = @ProductID";
                using (SqlCommand cmd = new SqlCommand(checkQuery, con))
                {
                    cmd.Parameters.AddWithValue("@UserEmail", userEmail);
                    cmd.Parameters.AddWithValue("@ProductID", productId);
                    int count = (int)cmd.ExecuteScalar();

                    if (count > 0)
                    {
                        // If the product exists, increase quantity
                        string updateQuery = "UPDATE Cart SET Quantity = Quantity + 1 WHERE UserEmail = @UserEmail AND ProductID = @ProductID";
                        using (SqlCommand updateCmd = new SqlCommand(updateQuery, con))
                        {
                            updateCmd.Parameters.AddWithValue("@UserEmail", userEmail);
                            updateCmd.Parameters.AddWithValue("@ProductID", productId);
                            updateCmd.ExecuteNonQuery();
                        }
                    }
                    else
                    {
                        // If the product is new, insert into cart
                        string insertQuery = "INSERT INTO Cart (UserEmail, ProductID, ProductName, ProductImage, ProductPrice, Quantity, DateAdded) VALUES (@UserEmail, @ProductID, @ProductName, @ProductImage, @ProductPrice, @Quantity, GETDATE())";
                        using (SqlCommand insertCmd = new SqlCommand(insertQuery, con))
                        {
                            insertCmd.Parameters.AddWithValue("@UserEmail", userEmail);
                            insertCmd.Parameters.AddWithValue("@ProductID", productId);
                            insertCmd.Parameters.AddWithValue("@ProductName", productName);
                            insertCmd.Parameters.AddWithValue("@ProductImage", productImage);
                            insertCmd.Parameters.AddWithValue("@ProductPrice", productPrice);
                            insertCmd.Parameters.AddWithValue("@Quantity", 1);
                            insertCmd.ExecuteNonQuery();
                        }
                    }
                }

                // Show success message
                Response.Write("<script>alert('Product added to cart successfully!');</script>");
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('Error: " + ex.Message + "');</script>");
            }
        }
    }


    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("UserDashboard.aspx");
    }
}
