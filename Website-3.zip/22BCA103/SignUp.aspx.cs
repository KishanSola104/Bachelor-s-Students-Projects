﻿using System;
using System.Data.SqlClient;
using System.Configuration;

public partial class SignUp : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void btnSignUp_Click(object sender, EventArgs e)
    {
        try
        {
            // Connection String from Web.config
            string connString = ConfigurationManager.ConnectionStrings["22BCA103"].ConnectionString;

            using (SqlConnection con = new SqlConnection(connString))
            {
                con.Open();

                // Insert Query
                string query = "INSERT INTO Users (email, name, dob, password, city, address, mobile, pincode, gender) " +
                               "VALUES (@Email, @Name, @DOB, @Password, @City, @Address, @Mobile, @Pincode, @Gender)";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                    cmd.Parameters.AddWithValue("@Name", txtName.Text);
                    cmd.Parameters.AddWithValue("@DOB", txtDOB.Text);
                    cmd.Parameters.AddWithValue("@Password", txtPassword.Text);
                    cmd.Parameters.AddWithValue("@City", ddlCity.SelectedValue);
                    cmd.Parameters.AddWithValue("@Address", txtAddress.Text);
                    cmd.Parameters.AddWithValue("@Mobile", txtMobile.Text);
                    cmd.Parameters.AddWithValue("@Pincode", txtPincode.Text);

                    // Gender Selection
                    string gender = rbMale.Checked ? "Male" : rbFemale.Checked ? "Female" : "Other";
                    cmd.Parameters.AddWithValue("@Gender", gender);

                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        lblMessage.ForeColor = System.Drawing.Color.Green;
                        lblMessage.Text = "Sign Up Successful!";
                        Response.Redirect("login.aspx");
                    }
                    else
                    {
                        lblMessage.Text = "Error: Data not inserted!";
                    }
                }
            }
        }
        catch (Exception ex)
        {
            lblMessage.Text = "Database Error: " + ex.Message;
        }
    }
}
