﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="login.aspx.cs" Inherits="login" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
<title>User Login</title>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f3f4f7;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            overflow: hidden;
        }

        .container {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            width: 400px;
            text-align: center;
            animation: slideIn 1s ease-out, fadeIn 1s ease-in;
        }

        @keyframes slideIn {
            from {
                transform: translateY(-30px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        h1 {
            font-size: 24px;
            font-weight: 600;
            color: #333;
            margin-bottom: 20px;
            animation: fadeIn 1s ease-out;
        }

        .logo {
            font-size: 30px;
            font-weight: 700;
            color: #2c3e50;
            margin-bottom: 30px;
            animation: fadeIn 1.5s ease-out;
            color:Orange;
        }

        .input {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 16px;
            background-color: #f9f9f9;
            outline: none;
            transition: all 0.3s ease;
            animation: fadeIn 2s ease-out;
        }

        .input:focus {
            border-color: #2980b9;
            background-color: #fff;
            transform: scale(1.02);
        }

        .button {
            width: 100%;
            padding: 14px;
            background-color: #2980b9;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 18px;
            cursor: pointer;
            transition: 0.3s;
            animation: fadeIn 2.5s ease-out;
        }

        .button:hover {
            background-color: #3498db;
            transform: translateY(-3px);
        }

        .forgot-password {
            display: block;
            margin-top: 10px;
            font-size: 14px;
            color: #555;
            animation: fadeIn 3s ease-out;
        }

        .forgot-password a {
            color: #2980b9;
            text-decoration: none;
            font-weight: bold;
        }

        .forgot-password a:hover {
            text-decoration: underline;
        }

        .signup {
            margin-top: 20px;
            font-size: 14px;
            color: #555;
        }

        .signup a {
            color: #2980b9;
            text-decoration: none;
            font-weight: bold;
        }

        .signup a:hover {
            text-decoration: underline;
        }

    </style>
</head>
<body>
    <form id="loginForm" runat="server">
        <div class="container">
            <div class="logo">TechGear Hub</div>
            <h1>Login</h1>
            <asp:TextBox ID="txtEmail" runat="server" CssClass="input" placeholder="Enter your email" Required="true"></asp:TextBox>
            <asp:TextBox ID="txtPassword" runat="server" CssClass="input" TextMode="Password" placeholder="Enter your password" Required="true"></asp:TextBox>
            <asp:Button ID="btnLogin" runat="server" Text="Login" CssClass="button" 
                onclick="btnLogin_Click"  />
            <asp:RegularExpressionValidator ID="RegularExpressionValidator1" runat="server" 
                ControlToValidate="txtEmail" ErrorMessage="Enter An Valid Email" 
                ForeColor="Red" 
                ValidationExpression="\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*"></asp:RegularExpressionValidator>
           
            <p class="forgot-password">
                <asp:Label ID="Label1" runat="server"></asp:Label>
            </p>
            <p class="signup">New here? <a href="SignUp.aspx">Sign Up</a></p>
        </div>
    </form>
</body>
</html>
