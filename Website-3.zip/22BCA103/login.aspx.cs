﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.UI;

public partial class login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label1.Visible = false; // Hide error message on page load
    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        if (string.IsNullOrEmpty(txtEmail.Text) || string.IsNullOrEmpty(txtPassword.Text))
        {
            Label1.Text = "Please enter both fields.";
            Label1.ForeColor = System.Drawing.Color.Red;
            Label1.Visible = true;
            return;
        }

        // Trim input to remove leading/trailing spaces
        string email = txtEmail.Text.Trim().ToLower(); // Convert email to lowercase
        string password = txtPassword.Text.Trim();     // Keep password case-sensitive (optional)

        if (email.Equals("admin@gmail.com", StringComparison.OrdinalIgnoreCase) && password.Equals("admin"))
        {
            Response.Redirect("AdminLogin.aspx");
        }
        else
        {
            // Validate user from database
            string connStr = ConfigurationManager.ConnectionStrings["22BCA103"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT COUNT(*) FROM Users WHERE email=@Email AND password=@Password";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Email", email);
                        cmd.Parameters.AddWithValue("@Password", password);

                        int userCount = Convert.ToInt32(cmd.ExecuteScalar());

                        if (userCount > 0)
                        {
                            // Store email in session and redirect to User Dashboard
                            Session["UserEmail"] = email;
                            Response.Redirect("UserDashboard.aspx");
                        }
                        else
                        {
                            Label1.Text = "Invalid email or password.";
                            Label1.ForeColor = System.Drawing.Color.Red;
                            Label1.Visible = true;
                        }
                    }
                }
                catch (Exception ex)
                {
                    Label1.Text = "Error: " + ex.Message;
                    Label1.ForeColor = System.Drawing.Color.Red;
                    Label1.Visible = true;
                }
            }
        }
    }
}
