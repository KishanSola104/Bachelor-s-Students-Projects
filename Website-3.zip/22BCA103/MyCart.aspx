﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="MyCart.aspx.cs" Inherits="MyCart" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>My Cart</title>

<style>
body {
    font-family: Arial, sans-serif;
    background-color: #f5f5f5;
}

.cart-container {
    width: 80%;
    margin: auto;
    background: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
}

h2 {
    text-align: center;
    color: #333;
}

.cart-table {
    width: 100%;
    border-collapse: collapse;
}

.cart-table th, .cart-table td {
    padding: 10px;
    border-bottom: 1px solid #ddd;
    text-align: center;
}

.cart-image {
    width: 50px;
    height: 50px;
    border-radius: 5px;
}

.qty-box {
    width: 50px;
    text-align: center;
}

.btn-update, .btn-remove, .btn-checkout {
    padding: 5px 10px;
    border: none;
    cursor: pointer;
    border-radius: 5px;
    color: white;
}

.btn-update {
    background-color: #4CAF50;
}

.btn-remove {
    background-color: #FF5733;
}

.btn-checkout {
    background-color: #007BFF;
    padding: 10px 20px;
    display: block;
    width: 100%;
    text-align: center;
    font-size: 16px;
}

.btn-update:hover, .btn-remove:hover, .btn-checkout:hover {
    opacity: 0.8;
}

.cart-footer {
    text-align: right;
    margin-top: 20px;
}

.total-price {
    font-size: 20px;
    font-weight: bold;
    color: #333;
}

</style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="cart-container">
            <h2>My Shopping Cart</h2>
            
            <asp:GridView ID="gvCart" runat="server" AutoGenerateColumns="False" CssClass="cart-table"
                OnRowCommand="gvCart_RowCommand">
                <Columns>
                    <asp:TemplateField HeaderText="Image">
                        <ItemTemplate>
                            <img src='<%# Eval("ProductImage") %>' alt="Product Image" class="cart-image" />
                        </ItemTemplate>
                    </asp:TemplateField>

                    <asp:BoundField DataField="ProductName" HeaderText="Product Name" />
                    <asp:BoundField DataField="ProductPrice" HeaderText="Price" DataFormatString="{0:C}" />

                    <asp:TemplateField HeaderText="Quantity">
                        <ItemTemplate>
                            <asp:TextBox ID="txtQuantity" runat="server" Text='<%# Eval("Quantity") %>' CssClass="qty-box"></asp:TextBox>
                            <asp:Button ID="btnUpdate" runat="server" CommandName="UpdateQuantity" CommandArgument='<%# Eval("ProductID") %>' Text="Update" CssClass="btn-update" />
                        </ItemTemplate>
                    </asp:TemplateField>

                    <asp:TemplateField HeaderText="Remove">
                        <ItemTemplate>
                            <asp:Button ID="btnRemove" runat="server" CommandName="RemoveItem" CommandArgument='<%# Eval("ProductID") %>' Text="Remove" CssClass="btn-remove" />
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>
            </asp:GridView>

            <div class="cart-footer">
                <h3>Total Price: <asp:Label ID="lblTotalPrice" runat="server" CssClass="total-price"></asp:Label></h3>
                <asp:Button ID="btnCheckout" runat="server" Text="Proceed to Checkout" CssClass="btn-checkout" OnClick="btnCheckout_Click" />
            </div>
        </div>
    </form>
</body>
</html>
