﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="orders.aspx.cs" Inherits="orders" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
   <title>Admin Dashboard </title>

    <style>
        /* General Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        /* Admin Header Styling */
        .admin-header {
            background-color: orange;
            color: white;
            font-size: large;
            font-weight: bold;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 100; /* Keeps the header above the sidebar */
            position: fixed;
            width: 100%;
            top: 0;
        }

        .admin-info {
            display: flex;
            align-items: center;
        }

        .admin-profile-img {
            border-radius: 50%;
            border: 2px solid #fff;
            object-fit: cover;
            margin-left: 10px;
        }

        .logout-btn {
            margin-left: 15px;
            background-color: #f44336;
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
        }

        .logout-btn:hover {
            background-color: #d32f2f;
        }

        /* Main Content */
        .main-content {
            margin-left: 200px; /* Adjusted for sidebar width */
            padding: 20px;
            transition: margin-left 0.3s;
            margin-top: 60px; /* To account for header height */
        }

        /* Footer Styling */
        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px;
            position: fixed;
            width: 100%;
            bottom: 0;
        }

        /* Sidebar Styling */
        .sidebar {
            width: 180px; /* Reduced width */
            background: #222;
            color: white;
            padding: 15px;
            position: fixed;
            height: 100%;
            transition: 0.3s ease-in-out;
        }

        .sidebar a {
            display: flex;
            align-items: center;
            color: white;
            padding: 12px;
            font-size: 14px;
            text-decoration: none;
            transition: background 0.3s ease-in-out;
        }

        .sidebar a i {
            margin-right: 10px;
            font-size: 16px;
        }

        .sidebar a:hover {
            background: #333;
            border-radius: 5px;
        }

        /* Settings Dropdown */
        .settings {
            margin-top: 10px;
        }

        .settings a {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .dropdown {
            display: none;
            background: #333;
            padding: 5px;
            border-radius: 5px;
            flex-direction: column;
        }

        .dropdown a {
            padding: 8px 15px;
            font-size: 13px;
            display: flex;
            align-items: center;
            gap: 10px;
            transition: 0.3s;
        }

        .dropdown a:hover {
            background: #444;
        }

        .settings .fa-chevron-down {
            transition: transform 0.3s ease;
        }

        .settings.open .fa-chevron-down {
            transform: rotate(180deg);
        }
    </style>
</head>
<body>

    <form id="adminDashboardForm" runat="server">
        <!-- Header Section -->
        <header class="admin-header">
            <div class="logo">TechGear Hub</div>
            <div class="admin-info">
                <span>Welcome, <asp:Label ID="lblAdminName" runat="server" Text="Admin"></asp:Label></span>
                <asp:Image ID="imgAdminProfile" runat="server" CssClass="admin-profile-img" Width="40px" Height="40px" />
                <asp:Button ID="btnLogout" runat="server" Text="Logout" CssClass="logout-btn"  />
            </div>
        </header>

        <!-- Sidebar Section -->
        <div class="sidebar">
            <a href="AdminDashboard.aspx"><i class="fas fa-home"></i>Dashboard</a>
           <a href="ManageProducts.aspx"><i class="fas fa-box"></i> Products</a>

            <a href="orders.aspx"><i class="fas fa-shopping-cart"></i> Orders</a>
            <a href="customers.aspx"><i class="fas fa-users"></i> Customers</a>

            <div class="settings">
                <a href="#" id="settings-btn"><i class="fas fa-cogs"></i> Settings <i class="fas fa-chevron-down"></i></a>
                <div class="dropdown" id="settings-dropdown">
                    <a href="AdminAccount.aspx"><i class="fas fa-user"></i> My Account</a>
                    <a href="AdminResetPassword.aspx"><i class="fas fa-key"></i> Reset Password</a>
                   
                    <a href="AdminLogin.aspx"><i class="fas fa-sign-out-alt"></i> Log Out</a>
                </div>
            </div>
        </div>

        <!-- Main Content Section -->
        <div class="main-content">
            <h2>Welcome to Admin Dashboard</h2>
            <p>This is the main content area where you can manage all your items.</p>
            <!-- Your main content goes here -->
        </div>

        <!-- Footer Section -->
        <footer>
            <p>© 2025 TechGera Hub . All Rights Reserved.</p>
        </footer>

    </form>

    <!-- JavaScript for Settings Dropdown -->
    <script>
        document.getElementById('settings-btn').addEventListener('click', function (event) {
            event.preventDefault();
            var dropdown = document.getElementById('settings-dropdown');
            var settings = document.querySelector('.settings');

            dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
            settings.classList.toggle('open');
        });
    </script>
</body>
</html>
