﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="AdminLogin.aspx.cs" Inherits="AdminLogin" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
   <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap');
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f6f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            width: 400px;
            text-align: center;
        }
        h1 {
            font-size: 24px;
            font-weight: 600;
            color: #333;
            margin-bottom: 20px;
        }
        .logo {
            font-size: 30px;
            font-weight: 700;
            color: orange;
            margin-bottom: 30px;
        }
        .input {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 16px;
            background-color: #f9f9f9;
            outline: none;
        }
        .button {
            width: 100%;
            padding: 14px;
            background-color: #2980b9;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 18px;
            cursor: pointer;
            transition: 0.3s;
        }
        .button:hover {
            background-color: #3498db;
        }
        .forgot-password {
            margin-top: 10px;
            font-size: 14px;
            color: #555;
        }
        .forgot-password a {
            color: #2980b9;
            text-decoration: none;
            font-weight: bold;
        }
        .forgot-password a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <form id="adminLoginForm" runat="server">
        <div class="container">
            <div class="logo">TechGear Hub</div>
            <h1>Admin Login</h1>
            <asp:TextBox ID="txtAdminEmail" runat="server" CssClass="input" TextMode="Email" placeholder="Enter Admin Email" Required="true"></asp:TextBox>
            <asp:TextBox ID="txtAdminPassword" runat="server" CssClass="input" TextMode="Password" placeholder="Enter Admin Password" Required="true"></asp:TextBox>
            
            <p class="forgot-password"><asp:Button 
                    ID="btnAdminLogin" runat="server" Text="Login" CssClass="button" 
                    onclick="btnAdminLogin_Click"  />
                    <a href="AdminForgotPassword.aspx">Forgot Password?</a></p>
            <p class="forgot-password">&nbsp;<asp:Label ID="Label1" runat="server"></asp:Label>
            </p>
        </div>
    </form>
</body>
</html>