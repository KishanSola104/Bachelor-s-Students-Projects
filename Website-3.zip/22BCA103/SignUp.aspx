﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="SignUp.aspx.cs" Inherits="SignUp" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
     <title>Sign Up</title>
    <style>
      body {
    font-family: Arial, sans-serif;
    background-color: #f8f9fa;
    margin: 0;
    padding: 0;
}

.container {
    width: 400px;
    background: white;
    padding: 20px;
    margin: 50px auto;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    border-radius: 10px;
    text-align: center;
}

h2 {
    color: #d9534f;
    margin-bottom: 20px;
}

label {
    font-weight: bold;
    display: block;
    margin-top: 10px;
    text-align: left;
}

input[type="text"],
input[type="password"],
input[type="date"],
textarea,
select {
    width: 100%;
    padding: 8px;
    margin-top: 5px;
    border: 1px solid #ddd;
    border-radius: 5px;
    font-size: 14px;
}

textarea {
    resize: none;
    height: 60px;
}

.radio-group {
    display: flex;
    justify-content: space-between;
    margin-top: 5px;
}

button, 
input[type="submit"] {
    background-color: #d9534f;
    color: white;
    border: none;
    padding: 10px;
    width: 100%;
    border-radius: 5px;
    font-size: 16px;
    cursor: pointer;
    margin-top: 15px;
}

button:hover {
    background-color: #c9302c;
}

.message {
    margin-top: 10px;
    font-weight: bold;
}

    </style>
</head>
<body>
  <div class="container">
        <h2>Sign Up</h2>
        <form id="form1" runat="server">
            <p>
                <asp:Label ID="lblMessage" runat="server" CssClass="message" ForeColor="Red"></asp:Label>
            </p>
            <label>Email:</label>
            <asp:TextBox ID="txtEmail" runat="server"></asp:TextBox>

            <label>Name:</label>
            <asp:TextBox ID="txtName" runat="server"></asp:TextBox>

            <label>Date of Birth:</label>
            <asp:TextBox ID="txtDOB" runat="server" TextMode="Date"></asp:TextBox>

            <label>Password:</label>
            <asp:TextBox ID="txtPassword" runat="server" TextMode="Password"></asp:TextBox>

            <label>City:</label>
            <asp:DropDownList ID="ddlCity" runat="server">
                <asp:ListItem Text="Anand" Value="Anand"></asp:ListItem>
                <asp:ListItem Text="Vidhya Nagar" Value="Vidhya Nagar"></asp:ListItem>
            </asp:DropDownList>

            <label>Address:</label>
            <asp:TextBox ID="txtAddress" runat="server" TextMode="MultiLine"></asp:TextBox>

            <label>Mobile No:</label>
            <asp:TextBox ID="txtMobile" runat="server"></asp:TextBox>

            <label>Pincode:</label>
            <asp:TextBox ID="txtPincode" runat="server"></asp:TextBox>

            <label>Gender:</label>
            <div class="radio-group">
                <asp:RadioButton ID="rbMale" runat="server" GroupName="Gender" Text="Male" />
                <asp:RadioButton ID="rbFemale" runat="server" GroupName="Gender" Text="Female" />
                <asp:RadioButton ID="rbOther" runat="server" GroupName="Gender" Text="Other" />
            </div>

            <asp:Button ID="btnSignUp" runat="server" Text="Sign Up" OnClick="btnSignUp_Click" />

            <br />
            <asp:HyperLink ID="HyperLink1" runat="server" href="login.aspx">Back To Login</asp:HyperLink>
            <br />

            
        </form>
    </div>
</body>
</html>