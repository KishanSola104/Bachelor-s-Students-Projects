﻿using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI;

public partial class AdminDashboard : Page
{
    string connStr = ConfigurationManager.ConnectionStrings["MilkshakeDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadDashboardStats();
        }
    }

    private void LoadDashboardStats()
    {
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            conn.Open();

            // Fetch Total Milkshakes
            SqlCommand cmdMilkshakes = new SqlCommand("SELECT COUNT(*) FROM Milkshakes", conn);
            lblTotalMilkshakes.Text = cmdMilkshakes.ExecuteScalar().ToString();

            // Fetch Total Customers
            SqlCommand cmdCustomers = new SqlCommand("SELECT COUNT(*) FROM Customers", conn);
            lblTotalCustomers.Text = cmdCustomers.ExecuteScalar().ToString();

            // Fetch Total Orders
            SqlCommand cmdOrders = new SqlCommand("SELECT COUNT(*) FROM Orders", conn);
            lblTotalOrders.Text = cmdOrders.ExecuteScalar().ToString();
        }
    }
    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminLogin.aspx");
    }
}
