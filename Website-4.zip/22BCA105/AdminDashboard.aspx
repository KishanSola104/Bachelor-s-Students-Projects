﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="AdminDashboard.aspx.cs" Inherits="AdminDashboard" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
   
  <title>Admin Dashboard - Frosty Bliss Milkshakes</title>
   
    <style>
    /* General Styles */
body {
    margin: 0;
    font-family: 'Poppins', sans-serif;
    background-color: #fffaf0;
    display:flex;
    align-items:center;
    justify-content:center;
}

/* Dashboard Container */
.dashboard-container {
    text-align: center;
    padding: 15px;
}

/* Navigation Menu */
.nav-menu {
    background: linear-gradient(90deg, #ff6600, #ff3300);
    padding: 15px;
    margin-bottom: 20px;
    width:auto;
    border-radius:10px;
}

.nav-menu ul {
    list-style: none;
    padding: 0;
    margin: 0;
    display: flex;
    justify-content: center;
}

.nav-menu ul li {
    margin: 0 15px;
}

.nav-menu ul li a {
    text-decoration: none;
    color: white;
    font-size: 18px;
    font-weight: bold;
    transition: 0.3s;
}

.nav-menu ul li a:hover {
    color: #ffcc99;
}

/* Dashboard Content */
.dashboard-content {
    background: white;
    padding: 20px;
    box-shadow: 0px 4px 10px rgba(0,0,0,0.2);
    border-radius: 10px;
    max-width: 600px;
    margin: 0 auto;
}

.dashboard-content h2 {
    color: #ff3300;
}

/* Logout Button */
.btn-logout {
    background: #cc0000;
    color: white;
    border: none;
    padding: 10px 20px;
    font-size: 16px;
    cursor: pointer;
    border-radius: 5px;
    transition: 0.3s;
}

.btn-logout:hover {
    background: #ff3300;
}

    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="dashboard-container">
            <h1>Welcome, Admin</h1>
            <div class="nav-menu">
                <ul>
                    
                     <li><a href="AdminDashboard.aspx">Home</a></li>
                    <li><a href="ManageMilkShakes.aspx">Manage MilkShakes</a></li>
                    <li><a href="Orders.aspx">Orders</a></li>
                    <li><a href="Customers.aspx">Customers</a></li>
                  
                    <li><asp:Button ID="btnLogout" runat="server" Text="Logout" CssClass="btn-logout" OnClick="btnLogout_Click" /></li>
                </ul>
            </div>
           <div class="dashboard-content">
    <h2>Dashboard Overview</h2>
    <p>Here you can manage orders, products, and customers.</p>

    <div class="dashboard-stats">
        <div class="stat-box">
            <h3>Total Milkshakes</h3>
            <asp:Label ID="lblTotalMilkshakes" runat="server" CssClass="stat-number"></asp:Label>
        </div>
        <div class="stat-box">
            <h3>Total Customers</h3>
            <asp:Label ID="lblTotalCustomers" runat="server" CssClass="stat-number"></asp:Label>
        </div>
        <div class="stat-box">
            <h3>Total Orders</h3>
            <asp:Label ID="lblTotalOrders" runat="server" CssClass="stat-number"></asp:Label>
        </div>
    </div>
</div>

<style>
    .dashboard-content {
        text-align: center;
        margin: 20px;
    }

    .dashboard-stats {
        display: flex;
        justify-content: center;
        gap: 20px;
        margin-top: 20px;
    }

    .stat-box {
        background: #f8f8f8;
        padding: 20px;
        border-radius: 10px;
        width: 200px;
        text-align: center;
        box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
    }

    .stat-number {
        font-size: 24px;
        font-weight: bold;
        color: #d32f2f;
    }
</style>

        </div>
    </form>
</body>
</html>
