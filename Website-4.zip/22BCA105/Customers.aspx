﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="Customers.aspx.cs" Inherits="Customers" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Customers</title>
  <style>
    /* General Styles */
body {
    margin: 0;
    font-family: 'Poppins', sans-serif;
    background-color: #fffaf0;
    display:flex;
    align-items:center;
    justify-content:center;
}

/* Dashboard Container */
.dashboard-container {
    text-align: center;
    padding: 15px;
}

/* Navigation Menu */
.nav-menu {
    background: linear-gradient(90deg, #ff6600, #ff3300);
    padding: 15px;
    margin-bottom: 20px;
    width:auto;
    border-radius:10px;
}

.nav-menu ul {
    list-style: none;
    padding: 0;
    margin: 0;
    display: flex;
    justify-content: center;
}

.nav-menu ul li {
    margin: 0 15px;
}

.nav-menu ul li a {
    text-decoration: none;
    color: white;
    font-size: 18px;
    font-weight: bold;
    transition: 0.3s;
}

.nav-menu ul li a:hover {
    color: #ffcc99;
}

/* Dashboard Content */
.dashboard-content {
    background: white;
    padding: 20px;
    box-shadow: 0px 4px 10px rgba(0,0,0,0.2);
    border-radius: 10px;
    max-width: 600px;
    margin: 0 auto;
}

.dashboard-content h2 {
    color: #ff3300;
}

/* Logout Button */
.btn-logout {
    background: #cc0000;
    color: white;
    border: none;
    padding: 10px 20px;
    font-size: 16px;
    cursor: pointer;
    border-radius: 5px;
    transition: 0.3s;
}

.btn-logout:hover {
    background: #ff3300;
}

    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="dashboard-container">
            <h1>Welcome, Admin</h1>
            <div class="nav-menu">
                <ul>
                    
                     <li><a href="AdminDashboard.aspx">Home</a></li>
                    <li><a href="ManageMilkShakes.aspx">Manage MilkShakes</a></li>
                    <li><a href="Orders.aspx">Orders</a></li>
                    <li><a href="Customers.aspx">Customers</a></li>
                    
                    <li><asp:Button ID="btnLogout" runat="server" Text="Logout" CssClass="btn-logout" OnClick="btnLogout_Click" /></li>
                </ul>
            </div>
            <div class="dashboard-content">
               
                <asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False" 
                    BackColor="#DEBA84" BorderColor="#DEBA84" BorderStyle="None" BorderWidth="1px" 
                    CellPadding="3" CellSpacing="2" DataKeyNames="FullName" 
                    DataSourceID="SqlDataSource1">
                    <Columns>
                        <asp:BoundField DataField="FullName" HeaderText="FullName" ReadOnly="True" 
                            SortExpression="FullName" />
                        <asp:BoundField DataField="Email" HeaderText="Email" SortExpression="Email" />
                        <asp:BoundField DataField="MobileNo" HeaderText="MobileNo" 
                            SortExpression="MobileNo" />
                        <asp:BoundField DataField="City" HeaderText="City" SortExpression="City" />
                        <asp:BoundField DataField="FullAddress" HeaderText="FullAddress" 
                            SortExpression="FullAddress" />
                    </Columns>
                    <FooterStyle BackColor="#F7DFB5" ForeColor="#8C4510" />
                    <HeaderStyle BackColor="#A55129" Font-Bold="True" ForeColor="White" />
                    <PagerStyle ForeColor="#8C4510" HorizontalAlign="Center" />
                    <RowStyle BackColor="#FFF7E7" ForeColor="#8C4510" />
                    <SelectedRowStyle BackColor="#738A9C" Font-Bold="True" ForeColor="White" />
                    <SortedAscendingCellStyle BackColor="#FFF1D4" />
                    <SortedAscendingHeaderStyle BackColor="#B95C30" />
                    <SortedDescendingCellStyle BackColor="#F1E5CE" />
                    <SortedDescendingHeaderStyle BackColor="#93451F" />
                </asp:GridView>
                <asp:SqlDataSource ID="SqlDataSource1" runat="server" 
                    ConnectionString="<%$ ConnectionStrings:MilkshakeDB %>" 
                    SelectCommand="SELECT [FullName], [Email], [MobileNo], [City], [FullAddress] FROM [Customers]">
                </asp:SqlDataSource>
               
            </div>
        </div>
    </form>
</body>
</html>
