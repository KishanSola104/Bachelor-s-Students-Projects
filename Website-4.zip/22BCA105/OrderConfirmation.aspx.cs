﻿using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI;

public partial class OrderConfirmation : Page
{
    string connStr = ConfigurationManager.ConnectionStrings["MilkshakeDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["CustomerEmail"] == null)
            {
                Response.Redirect("CustomerLogin.aspx");
                return;
            }

            if (!IsPostBack)
            {
                LoadOrderDetails();
            }
        }
        catch (Exception ex)
        {
            LogError("Page_Load", ex);
            ShowErrorMessage("An unexpected error occurred while loading the order confirmation page.");
        }
    }

    private void LoadOrderDetails()
    {
        try
        {
            string customerEmail = Session["CustomerEmail"].ToString();

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string query = @"
                    SELECT TOP 1 O.TotalAmount, O.ShippingAddress, O.City, O.OrderDate, C.FullName
                    FROM Orders O
                    INNER JOIN Customers C ON O.CustomerEmail = C.Email
                    WHERE O.CustomerEmail = @CustomerEmail
                    ORDER BY O.OrderDate DESC";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@CustomerEmail", customerEmail);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    lblCustomerEmail.Text = customerEmail;
                    lblCustomerName.Text = reader["FullName"].ToString();
                    lblAddress.Text = reader["ShippingAddress"].ToString();
                    lblCity.Text = reader["City"].ToString();
                    lblOrderDate.Text = Convert.ToDateTime(reader["OrderDate"]).ToString("dd MMM yyyy");
                    lblTotalAmount.Text = "₹" + reader["TotalAmount"].ToString();
                }
                else
                {
                    ShowErrorMessage("No recent orders found.");
                }
            }

            // Fetch purchased milkshakes
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string query = @"
                    SELECT M.Name, M.Price 
                    FROM Cart C 
                    INNER JOIN Milkshakes M ON C.MilkshakeID = M.MilkshakeID
                    WHERE C.CustomerEmail = @CustomerEmail";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@CustomerEmail", customerEmail);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                string orderItems = "";
                while (reader.Read())
                {
                    string milkshakeName = reader["Name"].ToString();
                    decimal price = Convert.ToDecimal(reader["Price"]);
                    orderItems += string.Format("<tr><td>{0}</td><td>₹{1}</td></tr>", milkshakeName, price);
                }

                if (string.IsNullOrEmpty(orderItems))
                {
                    orderItems = "<tr><td colspan='2'>No items found in the cart.</td></tr>";
                }

                ltOrderItems.Text = orderItems;
            }
        }
        catch (Exception ex)
        {
            LogError("LoadOrderDetails", ex);
            ShowErrorMessage("An error occurred while loading your order details.");
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            Response.Redirect("UserDashboard.aspx");
        }
        catch (Exception ex)
        {
            LogError("Button1_Click", ex);
            ShowErrorMessage("An error occurred while redirecting to the dashboard.");
        }
    }

    private void LogError(string functionName, Exception ex)
    {
        // Simple logging for debugging purposes
        System.Diagnostics.Debug.WriteLine("Error in " + functionName + ": " + ex.Message);
    }

    private void ShowErrorMessage(string message)
    {
        lblErrorMessage.Text = message;
        lblErrorMessage.Visible = true;
    }
}
