﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="Checkout.aspx.cs" Inherits="Checkout" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
   <title>Frosty Bliss - Check Out </title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #ffe5ec;
        }
        .header {
            background-color: #ff4d6d;
            color: white;
            padding: 15px;
            text-align: left;
            font-size: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .menu {
            display: flex;
            gap: 20px;
        }
        .menu a {
            color: white;
            text-decoration: none;
            font-size: 18px;
            font-weight: bold;
        }
     
        .milkshake-container {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            padding: 20px;
        }
        .milkshake-card {
            background: white;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
            text-align: center;
        }
        .milkshake-card img {
            width: 100%;
            height: 150px;
            border-radius: 8px;
        }
        .btn-add {
            background-color: #d63384;
            color: white;
            border: none;
            padding: 8px 12px;
            cursor: pointer;
            border-radius: 5px;
            font-size: 14px;
        }
        .btn-add:hover {
            background-color: #c2185b;
        }
        .footer {
            background-color: #d63384;
            color: white;
            text-align: center;
            padding: 15px;
            font-size: 16px;
            position: relative;
            bottom: 0;
            width: 100%;
        }
    </style>

     <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #ffe5ec;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 50%;
            margin: 50px auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
            height:70vh;
        }
        h2 {
            text-align: center;
            color: #d63384;
        }
        label {
            display: block;
            font-weight: bold;
            margin: 10px 0 5px;
        }
        .input-box {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
        }
        .dropdown {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
            background-color: white;
        }
        .btn-place-order {
            display: block;
            width: 100%;
            background-color: #d63384;
            color: white;
            padding: 10px;
            text-align: center;
            border-radius: 5px;
            font-size: 16px;
            margin-top: 10px;
            cursor: pointer;
            border: none;
        }
        .btn-place-order:hover {
            background-color: #c2185b;
        }
    </style>
</head>
<body>
  

<form id="form1" runat="server">
    <div class="header">
        <span>Welcome, <asp:Label ID="lblCustomerName" runat="server"></asp:Label></span>
        <div class="menu">
            <a href="UserDashboard.aspx">Home</a>
            <a href="Milkshakes.aspx">Milkshakes</a>
            <a href="MyCart.aspx">My Cart</a>
            <a href="CustomerLogin.aspx">Log Out</a>
        </div>
    </div>

    <div class="container">
            <h2>Checkout</h2>
            <p>
                <asp:Label ID="lblErrorMessage" runat="server"></asp:Label>
            </p>

            <label>Shipping Address:</label>
            <asp:TextBox ID="txtAddress" runat="server" CssClass="input-box" required></asp:TextBox>

            <label>City:</label>
            <asp:DropDownList ID="ddlCity" runat="server" CssClass="dropdown">
                <asp:ListItem Value="Anand">Anand</asp:ListItem>
                <asp:ListItem Value="Vidhya Nagar">Vidhya Nagar</asp:ListItem>
            </asp:DropDownList>

            <div class="order-summary">
                <h3>Order Summary</h3>
                <asp:Literal ID="ltOrderSummary" runat="server"></asp:Literal>
                <p><b>Total Amount:</b> ₹<asp:Label ID="lblTotalAmount" runat="server" ForeColor="Green"></asp:Label></p>
            </div>

            <asp:Button ID="btnPlaceOrder" runat="server" Text="Place Order" CssClass="btn-place-order" OnClick="btnPlaceOrder_Click" />
        </div>

    <div class="footer">
        &copy; 2025 Frosty Bliss Milkshakes | Enjoy the Best Milkshakes in Town!
    </div>
</form>

