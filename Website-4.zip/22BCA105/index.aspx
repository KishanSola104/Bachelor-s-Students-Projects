﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="index.aspx.cs" Inherits="index" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
<style>
   body {
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background-color: #fffaf0;
        }
        .header {
            background: linear-gradient(90deg, #ff6600, #ff3300);
            color: white;
            padding: 20px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 26px;
            font-weight: bold;
        }
        .login-dropdown {
            position: relative;
            cursor: pointer;
            font-size: 18px;
            margin-right:50px;
        }
        .dropdown-content {
            display: none;
            position: absolute;
            background: white;
            min-width: 120px;
            box-shadow: 0px 4px 10px rgba(0,0,0,0.2);
            border-radius: 5px;
            overflow: hidden;
            z-index: 10;
        }
        .dropdown-content a {
            display: block;
            padding: 12px 15px;
            color: #333;
            text-decoration: none;
            transition: 0.3s;
        }
        .dropdown-content a:hover {
            background: #ff9966;
            color: white;
        }
        .login-dropdown:hover .dropdown-content {
            display: block;
        }
        .content {
            position: relative;
            text-align: center;
            height:80vh;
        }
        .content img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            filter: brightness(80%);
        }
        .welcome-text {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: white;
            font-size: 36px;
            font-weight: bold;
            background: rgba(0, 0, 0, 0.5);
            padding: 20px 30px;
            border-radius: 12px;
        }
        .footer {
            background: #222;
            color: white;
            text-align: center;
            padding: 20px;
            font-size: 16px;
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="header">
            <div>Frosty Bliss Milkshakes</div>
            <div class="login-dropdown">
                Login
                <div class="dropdown-content">
                    <a href="AdminLogin.aspx">Admin</a>
                    <a href="CustomerLogin.aspx">Customer</a>
                </div>
            </div>
        </div>
        <div class="content">
            <img src="Images/image2.jpg" alt="Welcome Image">
            <div class="welcome-text">Welcome to Frosty Bliss Milkshakes! Refresh your day with a delicious shake!</div>
        </div>
        <div class="footer">
            <p>Contact Us: +91 9876543210 | Email: support@frostybliss.com</p>
            <p>Address: DNICA ,  MB Patel Science College, Sardar Gunj , Anand, India</p>
        </div>
    </form>
</body>
</html>
