﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Web.UI.WebControls;

public partial class ManageMilkShakes : System.Web.UI.Page
{
    string connectionString = ConfigurationManager.ConnectionStrings["MilkshakeDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadMilkshakeIDs();
            LoadMilkshakesGrid();
        }
    }

    private void LoadMilkshakeIDs()
    {
        try
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT MilkshakeID FROM Milkshakes";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);

                ddlMilkshakeID.DataSource = dt;
                ddlMilkshakeID.DataTextField = "MilkshakeID";
                ddlMilkshakeID.DataValueField = "MilkshakeID";
                ddlMilkshakeID.DataBind();
                ddlMilkshakeID.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception ex)
        {
            Response.Write("<script>alert('Error loading IDs: " + ex.Message + "');</script>");
        }
    }
    private void ClearFields()
    {
       
    }


    protected void btnAdd_Click(object sender, EventArgs e)
    {
        string imagePath = UploadImage();

        try
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Milkshakes (MilkshakeID,Name, Price, Description, ImagePath) VALUES (@ID,@Name, @Price, @Description, @ImagePath)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@ID",txtID.Text);
                cmd.Parameters.AddWithValue("@Name", txtName.Text);
                cmd.Parameters.AddWithValue("@Price", txtPrice.Text);
                cmd.Parameters.AddWithValue("@Description", txtDescription.Text);
                cmd.Parameters.AddWithValue("@ImagePath", imagePath);

                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();

                Response.Write("<script>alert('Milkshake Added Successfully!');</script>");
                LoadMilkshakeIDs();
                LoadMilkshakesGrid();
                ClearFields();
            }
        }
        catch (Exception ex)
        {
            Response.Write("<script>alert('Error adding milkshake: " + ex.Message + "');</script>");
        }
    }

    private string UploadImage()
    {
        if (fileUploadImage.HasFile)
        {
            string fileExtension = Path.GetExtension(fileUploadImage.FileName).ToLower();
            string[] allowedExtensions = { ".jpg", ".jpeg", ".png", ".gif" };
            if (Array.Exists(allowedExtensions, ext => ext == fileExtension))
            {
                string filePath = "Images/" + Guid.NewGuid() + fileExtension;
                fileUploadImage.SaveAs(Server.MapPath(filePath));
                return filePath;
            }
            else
            {
                Response.Write("<script>alert('Only JPG, PNG, and GIF files are allowed.');</script>");
            }
        }
        return "Images/default.png";
    }

    private void LoadMilkshakesGrid()
    {
        try
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Milkshakes";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);

                gvMilkshakes.DataSource = dt;
                gvMilkshakes.DataBind();
            }
        }
        catch (Exception ex)
        {
            Response.Write("<script>alert('Error loading grid: " + ex.Message + "');</script>");
        }
    }

    protected void ddlMilkshakeID_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlMilkshakeID.SelectedIndex > 0)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "SELECT Name, Price, Description, ImagePath FROM Milkshakes WHERE MilkshakeID = @MilkshakeID";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@MilkshakeID", ddlMilkshakeID.SelectedValue);

                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        txtName.Text = reader["Name"].ToString();
                        txtPrice.Text = reader["Price"].ToString();
                        txtDescription.Text = reader["Description"].ToString();
                        imgPreview.ImageUrl = reader["ImagePath"].ToString();
                    }
                    else
                    {
                        ClearFields();
                    }
                    reader.Close();
                    conn.Close();
                }
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('Error loading milkshake details: " + ex.Message + "');</script>");
            }
        }
        else
        {
            ClearFields();
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            if (ddlMilkshakeID.SelectedValue == "")
            {
                lblMessage.Text = "Please select a milkshake to update.";
                return;
            }

            int milkshakeID = Convert.ToInt32(ddlMilkshakeID.SelectedValue);
            string name = txtName.Text.Trim();
            decimal price = Convert.ToDecimal(txtPrice.Text);
            string description = txtDescription.Text.Trim();
            string imagePath = imgPreview.ImageUrl; // Keep old image path

            // If new image uploaded, save it and update path
            if (fileUploadImage.HasFile)
            {
                string fileName = fileUploadImage.FileName;
                string savePath = Server.MapPath("~/Images/" + fileName);
                fileUploadImage.SaveAs(savePath);
                imagePath = "Images/" + fileName;
            }

            string connectionString = ConfigurationManager.ConnectionStrings["MilkshakeDB"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "UPDATE Milkshakes SET Name=@Name, Price=@Price, Description=@Description, ImagePath=@ImagePath WHERE MilkshakeID=@MilkshakeID";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@MilkshakeID", milkshakeID);
                    cmd.Parameters.AddWithValue("@Name", name);
                    cmd.Parameters.AddWithValue("@Price", price);
                    cmd.Parameters.AddWithValue("@Description", description);
                    cmd.Parameters.AddWithValue("@ImagePath", imagePath);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }

            lblMessage.Text = "Milkshake updated successfully!";
            LoadMilkshakesGrid();
        }
        catch (Exception ex)
        {
            lblMessage.Text = "Error: " + ex.Message;
        }
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            if (ddlMilkshakeID.SelectedValue == "")
            {
                lblMessage.Text = "Please select a Milkshake ID to delete.";
                return;
            }

            int milkshakeID = Convert.ToInt32(ddlMilkshakeID.SelectedValue);
            string connectionString = ConfigurationManager.ConnectionStrings["MilkshakeDB"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM Milkshakes WHERE MilkshakeID = @MilkshakeID";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@MilkshakeID", milkshakeID);

                conn.Open();
                int rowsAffected = cmd.ExecuteNonQuery();
                conn.Close();

                if (rowsAffected > 0)
                {
                    lblMessage.Text = "Milkshake deleted successfully.";
                    LoadMilkshakeIDs();  // Refresh dropdown
                    LoadMilkshakesGrid(); // Refresh GridView
                    ClearFields(); // Clear input fields
                }
                else
                {
                    lblMessage.Text = "Error! Milkshake not found.";
                }
            }
        }
        catch (Exception ex)
        {
            lblMessage.Text = "Error: " + ex.Message;
        }
    }


    protected void btnClear_Click(object sender, EventArgs e)
    {
        txtName.Text = "";
        txtPrice.Text = "";
        txtDescription.Text = "";
        ddlMilkshakeID.SelectedIndex = 0;
    }
    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminLogin.aspx");
    }
}
