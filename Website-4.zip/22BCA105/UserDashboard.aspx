﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="UserDashboard.aspx.cs" Inherits="UserDashboard" EnableEventValidation="false" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
 <title>Frosty Bliss - Customer Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #ffe5ec;
        }
        .header {
            background-color: #ff4d6d;
            color: white;
            padding: 15px;
            text-align: left;
            font-size: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .menu {
            display: flex;
            gap: 20px;
        }
        .menu a {
            color: white;
            text-decoration: none;
            font-size: 18px;
            font-weight: bold;
        }
        .banner {
            width: 100%;
            height: 500px;
            background: url('img4.jpg') no-repeat center center;
            background-size: cover;
        }
        .milkshake-container {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            padding: 20px;
        }
        .milkshake-card {
            background: white;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
            text-align: center;
        }
        .milkshake-card img {
            width: 100%;
            height: 150px;
            border-radius: 8px;
        }
        .btn-add {
            background-color: #d63384;
            color: white;
            border: none;
            padding: 8px 12px;
            cursor: pointer;
            border-radius: 5px;
            font-size: 14px;
        }
        .btn-add:hover {
            background-color: #c2185b;
        }
        .footer {
            background-color: #d63384;
            color: white;
            text-align: center;
            padding: 15px;
            font-size: 16px;
            position: relative;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
  

<form id="form1" runat="server">
    <div class="header">
        <span>Welcome, <asp:Label ID="lblCustomerName" runat="server"></asp:Label></span>
        <div class="menu">
            <a href="UserDashboard.aspx">Home</a>
            <a href="Milkshakes.aspx">Milkshakes</a>
            <a href="MyCart.aspx">My Cart</a>
            <a href="CustomerLogin.aspx">Log Out</a>
        </div>
    </div>

    <div class="banner"></div>

    <div class="milkshake-container">
        <asp:Repeater ID="rptMilkshakes" runat="server">
            <ItemTemplate>
                <div class="milkshake-card">
                    <img src='<%# Eval("ImagePath") ?? "/images/default-milkshake.jpg" %>' alt="Milkshake Image" />
                    <h3><%# Eval("Name") %></h3>
                    <p><%# Eval("Description") %></p>
                    <p><b>Price:</b> ₹<%# Eval("Price") %></p>
                    <asp:Button ID="btnAddToCart" runat="server" Text="Add to Cart" CssClass="btn-add"
                        CommandArgument='<%# Eval("MilkshakeID") %>' OnClick="btnAddToCart_Click" />
                </div>
            </ItemTemplate>
        </asp:Repeater>
    </div>

    <div class="footer">
        &copy; 2025 Frosty Bliss Milkshakes | Enjoy the Best Milkshakes in Town!
    </div>
</form>
