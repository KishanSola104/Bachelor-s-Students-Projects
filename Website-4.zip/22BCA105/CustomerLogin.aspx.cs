﻿using System;
using System.Data.SqlClient;
using System.Configuration;

public partial class CustomerLogin : System.Web.UI.Page
{
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        string connStr = ConfigurationManager.ConnectionStrings["MilkshakeDB"].ConnectionString;
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            string query = "SELECT COUNT(*) FROM Customers WHERE Email=@Email AND Password=@Password";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
            cmd.Parameters.AddWithValue("@Password", txtPassword.Text);

            conn.Open();
            int count = (int)cmd.ExecuteScalar();
            conn.Close();

            if (count > 0)
            {
                Session["CustomerEmail"] = txtEmail.Text;
                Response.Redirect("UserDashboard.aspx");
            }
            else
            {
                lblMessage.Text = "Invalid Email or Password!";
            }
        }
    }
}
