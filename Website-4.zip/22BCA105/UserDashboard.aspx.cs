﻿using System;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;

public partial class UserDashboard : System.Web.UI.Page
{
    string connStr = ConfigurationManager.ConnectionStrings["MilkshakeDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["CustomerEmail"] == null)
        {
            Response.Redirect("CustomerLogin.aspx");
        }

        if (!IsPostBack)
        {
            GetCustomerName();
            LoadMilkshakes();
        }
    }

    private void GetCustomerName()
    {
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            string query = "SELECT FullName FROM Customers WHERE Email = @Email";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@Email", Session["CustomerEmail"].ToString());
            conn.Open();
            object result = cmd.ExecuteScalar();
            if (result != null)
            {
                lblCustomerName.Text = result.ToString();
            }
        }
    }

    private void LoadMilkshakes()
    {
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            string query = "SELECT * FROM Milkshakes";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            rptMilkshakes.DataSource = dt;
            rptMilkshakes.DataBind();
        }
    }

    protected void btnAddToCart_Click(object sender, EventArgs e)
    {
        if (Session["CustomerEmail"] == null)
        {
            Response.Redirect("CustomerLogin.aspx");
            return;
        }

        Button btn = (Button)sender;
        int milkshakeID;
        if (!int.TryParse(btn.CommandArgument, out milkshakeID))
        {
            return;
        }

        string customerEmail = Session["CustomerEmail"].ToString();

        using (SqlConnection conn = new SqlConnection(connStr))
        {
            string query = @"INSERT INTO Cart (CustomerEmail, MilkshakeID, Quantity, Price, DateAdded) 
                             VALUES (@CustomerEmail, @MilkshakeID, 1, 
                             (SELECT Price FROM Milkshakes WHERE MilkshakeID = @MilkshakeID), GETDATE())";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@CustomerEmail", customerEmail);
            cmd.Parameters.AddWithValue("@MilkshakeID", milkshakeID);

            conn.Open();
            cmd.ExecuteNonQuery();
            // Show JavaScript alert
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Milkshake added to cart successfully!');", true);
        }
    }
}
