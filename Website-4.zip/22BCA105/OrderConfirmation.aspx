﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="OrderConfirmation.aspx.cs" Inherits="OrderConfirmation" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Order Confirmation - Frosty Bliss</title>

    <style>
        .bill-container {
            width: 60%;
            margin: auto;
            padding: 20px;
            border: 2px solid #ccc;
            border-radius: 10px;
            background: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            font-family: Arial, sans-serif;
        }
        .bill-header {
            text-align: center;
            font-size: 22px;
            font-weight: bold;
            color: #d9534f;
        }
        .bill-details {
            margin: 20px 0;
            padding: 10px;
            border: 1px solid #ddd;
            background: #f9f9f9;
            border-radius: 5px;
        }
        .bill-items {
            width: 100%;
            border-collapse: collapse;
        }
        .bill-items th, .bill-items td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        .bill-items th {
            background: #f2f2f2;
        }
        .total-amount {
            font-size: 18px;
            font-weight: bold;
            text-align: right;
            margin-top: 10px;
        }
        .thank-you {
            text-align: center;
            margin-top: 20px;
            font-size: 16px;
            color: green;
        }
        .btn-print {
            display: block;
            width: 100%;
            padding: 10px;
            text-align: center;
            background: #5cb85c;
            color: #fff;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }
        .btn-print:hover {
            background: #4cae4c;
        }
    </style>
</head>
<body>
<form runat="server">
    <div class="bill-container">
        <div class="bill-header">🛒 Frosty Bliss Milkshakes - Order Confirmation<br />
            <asp:Label ID="lblErrorMessage" runat="server"></asp:Label>
        </div>
        <div class="bill-details">
            <strong>Customer Name:</strong> <asp:Label ID="lblCustomerName" runat="server"></asp:Label><br />
            <strong>Email:</strong> <asp:Label ID="lblCustomerEmail" runat="server"></asp:Label><br />
            <strong>Shipping Address:</strong> <asp:Label ID="lblAddress" runat="server"></asp:Label>, 
            <asp:Label ID="lblCity" runat="server"></asp:Label><br />
            <strong>Order Date:</strong> <asp:Label ID="lblOrderDate" runat="server"></asp:Label>
        </div>
        
        <table class="bill-items">
            <thead>
                <tr>
                    <th>Milkshake</th>
                    <th>Price (₹)</th>
                </tr>
            </thead>
            <tbody>
                <asp:Literal ID="ltOrderItems" runat="server"></asp:Literal>
            </tbody>
        </table>
        
        <div class="total-amount">Total Amount: ₹<asp:Label ID="lblTotalAmount" runat="server"></asp:Label></div>

        <div class="thank-you"> Thank you for ordering from Frosty Bliss Milkshakes! Enjoy your drink. </div>
         <div class="thank-you"> You will Receive Your Shake in 30-40 Minutes . </div>
        <button class="btn-print" onclick="window.print();">🖨️ Print Bill</button>
         <div class="thank-you">  
        <asp:Button ID="Button1" runat="server" Text="Countiue Buying" 
                 onclick="Button1_Click" /></div>
    </div>
    </form>
</body>
</html>