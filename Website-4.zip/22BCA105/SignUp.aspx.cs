﻿using System;
using System.Data.SqlClient;
using System.Configuration;

public partial class SignUp : System.Web.UI.Page
{
    protected void btnSignUp_Click(object sender, EventArgs e)
    {
        if (txtPassword.Text != txtConfirmPassword.Text)
        {
            lblMessage.Text = "Passwords do not match!";
            return;
        }

        string connStr = ConfigurationManager.ConnectionStrings["MilkshakeDB"].ConnectionString;
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            string query = "INSERT INTO Customers (FullName, Email, MobileNo, City, FullAddress, Password) VALUES (@FullName, @Email, @MobileNo, @City, @FullAddress, @Password)";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@FullName", txtFullName.Text);
            cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
            cmd.Parameters.AddWithValue("@MobileNo", txtMobile.Text);
            cmd.Parameters.AddWithValue("@City", ddlCity.SelectedValue);
            cmd.Parameters.AddWithValue("@FullAddress", txtAddress.Text);
            cmd.Parameters.AddWithValue("@Password", txtPassword.Text);

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();

            lblMessage.Text = "Registration successful! <a href='CustomerLogin.aspx'>Login Here</a>";
        }
    }
}
