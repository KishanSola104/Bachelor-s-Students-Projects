﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="ManageMilkShakes.aspx.cs" Inherits="ManageMilkShakes" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Milk Shakes </title>
 <style>
    /* General Styles */
body {
    margin: 0;
    font-family: 'Poppins', sans-serif;
    background-color: #fffaf0;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
}

/* Dashboard Container */
.dashboard-container {
    text-align: center;
    padding: 20px;
}

/* Navigation Menu */
.nav-menu {
    background: linear-gradient(90deg, #ff6600, #ff3300);
    padding: 15px;
    margin-bottom: 20px;
    border-radius: 10px;
}

.nav-menu ul {
    list-style: none;
    padding: 0;
    margin: 0;
    display: flex;
    justify-content: center;
}

.nav-menu ul li {
    margin: 0 15px;
}

.nav-menu ul li a {
    text-decoration: none;
    color: white;
    font-size: 18px;
    font-weight: bold;
    transition: 0.3s;
}

.nav-menu ul li a:hover {
    color: #ffcc99;
}

/* Dashboard Content */
.dashboard-content {
    background: white;
    padding: 20px;
    box-shadow: 0px 4px 10px rgba(0,0,0,0.2);
    border-radius: 10px;
    max-width: 700px;
    margin: 0 auto;
}

/* Logout Button */
.btn-logout {
    background: #cc0000;
    color: white;
    border: none;
    padding: 10px 20px;
    font-size: 16px;
    cursor: pointer;
    border-radius: 5px;
    transition: 0.3s;
}

.btn-logout:hover {
    background: #ff3300;
}

/* Form Container */
.container {
    background-color: white;
    width: 90%;
    max-width: 600px;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
    margin: 0 auto;
}

/* Headings */
h2, h3 {
    text-align: center;
    color: #333;
}

/* Input Groups */
.input-group {
    margin-bottom: 15px;
    text-align: left;
}

.input-group label {
    display: block;
    font-weight: bold;
    margin-bottom: 5px;
    color: #555;
}

.input-field {
    width: 100%;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 14px;
}

/* Buttons */
.button-group {
    text-align: center;
    margin-top: 15px;
}

.btn {
    padding: 10px 15px;
    font-size: 14px;
    border-radius: 5px;
    border: none;
    cursor: pointer;
    transition: 0.3s;
    color: white;
    margin: 5px;
}

.btn:hover {
    opacity: 0.85;
}

/* Different Button Colors */
#btnAdd { background-color: #28a745; }
#btnUpdate { background-color: #007bff; }
#btnDelete { background-color: #dc3545; }
#btnClear { background-color: #ffc107; color: black; }

/* Image Preview */
.image-preview {
    display: block;
    margin-top: 10px;
    border: 1px solid #ddd;
    border-radius: 5px;
}

/* Grid View */
.grid-view {
    width: 100%;
    margin-top: 20px;
    border-collapse: collapse;
    background-color: #fff;
}

.grid-view th, .grid-view td {
    border: 1px solid #ddd;
    padding: 10px;
    text-align: center;
}

.grid-view th {
    background-color: #007bff;
    color: white;
}

.grid-view img {
    border-radius: 5px;
}

/* Error Message */
#error-message {
    color: red;
    font-weight: bold;
    text-align: center;
    margin-top: 10px;
}


    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="dashboard-container">
            <h1>Welcome, Admin</h1>
            <div class="nav-menu">
                <ul>
                    
                   
                     <li><a href="AdminDashboard.aspx">Home</a></li>
                    <li><a href="ManageMilkShakes.aspx">Manage MilkShakes</a></li>
                    <li><a href="Orders.aspx">Orders</a></li>
                    <li><a href="Customers.aspx">Customers</a></li>
                    
                    <li><asp:Button ID="btnLogout" runat="server" Text="Logout" CssClass="btn-logout" OnClick="btnLogout_Click" /></li>
                </ul>
            </div>
            <div class="dashboard-content">
                <div class="container">
            <h2>Manage Milkshakes</h2>
            <p>
                <asp:Label ID="lblMessage" runat="server"></asp:Label>
            </p>
            
            <div class="input-group">
                <label>Select Milkshake ID:</label>
                <asp:DropDownList ID="ddlMilkshakeID" runat="server" AutoPostBack="true" CssClass="input-field" OnSelectedIndexChanged="ddlMilkshakeID_SelectedIndexChanged">
                </asp:DropDownList>
            </div>

            <div class="input-group">
                <label>Enter MilkShake ID:</label>
                <asp:TextBox ID="txtID" runat="server" CssClass="input-field"></asp:TextBox>
            </div>

            <div class="input-group">
                <label>Name:</label>
                <asp:TextBox ID="txtName" runat="server" CssClass="input-field"></asp:TextBox>
            </div>

            <div class="input-group">
                <label>Price:</label>
                <asp:TextBox ID="txtPrice" runat="server" CssClass="input-field"></asp:TextBox>
            </div>

            <div class="input-group">
                <label>Description:</label>
                <asp:TextBox ID="txtDescription" runat="server" CssClass="input-field"></asp:TextBox>
            </div>

            <div class="input-group">
                <label>Upload Image:</label>
                <asp:FileUpload ID="fileUploadImage" runat="server" CssClass="input-field"/>
                 <asp:Image ID="imgPreview" runat="server" CssClass="image-preview" Width="150px" Height="150px" />
            </div>
       

            <div class="button-group">
                <asp:Button ID="btnAdd" runat="server" Text="Add" CssClass="btn" OnClick="btnAdd_Click"/>
                <asp:Button ID="btnUpdate" runat="server" Text="Update" CssClass="btn" OnClick="btnUpdate_Click"/>
                <asp:Button ID="btnDelete" runat="server" Text="Delete" CssClass="btn" OnClick="btnDelete_Click"/>
                <asp:Button ID="btnClear" runat="server" Text="Clear" CssClass="btn" OnClick="btnClear_Click"/>
            </div>

            <h3>Milkshakes List</h3>
            <asp:GridView ID="gvMilkshakes" runat="server" CssClass="grid-view" AutoGenerateColumns="False">
                <Columns>
                    <asp:BoundField DataField="MilkshakeID" HeaderText="ID"/>
                    <asp:BoundField DataField="Name" HeaderText="Name"/>
                    <asp:BoundField DataField="Price" HeaderText="Price"/>
                    <asp:BoundField DataField="Description" HeaderText="Description"/>
                    <asp:ImageField DataImageUrlField="ImagePath" HeaderText="Image">
                        <ControlStyle Width="80px" Height="80px"/>
                    </asp:ImageField>
                </Columns>
            </asp:GridView>
        </div>
            </div>
        </div>
    </form>
</body>
</html>
