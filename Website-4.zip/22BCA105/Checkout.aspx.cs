﻿using System;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Web.UI;

public partial class Checkout : Page
{
    string connStr = ConfigurationManager.ConnectionStrings["MilkshakeDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["CustomerEmail"] == null)
            {
                Response.Redirect("CustomerLogin.aspx");
                return;
            }

            if (!IsPostBack)
            {
                LoadOrderSummary();
            }
        }
        catch (Exception ex)
        {
            LogError("Page_Load", ex);
            ShowErrorMessage("An unexpected error occurred while loading the checkout page.");
        }
    }

    private void LoadOrderSummary()
    {
        try
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string query = @"
                SELECT M.Name, M.Price 
                FROM Cart C 
                INNER JOIN Milkshakes M ON C.MilkshakeID = M.MilkshakeID
                WHERE C.CustomerEmail = @CustomerEmail";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@CustomerEmail", Session["CustomerEmail"].ToString());
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                string summary = "<ul>";
                decimal totalAmount = 0;

                while (reader.Read())
                {
                    string milkshakeName = reader["Name"].ToString();
                    decimal price = Convert.ToDecimal(reader["Price"]);
                    totalAmount += price;

                    summary += "<li>" + milkshakeName + " - ₹" + price + "</li>";
                }
                summary += "</ul>";

                ltOrderSummary.Text = summary;
                lblTotalAmount.Text = "Total Amount: ₹" + totalAmount;
            }
        }
        catch (Exception ex)
        {
            LogError("LoadOrderSummary", ex);
            ShowErrorMessage("An error occurred while loading the order summary.");
        }
    }

    protected void btnPlaceOrder_Click(object sender, EventArgs e)
    {
        try
        {
            string customerEmail = Session["CustomerEmail"].ToString();
            decimal totalAmount = 0;

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();

                // Get Total Amount
                string totalQuery = "SELECT SUM(M.Price) FROM Cart C INNER JOIN Milkshakes M ON C.MilkshakeID = M.MilkshakeID WHERE C.CustomerEmail = @CustomerEmail";
                SqlCommand totalCmd = new SqlCommand(totalQuery, conn);
                totalCmd.Parameters.AddWithValue("@CustomerEmail", customerEmail);
                object result = totalCmd.ExecuteScalar();
                if (result != DBNull.Value)
                {
                    totalAmount = Convert.ToDecimal(result);
                }

                // Place Order
                string orderQuery = "INSERT INTO Orders (CustomerEmail, TotalAmount, ShippingAddress, City, OrderDate) " +
                                    "VALUES (@CustomerEmail, @TotalAmount, @ShippingAddress, @City, GETDATE())";
                SqlCommand orderCmd = new SqlCommand(orderQuery, conn);
                orderCmd.Parameters.AddWithValue("@CustomerEmail", customerEmail);
                orderCmd.Parameters.AddWithValue("@TotalAmount", totalAmount);
                orderCmd.Parameters.AddWithValue("@ShippingAddress", txtAddress.Text);
                orderCmd.Parameters.AddWithValue("@City", ddlCity.SelectedValue);
                orderCmd.ExecuteNonQuery();

                // Clear Cart
                string clearCartQuery = "DELETE FROM Cart WHERE CustomerEmail = @CustomerEmail";
                SqlCommand clearCartCmd = new SqlCommand(clearCartQuery, conn);
                clearCartCmd.Parameters.AddWithValue("@CustomerEmail", customerEmail);
                clearCartCmd.ExecuteNonQuery();
            }

            Session["OrderTotal"] = totalAmount;
            Response.Redirect("OrderConfirmation.aspx");
        }
        catch (Exception ex)
        {
            LogError("btnPlaceOrder_Click", ex);
            ShowErrorMessage("An error occurred while placing the order. Please try again.");
        }
    }

    private void LogError(string functionName, Exception ex)
    {
        // Simple error logging
        System.Diagnostics.Debug.WriteLine("Error in " + functionName + ": " + ex.Message);
    }

    private void ShowErrorMessage(string message)
    {
        lblErrorMessage.Text = message;
        lblErrorMessage.Visible = true;
    }
}
