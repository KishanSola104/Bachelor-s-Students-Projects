﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="MyCart.aspx.cs" Inherits="MyCart" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
<title>Frosty Bliss - My Cart </title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #ffe5ec;
        }
        .header {
            background-color: #ff4d6d;
            color: white;
            padding: 15px;
            text-align: left;
            font-size: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .menu {
            display: flex;
            gap: 20px;
        }
        .menu a {
            color: white;
            text-decoration: none;
            font-size: 18px;
            font-weight: bold;
        }
      
        .milkshake-container {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            padding: 20px;
        }
        .milkshake-card {
            background: white;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
            text-align: center;
        }
        .milkshake-card img {
            width: 100%;
            height: 150px;
            border-radius: 8px;
        }
        .btn-add {
            background-color: #d63384;
            color: white;
            border: none;
            padding: 8px 12px;
            cursor: pointer;
            border-radius: 5px;
            font-size: 14px;
        }
        .btn-add:hover {
            background-color: #c2185b;
        }
        .footer {
            background-color: #d63384;
            color: white;
            text-align: center;
            padding: 15px;
            font-size: 16px;
            position: relative;
            bottom: 0;
            width: 100%;
        }
        
         .container { width: 80%; margin: auto; padding: 20px; }
        .cart-item { display: flex; justify-content: space-between; padding: 10px; background: white; border-radius: 8px; margin-bottom: 10px; }
        .btn-remove, .btn-checkout { padding: 8px 12px; border: none; cursor: pointer; border-radius: 5px; }
        .btn-remove { background-color: red; color: white; }
        .btn-checkout { background-color: green; color: white; }
    </style>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #ffe5ec;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 60%;
            margin: 50px auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
            height:90vh;
        }
        h2 {
            text-align: center;
            color: #d63384;
        }
        .cart-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }
        .cart-item img {
            width: 80px;
            height: 80px;
            border-radius: 8px;
            margin-right: 10px;
        }
        .cart-item div {
            flex: 1;
        }
        .quantity-controls {
            display: flex;
            align-items: center;
        }
        .btn-qty {
            background-color: #ff4d6d;
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
            border-radius: 5px;
            font-size: 14px;
            margin: 0 5px;
        }
        .btn-remove {
            background-color: red;
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
            border-radius: 5px;
        }
        .btn-checkout {
            display: block;
            width: 100%;
            background-color: #d63384;
            color: white;
            padding: 10px;
            text-align: center;
            border-radius: 5px;
            font-size: 16px;
            margin-top: 20px;
            text-decoration: none;
        }
        .btn-checkout:hover {
            background-color: #c2185b;
        }
                .total-amount {
            text-align: right;
            font-size: 18px;
            font-weight: bold;
            margin-top: 15px;
        }

    </style>
</head>
<body>
  

<form id="form1" runat="server">
    <div class="header">
        <span>Welcome, <asp:Label ID="lblCustomerName" runat="server"></asp:Label></span>
        <div class="menu">
            <a href="UserDashboard.aspx">Home</a>
            <a href="Milkshakes.aspx">Milkshakes</a>
            <a href="MyCart.aspx">My Cart</a>
            <a href="CustomerLogin.aspx">Log Out</a>
        </div>
    </div>

   <div class="container">
            <h2>My Cart</h2>
            <p>
                <asp:Label ID="lblErrorMessage" runat="server"></asp:Label>
            </p>
            <asp:Repeater ID="rptCart" runat="server">
                <ItemTemplate>
                    <div class="cart-item">
                        <img src='<%# Eval("ImagePath") ?? "/images/default-milkshake.jpg" %>' alt="Milkshake" />
                        <div>
                            <strong><%# Eval("MilkshakeName") %></strong>
                            <p>₹<%# Eval("Price") %></p>
                        </div>
                        <div class="quantity-controls">
                            <asp:Button ID="btnDecrease" runat="server" Text="-" CssClass="btn-qty"
                                CommandArgument='<%# Eval("MilkshakeID") %>' OnClick="btnDecrease_Click" />
                            <span><%# Eval("Quantity") %></span>
                            <asp:Button ID="btnIncrease" runat="server" Text="+" CssClass="btn-qty"
                                CommandArgument='<%# Eval("MilkshakeID") %>' OnClick="btnIncrease_Click" />
                        </div>
                        <asp:Button ID="btnRemove" runat="server" Text="Remove" CssClass="btn-remove"
                            CommandArgument='<%# Eval("MilkshakeID") %>' OnClick="btnRemove_Click" />
                    </div>
                </ItemTemplate>
            </asp:Repeater>

             <!-- Total Amount -->
            <div class="total-amount">
                Total Amount: ₹<asp:Label ID="lblTotalAmount" runat="server" Text="0"></asp:Label>
            </div>

            <asp:Button ID="btnCheckout" runat="server" Text="Proceed to Checkout" CssClass="btn-checkout" OnClick="btnCheckout_Click" />
        </div>

    <div class="footer">
        &copy; 2025 Frosty Bliss Milkshakes | Enjoy the Best Milkshakes in Town!
    </div>
</form>
