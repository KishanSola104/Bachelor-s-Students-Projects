﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="SignUp.aspx.cs" Inherits="SignUp" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
   
 <title>Frosty Bliss - Sign Up</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #ffe5ec;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            width: 350px;
            text-align: center;
        }
        h2 {
            color: #d63384;
        }
        .input-group {
            margin-bottom: 12px;
            text-align: left;
        }
        label {
            font-weight: bold;
        }
        .input-field {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
        }
        .btn {
            width: 100%;
            background-color: #d63384;
            color: white;
            border: none;
            padding: 10px;
            cursor: pointer;
            border-radius: 5px;
            margin-top: 10px;
            font-size: 16px;
        }
        .btn:hover {
            background-color: #c2185b;
        }
        .login-link {
            display: block;
            text-align: center;
            margin-top: 10px;
            color: #6c757d;
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="container">
            <h2>Sign Up</h2>
            <asp:Label ID="lblMessage" runat="server" ForeColor="Red"></asp:Label>

            <div class="input-group">
                <label>Full Name:</label>
                <asp:TextBox ID="txtFullName" runat="server" CssClass="input-field"></asp:TextBox>
            </div>

            <div class="input-group">
                <label>Email:</label>
                <asp:TextBox ID="txtEmail" runat="server" CssClass="input-field"></asp:TextBox>
            </div>

            <div class="input-group">
                <label>Mobile No:</label>
                <asp:TextBox ID="txtMobile" runat="server" CssClass="input-field"></asp:TextBox>
            </div>

            <div class="input-group">
                <label>City:</label>
                <asp:DropDownList ID="ddlCity" runat="server" CssClass="input-field">
                    <asp:ListItem Text="Anand" Value="Anand"></asp:ListItem>
                    <asp:ListItem Text="Vidhya Nagar" Value="Vidhya Nagar"></asp:ListItem>
                </asp:DropDownList>
            </div>

            <div class="input-group">
                <label>Full Address:</label>
                <asp:TextBox ID="txtAddress" runat="server" CssClass="input-field" TextMode="MultiLine"></asp:TextBox>
            </div>

            <div class="input-group">
                <label>Password:</label>
                <asp:TextBox ID="txtPassword" runat="server" CssClass="input-field" TextMode="Password"></asp:TextBox>
            </div>

            <div class="input-group">
                <label>Confirm Password:</label>
                <asp:TextBox ID="txtConfirmPassword" runat="server" CssClass="input-field" TextMode="Password"></asp:TextBox>
            </div>

            <asp:Button ID="btnSignUp" runat="server" Text="Sign Up" CssClass="btn" OnClick="btnSignUp_Click" />

            <a href="CustomerLogin.aspx" class="login-link">Back to Login</a>
        </div>
    </form>
</body>
</html>