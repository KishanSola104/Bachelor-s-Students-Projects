﻿using System;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MyCart : Page
{
    string connStr = ConfigurationManager.ConnectionStrings["MilkshakeDB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["CustomerEmail"] == null)
            {
                Response.Redirect("CustomerLogin.aspx");
                return;
            }

            if (!IsPostBack)
            {
                LoadCart();
            }
        }
        catch (Exception ex)
        {
            LogError("Page_Load", ex);
            ShowErrorMessage("An unexpected error occurred while loading the cart.");
        }
    }

    private void LoadCart()
    {
        try
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string query = @"SELECT c.MilkshakeID, m.Name AS MilkshakeName, m.Price, m.ImagePath, c.Quantity 
                                 FROM Cart c 
                                 INNER JOIN Milkshakes m ON c.MilkshakeID = m.MilkshakeID
                                 WHERE c.CustomerEmail = @Email";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Email", Session["CustomerEmail"].ToString());

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                rptCart.DataSource = dt;
                rptCart.DataBind();

                // Calculate Total Amount
                decimal totalAmount = 0;
                foreach (DataRow row in dt.Rows)
                {
                    totalAmount += Convert.ToDecimal(row["Price"]) * Convert.ToInt32(row["Quantity"]);
                }
                lblTotalAmount.Text = totalAmount.ToString();
            }
        }
        catch (Exception ex)
        {
            LogError("LoadCart", ex);
            ShowErrorMessage("An error occurred while loading your cart.");
        }
    }

    protected void btnRemove_Click(object sender, EventArgs e)
    {
        try
        {
            Button btn = (Button)sender;
            int milkshakeID = int.Parse(btn.CommandArgument);

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string query = "DELETE FROM Cart WHERE CustomerEmail = @Email AND MilkshakeID = @MilkshakeID";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Email", Session["CustomerEmail"].ToString());
                cmd.Parameters.AddWithValue("@MilkshakeID", milkshakeID);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
            LoadCart();
        }
        catch (Exception ex)
        {
            LogError("btnRemove_Click", ex);
            ShowErrorMessage("An error occurred while removing the item from the cart.");
        }
    }

    protected void btnIncrease_Click(object sender, EventArgs e)
    {
        try
        {
            Button btn = (Button)sender;
            int milkshakeID = int.Parse(btn.CommandArgument);

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string query = "UPDATE Cart SET Quantity = Quantity + 1 WHERE CustomerEmail = @Email AND MilkshakeID = @MilkshakeID";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Email", Session["CustomerEmail"].ToString());
                cmd.Parameters.AddWithValue("@MilkshakeID", milkshakeID);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
            LoadCart();
        }
        catch (Exception ex)
        {
            LogError("btnIncrease_Click", ex);
            ShowErrorMessage("An error occurred while updating the quantity.");
        }
    }

    protected void btnDecrease_Click(object sender, EventArgs e)
    {
        try
        {
            Button btn = (Button)sender;
            int milkshakeID = int.Parse(btn.CommandArgument);

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string query = "UPDATE Cart SET Quantity = Quantity - 1 WHERE CustomerEmail = @Email AND MilkshakeID = @MilkshakeID AND Quantity > 1";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Email", Session["CustomerEmail"].ToString());
                cmd.Parameters.AddWithValue("@MilkshakeID", milkshakeID);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
            LoadCart();
        }
        catch (Exception ex)
        {
            LogError("btnDecrease_Click", ex);
            ShowErrorMessage("An error occurred while decreasing the quantity.");
        }
    }

    protected void btnCheckout_Click(object sender, EventArgs e)
    {
        try
        {
            Response.Redirect("Checkout.aspx");
        }
        catch (Exception ex)
        {
            LogError("btnCheckout_Click", ex);
            ShowErrorMessage("An error occurred while proceeding to checkout.");
        }
    }

    private void LogError(string functionName, Exception ex)
    {
        // Simple error logging
        System.Diagnostics.Debug.WriteLine("Error in " + functionName + ": " + ex.Message);
    }

    private void ShowErrorMessage(string message)
    {
        lblErrorMessage.Text = message;
        lblErrorMessage.Visible = true;
    }
}
